# Saravana Bhava v1.0.1 - QA Test Plan

## Test Scope
- App Version: 1.0.1
- Build Type: Production AAB
- Target Platform: Android (API 24-36)
- Package: com.saravanabhava.murugan

## Functional Tests

### 1. Navigation & Screens
- [ ] Splash screen displays correctly (2.5 seconds)
- [ ] Home screen loads with hero carousel
- [ ] Bottom tab navigation works (Home, Library, Bookmarks, Settings, AI Search, Temples)
- [ ] All god screens accessible (Murugan, Shiva, Perumal, Sakthi, Siddhars, Vinayagar)
- [ ] Song detail screen opens correctly
- [ ] Back navigation works on all screens

### 2. Content Display
- [ ] Real content loads from JSON (app_content_records)
- [ ] Temple list displays Murugan temples (needs_review status)
- [ ] Content shows "Needs Review" badge correctly
- [ ] No fake counts displayed (1300+, 4000+, etc.)
- [ ] Verification status badges show correctly
- [ ] Tamil text renders properly

### 3. AI Search Feature
- [ ] AI Search screen accessible from bottom tabs
- [ ] Search by deity works (e.g., "முருகன்")
- [ ] Search by mantra works
- [ ] Search by problem works
- [ ] Results display with verification status
- [ ] "Needs Review" content marked appropriately
- [ ] AI disclaimer displays correctly

### 4. Temple List Feature
- [ ] Temple List screen accessible from bottom tabs
- [ ] Murugan temples display with correct information
- [ ] Temple details show location, deity, status
- [ ] All temples marked as "Needs Review"
- [ ] No fake temple counts

### 5. Bookmarks
- [ ] Bookmark button works on content
- [ ] Bookmarked items appear in Bookmarks screen
- [ ] Remove bookmark works
- [ ] Bookmark count updates

### 6. Audio & Media
- [ ] No fake audio player displayed
- [ ] Audio status shows "not_available" when appropriate
- [ ] YouTube search button available when no local audio

### 7. Settings & Profile
- [ ] Settings screen accessible
- [ ] Profile screen accessible
- [ ] Privacy policy link works
- [ ] Support email link works

### 8. Offline Support
- [ ] App works without internet connection
- [ ] Content loads from local JSON
- [ ] Navigation works offline

## Compliance Tests

### 1. Version & SDK
- [ ] versionCode: 2
- [ ] versionName: 1.0.1
- [ ] targetSdkVersion: 36
- [ ] minSdkVersion: 24
- [ ] compileSdkVersion: 36

### 2. Package Name
- [ ] Package: com.saravanabhava.murugan (unchanged)

### 3. Permissions
- [ ] INTERNET permission present
- [ ] VIBRATE permission present
- [ ] RECEIVE_BOOT_COMPLETED permission present
- [ ] No unnecessary permissions

### 4. Content Verification
- [ ] No fake song counts (1300+)
- [ ] No fake audio claims
- [ ] All content marked with verification status
- [ ] "Needs Review" content clearly labeled

### 5. Privacy & Data
- [ ] No analytics tracking
- [ ] No user data collection
- [ ] No ads displayed
- [ ] Privacy policy accessible

## Performance Tests

### 1. Load Times
- [ ] App starts within 3 seconds
- [ ] Splash screen animation smooth
- [ ] Screen transitions smooth (< 500ms)
- [ ] Content loads without lag

### 2. Memory
- [ ] No memory leaks on navigation
- [ ] App doesn't crash on rapid navigation
- [ ] Smooth scrolling in lists

### 3. Battery
- [ ] No excessive battery drain
- [ ] No background processes running unnecessarily

## Device Tests

### 1. Screen Sizes
- [ ] Works on small phones (4.5")
- [ ] Works on medium phones (5.5")
- [ ] Works on large phones (6.5"+)
- [ ] Landscape orientation (if supported)

### 2. Android Versions
- [ ] Android 6 (API 24) - minimum
- [ ] Android 9 (API 28)
- [ ] Android 12 (API 31)
- [ ] Android 15 (API 36) - target

## Build & Deployment

### 1. Build Process
- [ ] EAS build completes successfully
- [ ] AAB file generated (app-release.aab)
- [ ] APK file generated (app-release.apk)
- [ ] No build warnings/errors

### 2. Installation
- [ ] AAB installs via Google Play Console
- [ ] APK installs via adb
- [ ] App launches after installation
- [ ] No installation errors

### 3. First Launch
- [ ] Splash screen displays
- [ ] Home screen loads
- [ ] All tabs accessible
- [ ] Content loads correctly

## Known Issues & Limitations

- Content marked "Needs Review" - verification pending
- AI Search uses local content only (no external AI yet)
- Temple list limited to Murugan temples
- Audio features not implemented (coming soon)
- Multi-language support framework only (Tamil + English)

## Sign-Off

- QA Tester: _________________
- Date: _________________
- Status: PASS / FAIL

