import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { C } from '../utils/theme';
import { getMuruganTemples } from '../data/dataService';
import { Temple } from '../data/models';

const TempleListScreen: React.FC = () => {
  const muruganTemples = getMuruganTemples();

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <Text style={styles.title}>முருகன் கோயில்கள் (Murugan Temples)</Text>
        <Text style={styles.subtitle}>சரிபார்ப்பு தேவைப்படும் கோயில்கள்</Text>

        {muruganTemples.length > 0 ? (
          <View style={styles.templesContainer}>
            {muruganTemples.map((temple: Temple) => (
              <View key={temple.id} style={styles.templeItem}>
                <Text style={styles.templeName}>{temple.names.tamil_or_local} ({temple.names.english})</Text>
                <Text style={styles.templeLocation}>{temple.location.city_town}, {temple.location.state_province}</Text>
                <Text style={styles.templeStatus}>சரிபார்ப்பு நிலை: {temple.app_workflow.display_label}</Text>
                <TouchableOpacity style={styles.viewDetailsButton}>
                  <Text style={styles.viewDetailsButtonText}>விவரங்கள் காண்க (View Details)</Text>
                </TouchableOpacity>
              </View>
            ))}
          </View>
        ) : (
          <Text style={styles.noTemplesText}>கோயில்கள் எதுவும் இல்லை.</Text>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: C.bg,
  },
  scrollContainer: {
    padding: 20,
    alignItems: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: C.gold,
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: C.txt2,
    marginBottom: 30,
    textAlign: 'center',
  },
  templesContainer: {
    width: '100%',
  },
  templeItem: {
    backgroundColor: C.card,
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
    borderColor: C.border,
    borderWidth: 1,
  },
  templeName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: C.txt,
    marginBottom: 5,
  },
  templeLocation: {
    fontSize: 14,
    color: C.txt2,
    marginBottom: 5,
  },
  templeStatus: {
    fontSize: 14,
    color: C.saffron,
    marginBottom: 10,
  },
  viewDetailsButton: {
    backgroundColor: C.gold,
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  viewDetailsButtonText: {
    color: C.bg,
    fontSize: 14,
    fontWeight: 'bold',
  },
  noTemplesText: {
    fontSize: 16,
    color: C.txt3,
    textAlign: 'center',
    marginTop: 50,
  },
});

export default TempleListScreen;
