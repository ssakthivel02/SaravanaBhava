import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, StatusBar } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { C, S, R } from '../utils/theme';
import { SONGS } from '../data/songs';
import { useApp } from '../context/AppContext';

const SIDDHARS_18 = [
  { n: 1, name: 'அகத்தியர்', en: 'Agathiyar', icon: '🌿', work: 'அகத்தியர் வைத்திய ரத்தினாகரம், தமிழ் இலக்கணம்', field: 'மூலிகை & யோகம்', period: 'சங்க காலம்' },
  { n: 2, name: 'திருமூலர்', en: 'Thirumoolar', icon: '🧘', work: 'திருமந்திரம் (3000 பாடல்கள்)', field: 'யோகம் & தத்துவம்', period: '5-7ம் நூற்றாண்டு' },
  { n: 3, name: 'போகர்', en: 'Bogar', icon: '🔬', work: 'போகர் 7000, பழனி நவபாஷாண மூர்த்தி', field: 'ரசவாதம் & ஞானம்', period: '3ம் நூற்றாண்டு' },
  { n: 4, name: 'சிவவாக்கியர்', en: 'Sivavakkiyar', icon: '⚗️', work: 'சிவவாக்கியம் 500', field: 'பகுத்தறிவு ஞானம்', period: '10ம் நூற்றாண்டு' },
  { n: 5, name: 'பட்டினத்தார்', en: 'Pattinathar', icon: '🌊', work: 'பட்டினத்தார் பாடல்கள்', field: 'வைராக்கியம்', period: '10ம் நூற்றாண்டு' },
  { n: 6, name: 'கோரக்கர்', en: 'Korakkar', icon: '💎', work: 'கோரக்கர் 200', field: 'சித்த வழி', period: '7ம் நூற்றாண்டு' },
  { n: 7, name: 'பாம்பாட்டி சித்தர்', en: 'Paambatti', icon: '🐍', work: 'பாம்பாட்டி சித்தர் பாடல்கள்', field: 'குண்டலினி யோகம்', period: '17ம் நூற்றாண்டு' },
  { n: 8, name: 'கருவூரார்', en: 'Karuvoorar', icon: '⚡', work: 'சித்த மருத்துவ நூல்கள்', field: 'சித்த மருத்துவம்', period: '7ம் நூற்றாண்டு' },
  { n: 9, name: 'இடைக்காடர்', en: 'Idaikadar', icon: '🌾', work: 'இடைக்காடர் பாடல்கள்', field: 'இடையர் ஞானி', period: '8ம் நூற்றாண்டு' },
  { n: 10, name: 'கமலமுனி', en: 'Kamalamuni', icon: '🌺', work: 'மூலிகை ஞான பாடல்கள்', field: 'மூலிகை சித்தர்', period: '9ம் நூற்றாண்டு' },
  { n: 11, name: 'சட்டைமுனி', en: 'Sattaimuni', icon: '🔥', work: 'ஞான நூல்கள்', field: 'தந்த்ரிக ஞானம்', period: '10ம் நூற்றாண்டு' },
  { n: 12, name: 'கொங்கணர்', en: 'Konganar', icon: '🌀', work: 'கொங்கணர் 800', field: 'அஷ்டாங்க யோகம்', period: '9ம் நூற்றாண்டு' },
  { n: 13, name: 'வான்மீகர்', en: 'Vaanmeegar', icon: '🦢', work: 'ஜோதிட ஞான நூல்கள்', field: 'ஜோதிட ஞானம்', period: '8ம் நூற்றாண்டு' },
  { n: 14, name: 'மச்சமுனி', en: 'Machamuni', icon: '🐟', work: 'ஞான நூல்கள்', field: 'கடல் ஞானி', period: '7ம் நூற்றாண்டு' },
  { n: 15, name: 'பதஞ்சலி', en: 'Patanjali', icon: '🧬', work: 'யோக சூத்திரம்', field: 'யோக ஞானம்', period: '2ம் நூற்றாண்டு BCE' },
  { n: 16, name: 'இராமதேவர்', en: 'Ramadevar', icon: '☀️', work: 'ராமதேவர் 800', field: 'சூஃபி-சித்தர் ஞானம்', period: '17ம் நூற்றாண்டு' },
  { n: 17, name: 'குதம்பை சித்தர்', en: 'Kudhambai', icon: '🪔', work: 'குதம்பை பாடல்கள்', field: 'அன்னை சக்தி ஞானம்', period: '14ம் நூற்றாண்டு' },
  { n: 18, name: 'தன்வந்திரி', en: 'Dhanvantri', icon: '💊', work: 'ஆயுர்வேத/சித்த மருத்துவ அடிப்படை', field: 'மருத்துவ சித்தர்', period: 'பண்டைய காலம்' },
];

const SIDDHAR_SONGS = SONGS.filter(s => s.type === 'siddhar');

export default function SiddharsScreen({ navigation }: any) {
  const [selected, setSelected] = useState<number | null>(null);
  const { isFavorite, toggleFavorite } = useApp();

  return (
    <View style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      <ScrollView showsVerticalScrollIndicator={false}>
        <LinearGradient colors={['#181808', '#1A1A08', '#0A0A00']} style={s.header}>
          <Text style={s.glyph}>ஞா</Text>
          <TouchableOpacity onPress={() => navigation.goBack()} style={s.back}>
            <Text style={s.backTxt}>←</Text>
          </TouchableOpacity>
          <Text style={s.icon}>🧘</Text>
          <Text style={s.name}>18 சித்தர்கள்</Text>
          <Text style={s.desc}>தமிழ் நாட்டின் ஞான சித்தர்கள் — யோகம், மருத்துவம், தத்துவம்{'\n'}உடல் நலம், மன நலம், ஆன்மீக நலம் தரும் ஞானிகள்</Text>
          <View style={s.stats}>
            {[['18', 'சித்தர்கள்'], ['10000+', 'பாடல்கள்'], ['3000+', 'ஆண்டுகள்']].map(([n, l]) => (
              <View key={l}><Text style={s.statN}>{n}</Text><Text style={s.statL}>{l}</Text></View>
            ))}
          </View>
        </LinearGradient>

        <SH title="🎵 சித்தர் பாடல்கள்" count={SIDDHAR_SONGS.length} />
        {SIDDHAR_SONGS.map(song => (
          <TouchableOpacity key={song.id} style={s.songCard} onPress={() => navigation.navigate('SongDetail', { songId: song.id })}>
            <View style={[s.songIcon, { backgroundColor: C.siddharBg }]}><Text style={{ fontSize: 22 }}>🧘</Text></View>
            <View style={{ flex: 1 }}>
              <Text style={s.songTitle}>{song.title}</Text>
              <Text style={s.songMeta}>{song.siddharTa || song.type}</Text>
            </View>
            <TouchableOpacity onPress={() => toggleFavorite(song.id)}>
              <Text style={{ fontSize: 16 }}>{isFavorite(song.id) ? '❤️' : '🔖'}</Text>
            </TouchableOpacity>
          </TouchableOpacity>
        ))}

        <SH title="🧘 18 சித்தர்கள் — முழு விவரம்" />
        {SIDDHARS_18.map((sid) => (
          <TouchableOpacity key={sid.n} style={s.siddharCard} onPress={() => setSelected(selected === sid.n ? null : sid.n)} activeOpacity={0.8}>
            <View style={s.siddharHeader}>
              <View style={s.siddharNum}><Text style={s.siddharNumTxt}>{sid.n}</Text></View>
              <Text style={{ fontSize: 24, marginHorizontal: 10 }}>{sid.icon}</Text>
              <View style={{ flex: 1 }}>
                <Text style={s.siddharName}>{sid.name}</Text>
                <Text style={s.siddharEn}>{sid.en} · {sid.field}</Text>
              </View>
              <Text style={s.expandIcon}>{selected === sid.n ? '▲' : '▼'}</Text>
            </View>
            {selected === sid.n && (
              <View style={s.siddharDetail}>
                <View style={s.detailRow}>
                  <Text style={s.detailLabel}>நூல்கள்:</Text>
                  <Text style={s.detailVal}>{sid.work}</Text>
                </View>
                <View style={s.detailRow}>
                  <Text style={s.detailLabel}>காலம்:</Text>
                  <Text style={s.detailVal}>{sid.period}</Text>
                </View>
                <View style={s.detailRow}>
                  <Text style={s.detailLabel}>துறை:</Text>
                  <Text style={s.detailVal}>{sid.field}</Text>
                </View>
              </View>
            )}
          </TouchableOpacity>
        ))}

        <View style={{ height: 80 }} />
      </ScrollView>
    </View>
  );
}

function SH({ title, count }: { title: string; count?: number }) {
  return (
    <View style={s.sh}>
      <Text style={s.shTitle}>{title}</Text>
      {count !== undefined && <Text style={s.shCount}>{count}</Text>}
      <View style={s.shLine} />
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  header: { paddingTop: 50, paddingBottom: 22, paddingHorizontal: S.lg, position: 'relative' },
  glyph: { position: 'absolute', right: -5, bottom: -15, fontSize: 100, color: 'rgba(212,168,32,0.05)' },
  back: { position: 'absolute', top: 50, left: S.lg, width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(212,168,32,0.15)', borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center', zIndex: 10 },
  backTxt: { color: C.gold, fontSize: 18, fontWeight: '700' },
  icon: { fontSize: 52, marginBottom: 10, marginTop: 40 },
  name: { color: C.gold, fontSize: 24, fontWeight: '700', marginBottom: 5 },
  desc: { color: C.txt2, fontSize: 12, lineHeight: 20 },
  stats: { flexDirection: 'row', gap: 18, marginTop: 14 },
  statN: { color: C.saffron, fontSize: 20, fontWeight: '700' },
  statL: { color: C.txt3, fontSize: 9 },
  sh: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: S.lg, paddingTop: 18, paddingBottom: 10 },
  shTitle: { color: C.gold, fontSize: 14, fontWeight: '700' },
  shCount: { color: C.txt3, fontSize: 10 },
  shLine: { flex: 1, height: 1, backgroundColor: C.border },
  songCard: { flexDirection: 'row', backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border2, padding: 13, marginHorizontal: S.lg, marginBottom: 9, alignItems: 'center', gap: 12 },
  songIcon: { width: 42, height: 42, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  songTitle: { color: C.txt, fontSize: 13.5, fontWeight: '600' },
  songMeta: { color: C.txt3, fontSize: 11 },
  siddharCard: { backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border2, marginHorizontal: S.lg, marginBottom: 8, overflow: 'hidden' },
  siddharHeader: { flexDirection: 'row', alignItems: 'center', padding: 13 },
  siddharNum: { width: 28, height: 28, borderRadius: 14, backgroundColor: 'rgba(212,168,32,0.15)', alignItems: 'center', justifyContent: 'center' },
  siddharNumTxt: { color: C.gold, fontSize: 11, fontWeight: '700' },
  siddharName: { color: C.txt, fontSize: 14, fontWeight: '600' },
  siddharEn: { color: C.txt3, fontSize: 10, marginTop: 1 },
  expandIcon: { color: C.txt3, fontSize: 10 },
  siddharDetail: { backgroundColor: C.bg3, padding: 13, borderTopWidth: 1, borderTopColor: C.border2 },
  detailRow: { flexDirection: 'row', marginBottom: 6 },
  detailLabel: { color: C.txt3, fontSize: 11, width: 60 },
  detailVal: { color: C.txt2, fontSize: 11, flex: 1, lineHeight: 18 },
});
