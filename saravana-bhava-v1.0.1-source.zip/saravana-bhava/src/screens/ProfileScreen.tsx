import React, { useState, useEffect } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  StatusBar, TextInput, Alert,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { C, S, R } from '../utils/theme';
import { SONGS } from '../data/songs';
import { useApp } from '../context/AppContext';

const DEVOTION_LEVELS = [
  { min: 0, max: 4, title: 'பக்தி தொடக்கம்', titleEn: 'Beginner Devotee', icon: '🌱', color: '#66BB6A' },
  { min: 5, max: 9, title: 'பக்தி வளர்ச்சி', titleEn: 'Growing Devotee', icon: '🌿', color: '#42A5F5' },
  { min: 10, max: 14, title: 'திருப்புகழ் பக்தர்', titleEn: 'Thiruppugazh Devotee', icon: '🌟', color: C.gold },
  { min: 15, max: 19, title: 'ஞான சாதகர்', titleEn: 'Wisdom Seeker', icon: '🔥', color: C.saffron },
  { min: 20, max: 999, title: 'சித்தர் நிலை', titleEn: 'Siddhar Level', icon: '🧘', color: '#CE93D8' },
];

export default function ProfileScreen({ navigation }: any) {
  const { favorites, readingStreak } = useApp();
  const [name, setName] = useState('பக்தர்');
  const [editingName, setEditingName] = useState(false);
  const [tempName, setTempName] = useState('');
  const [quizHighScore, setQuizHighScore] = useState(0);
  const [totalSongsRead, setTotalSongsRead] = useState(0);
  const [joinDate, setJoinDate] = useState('');

  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = async () => {
    try {
      const [n, qs, sr, jd] = await Promise.all([
        AsyncStorage.getItem('sb_profile_name'),
        AsyncStorage.getItem('sb_quiz_highscore'),
        AsyncStorage.getItem('sb_recent'),
        AsyncStorage.getItem('sb_join_date'),
      ]);
      if (n) setName(n);
      if (qs) setQuizHighScore(parseInt(qs));
      if (sr) setTotalSongsRead(JSON.parse(sr).length);
      if (jd) {
        setJoinDate(jd);
      } else {
        const today = new Date().toLocaleDateString('ta-IN');
        setJoinDate(today);
        await AsyncStorage.setItem('sb_join_date', today);
      }
    } catch {}
  };

  const saveName = async () => {
    if (tempName.trim()) {
      setName(tempName.trim());
      await AsyncStorage.setItem('sb_profile_name', tempName.trim());
    }
    setEditingName(false);
  };

  const totalSongs = SONGS.length;
  const level = DEVOTION_LEVELS.find(l => readingStreak >= l.min && readingStreak <= l.max) || DEVOTION_LEVELS[0];

  const stats = [
    { icon: '🔥', value: readingStreak, label: 'நாள் தொடர்ச்சி' },
    { icon: '❤️', value: favorites.length, label: 'சேமிக்கப்பட்டவை' },
    { icon: '📖', value: totalSongsRead, label: 'படித்தவை' },
    { icon: '🎯', value: quizHighScore, label: 'சிறந்த மதிப்பெண்' },
  ];

  const progress = Math.min((readingStreak / 20) * 100, 100);

  return (
    <View style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      <View style={s.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={s.back}>
          <Text style={s.backTxt}>←</Text>
        </TouchableOpacity>
        <Text style={s.headerTitle}>👤 சுயவிவரம்</Text>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.content}>
        {/* Avatar & Name */}
        <View style={s.avatarSection}>
          <View style={s.avatar}>
            <Text style={s.avatarIcon}>{level.icon}</Text>
          </View>
          {editingName ? (
            <View style={s.nameEdit}>
              <TextInput
                style={s.nameInput}
                value={tempName}
                onChangeText={setTempName}
                placeholder="உங்கள் பெயர்"
                placeholderTextColor={C.txt3}
                autoFocus
                maxLength={30}
              />
              <TouchableOpacity style={s.saveBtn} onPress={saveName}>
                <Text style={s.saveBtnTxt}>சேமி</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <TouchableOpacity onPress={() => { setTempName(name); setEditingName(true); }}>
              <Text style={s.name}>{name} ✏️</Text>
            </TouchableOpacity>
          )}
          <View style={[s.levelBadge, { backgroundColor: level.color + '22', borderColor: level.color + '44' }]}>
            <Text style={[s.levelTxt, { color: level.color }]}>{level.title}</Text>
          </View>
          <Text style={s.joinDate}>சேர்ந்த தேதி: {joinDate}</Text>
        </View>

        {/* Progress to Next Level */}
        <View style={s.progressCard}>
          <View style={s.progressHeader}>
            <Text style={s.progressTitle}>அடுத்த நிலைக்கு</Text>
            <Text style={s.progressPct}>{Math.round(progress)}%</Text>
          </View>
          <View style={s.progressBar}>
            <View style={[s.progressFill, { width: `${progress}%`, backgroundColor: level.color }]} />
          </View>
          <Text style={s.progressHint}>{20 - Math.min(readingStreak, 20)} நாள் தொடர்ச்சி மேலும் தேவை</Text>
        </View>

        {/* Stats Grid */}
        <Text style={s.sectionTitle}>📊 உங்கள் புள்ளிவிவரங்கள்</Text>
        <View style={s.statsGrid}>
          {stats.map((st, i) => (
            <View key={i} style={s.statCard}>
              <Text style={s.statIcon}>{st.icon}</Text>
              <Text style={s.statValue}>{st.value}</Text>
              <Text style={s.statLabel}>{st.label}</Text>
            </View>
          ))}
        </View>

        {/* Reading Progress */}
        <Text style={s.sectionTitle}>📚 படிப்பு முன்னேற்றம்</Text>
        <View style={s.readingCard}>
          <View style={s.readingRow}>
            <Text style={s.readingLabel}>மொத்த பாடல்கள்</Text>
            <Text style={s.readingValue}>{totalSongs}</Text>
          </View>
          <View style={s.readingRow}>
            <Text style={s.readingLabel}>படித்தவை</Text>
            <Text style={s.readingValue}>{totalSongsRead}</Text>
          </View>
          <View style={s.readingRow}>
            <Text style={s.readingLabel}>சேமிக்கப்பட்டவை</Text>
            <Text style={s.readingValue}>{favorites.length}</Text>
          </View>
          <View style={s.readingProgressBar}>
            <View style={[s.readingProgressFill, { width: `${(totalSongsRead / totalSongs) * 100}%` }]} />
          </View>
          <Text style={s.readingProgressTxt}>{Math.round((totalSongsRead / totalSongs) * 100)}% முடிந்தது</Text>
        </View>

        {/* Quick Actions */}
        <Text style={s.sectionTitle}>⚡ விரைவு செயல்கள்</Text>
        <View style={s.actionsGrid}>
          {[
            { icon: '🎯', label: 'வினாடி வினா', onPress: () => navigation.navigate('Quiz') },
            { icon: '🏆', label: 'சாதனைகள்', onPress: () => navigation.navigate('Achievements') },
            { icon: '🎁', label: 'வெகுமதிகள்', onPress: () => navigation.navigate('Rewards') },
            { icon: '📚', label: 'நூலகம்', onPress: () => navigation.navigate('Library') },
          ].map((a, i) => (
            <TouchableOpacity key={i} style={s.actionCard} onPress={a.onPress}>
              <Text style={s.actionIcon}>{a.icon}</Text>
              <Text style={s.actionLabel}>{a.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={{ height: 80 }} />
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  header: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: S.lg, paddingTop: 52, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: C.border2 },
  back: { width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(212,168,32,0.15)', borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center' },
  backTxt: { color: C.gold, fontSize: 18, fontWeight: '700' },
  headerTitle: { color: C.gold, fontSize: 18, fontWeight: '700' },
  content: { paddingHorizontal: S.lg, paddingTop: S.lg },
  avatarSection: { alignItems: 'center', paddingVertical: 24 },
  avatar: { width: 90, height: 90, borderRadius: 45, backgroundColor: C.card, borderWidth: 2, borderColor: C.border, alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  avatarIcon: { fontSize: 44 },
  name: { color: C.txt, fontSize: 20, fontWeight: '700', marginBottom: 8 },
  nameEdit: { flexDirection: 'row', gap: 8, marginBottom: 8 },
  nameInput: { backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: R.md, paddingHorizontal: 12, paddingVertical: 8, color: C.txt, fontSize: 16, minWidth: 160 },
  saveBtn: { backgroundColor: C.saffron, borderRadius: R.md, paddingHorizontal: 16, paddingVertical: 8, justifyContent: 'center' },
  saveBtnTxt: { color: '#fff', fontWeight: '700' },
  levelBadge: { borderWidth: 1, borderRadius: 20, paddingHorizontal: 14, paddingVertical: 5, marginBottom: 6 },
  levelTxt: { fontSize: 12, fontWeight: '600' },
  joinDate: { color: C.txt3, fontSize: 11 },
  progressCard: { backgroundColor: C.card, borderRadius: R.lg, borderWidth: 1, borderColor: C.border, padding: S.lg, marginBottom: 20 },
  progressHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 },
  progressTitle: { color: C.txt, fontSize: 14, fontWeight: '600' },
  progressPct: { color: C.saffron, fontSize: 14, fontWeight: '700' },
  progressBar: { height: 8, backgroundColor: C.bg3, borderRadius: 4, overflow: 'hidden', marginBottom: 8 },
  progressFill: { height: '100%', borderRadius: 4 },
  progressHint: { color: C.txt3, fontSize: 11 },
  sectionTitle: { color: C.txt3, fontSize: 11, letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 12, marginTop: 4 },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  statCard: { width: '47%', backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border, padding: S.lg, alignItems: 'center' },
  statIcon: { fontSize: 28, marginBottom: 6 },
  statValue: { color: C.saffron, fontSize: 28, fontWeight: '700' },
  statLabel: { color: C.txt3, fontSize: 10, marginTop: 2, textAlign: 'center' },
  readingCard: { backgroundColor: C.card, borderRadius: R.lg, borderWidth: 1, borderColor: C.border, padding: S.lg, marginBottom: 20 },
  readingRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: C.border2 },
  readingLabel: { color: C.txt2, fontSize: 13 },
  readingValue: { color: C.txt, fontSize: 13, fontWeight: '600' },
  readingProgressBar: { height: 6, backgroundColor: C.bg3, borderRadius: 3, overflow: 'hidden', marginTop: 12, marginBottom: 6 },
  readingProgressFill: { height: '100%', backgroundColor: C.gold, borderRadius: 3 },
  readingProgressTxt: { color: C.txt3, fontSize: 11 },
  actionsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  actionCard: { width: '47%', backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border, padding: S.lg, alignItems: 'center', gap: 8 },
  actionIcon: { fontSize: 32 },
  actionLabel: { color: C.txt, fontSize: 12, fontWeight: '600' },
});
