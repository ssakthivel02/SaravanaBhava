import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, StatusBar } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { C, S, R } from '../utils/theme';
import { SONGS } from '../data/songs';
import { useApp } from '../context/AppContext';

const MOODS = ['பக்தி', 'காப்பு', 'ஞானம்', 'குணமடைதல்'];
const MOOD_MAP: Record<string, string> = { 'பக்தி': 'bhakti', 'காப்பு': 'protection', 'ஞானம்': 'wisdom', 'குணமடைதல்': 'healing' };

export default function MuruganScreen({ navigation }: any) {
  const [mood, setMood] = useState('பக்தி');
  const { isFavorite, toggleFavorite } = useApp();

  const songs = SONGS.filter(s => s.god === 'murugan' && s.theme === MOOD_MAP[mood]);

  return (
    <View style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      <ScrollView showsVerticalScrollIndicator={false}>
        <LinearGradient colors={['#071A0E', '#0D2818', '#120A00']} style={s.header}>
          <Text style={s.headerGlyph}>வேல்</Text>
          <TouchableOpacity onPress={() => navigation.goBack()} style={s.backBtn}>
            <Text style={s.backBtnTxt}>←</Text>
          </TouchableOpacity>
          <Text style={s.icon}>🦚</Text>
          <Text style={s.name}>முருகன்</Text>
          <Text style={s.desc}>ஆறுமுகன் · குகன் · கந்தன் · வேலவன் · கார்த்திகேயன்{'\n'}ஞானம், வீரம், அருள் சொரியும் தெய்வம்</Text>
          <View style={s.stats}>
            {[['15', 'நூல்கள்'], ['1300+', 'பாடல்கள்'], ['6', 'படைவீடுகள்']].map(([n, l]) => (
              <View key={l}><Text style={s.statNum}>{n}</Text><Text style={s.statLbl}>{l}</Text></View>
            ))}
          </View>
        </LinearGradient>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.moodRow}>
          {MOODS.map(m => (
            <TouchableOpacity key={m} style={[s.moodChip, mood === m && s.moodChipOn]} onPress={() => setMood(m)}>
              <Text style={[s.moodChipTxt, mood === m && s.moodChipTxtOn]}>{m}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <SH title="🎵 பாடல்கள்" count={songs.length} />
        {songs.length === 0 ? (
          <Text style={s.noSongs}>இந்த வகையில் பாடல்கள் விரைவில் சேர்க்கப்படும்</Text>
        ) : songs.map(song => (
          <TouchableOpacity key={song.id} style={s.songCard} onPress={() => navigation.navigate('SongDetail', { songId: song.id })}>
            <View style={[s.songIcon, { backgroundColor: C.muruganBg }]}><Text style={{ fontSize: 22 }}>🦚</Text></View>
            <View style={{ flex: 1 }}>
              <Text style={s.songTitle}>{song.title}</Text>
              <Text style={s.songMeta}>{song.temple || song.type}</Text>
            </View>
            <TouchableOpacity onPress={() => toggleFavorite(song.id)}>
              <Text style={{ fontSize: 16 }}>{isFavorite(song.id) ? '❤️' : '🔖'}</Text>
            </TouchableOpacity>
          </TouchableOpacity>
        ))}

        <SH title="🛕 ஆறு படைவீடுகள்" />
        {TEMPLES.map((t, i) => (
          <View key={i} style={s.templeCard}>
            <Text style={s.templeNum}>{i + 1}</Text>
            <View style={{ flex: 1 }}>
              <Text style={s.templeName}>{t.icon} {t.name}</Text>
              <Text style={s.templeLoc}>{t.loc}</Text>
              <Text style={s.templeDetail}>{t.detail}</Text>
            </View>
          </View>
        ))}

        <SH title="🧘 18 சித்தர்கள்" />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: S.lg, gap: S.sm }}>
          {SIDDHARS.map(sid => (
            <View key={sid.en} style={s.siddharCard}>
              <Text style={{ fontSize: 28, marginBottom: 6 }}>{sid.icon}</Text>
              <Text style={s.siddharName}>{sid.name}</Text>
              <Text style={s.siddharDesc}>{sid.desc}</Text>
              <Text style={s.siddharCount}>{sid.count}</Text>
            </View>
          ))}
        </ScrollView>

        <View style={{ height: 80 }} />
      </ScrollView>
    </View>
  );
}

function SH({ title, count }: { title: string; count?: number }) {
  return (
    <View style={s.sh}>
      <Text style={s.shTitle}>{title}</Text>
      {count !== undefined && <Text style={s.shCount}>{count}</Text>}
      <View style={s.shLine} />
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  header: { paddingTop: 50, paddingBottom: 22, paddingHorizontal: S.lg, position: 'relative' },
  headerGlyph: { position: 'absolute', right: -5, bottom: -15, fontSize: 100, color: 'rgba(212,168,32,0.05)' },
  backBtn: { position: 'absolute', top: 50, left: S.lg, width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(212,168,32,0.15)', borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center', zIndex: 10 },
  backBtnTxt: { color: C.saffron, fontSize: 18, fontWeight: '700' },
  icon: { fontSize: 52, marginBottom: 10, marginTop: 40 },
  name: { color: '#66BB6A', fontSize: 24, fontWeight: '700', marginBottom: 5 },
  desc: { color: C.txt2, fontSize: 12, lineHeight: 20 },
  stats: { flexDirection: 'row', gap: 18, marginTop: 14 },
  statNum: { color: C.saffron, fontSize: 20, fontWeight: '700' },
  statLbl: { color: C.txt3, fontSize: 9 },
  moodRow: { paddingHorizontal: S.lg, gap: 7, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: C.border2 },
  moodChip: { paddingHorizontal: 13, paddingVertical: 6, borderRadius: 20, borderWidth: 1, borderColor: 'rgba(240,106,10,0.3)' },
  moodChipOn: { backgroundColor: C.saffron, borderColor: C.saffron },
  moodChipTxt: { color: C.saffron, fontSize: 11 },
  moodChipTxtOn: { color: '#fff' },
  sh: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: S.lg, paddingTop: 18, paddingBottom: 10 },
  shTitle: { color: C.gold, fontSize: 14, fontWeight: '700' },
  shCount: { color: C.txt3, fontSize: 10 },
  shLine: { flex: 1, height: 1, backgroundColor: C.border },
  noSongs: { color: C.txt3, fontSize: 12, textAlign: 'center', paddingVertical: 20 },
  songCard: { flexDirection: 'row', backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border2, padding: 13, marginHorizontal: S.lg, marginBottom: 9, alignItems: 'center', gap: 12 },
  songIcon: { width: 42, height: 42, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  songTitle: { color: C.txt, fontSize: 13.5, fontWeight: '600' },
  songMeta: { color: C.txt3, fontSize: 11 },
  templeCard: { flexDirection: 'row', backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border2, padding: 13, marginHorizontal: S.lg, marginBottom: 9, gap: 12, alignItems: 'flex-start' },
  templeNum: { color: C.saffron, fontSize: 20, fontWeight: '700', minWidth: 24 },
  templeName: { color: C.txt, fontSize: 14, fontWeight: '600', marginBottom: 3 },
  templeLoc: { color: C.txt3, fontSize: 11, marginBottom: 2 },
  templeDetail: { color: C.gold, fontSize: 10 },
  siddharCard: { width: 130, backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border, padding: 13 },
  siddharName: { color: C.txt, fontSize: 12, fontWeight: '600', marginBottom: 3 },
  siddharDesc: { color: C.txt3, fontSize: 10, marginBottom: 4 },
  siddharCount: { color: C.saffron, fontSize: 9.5 },
});
