import React, { useState, useEffect, useRef } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, StatusBar, Animated } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { C, S, R } from '../utils/theme';
import { SONGS } from '../data/songs';
import { useApp } from '../context/AppContext';

const HERO = [
  { title: 'முருகன் – வேலவன்\nஆறுமுக அருட்கடல்', sub: 'திருப்புகழ் · கந்தர் சஷ்டி · திருமுருகாற்றுப்படை', badge: '✦ இன்றைய தெய்வம்', glyph: 'வேல்', colors: ['#071A0E', '#0D2818', '#1A0E00'] as const, page: 'Murugan' },
  { title: 'சிவன் – நடராஜன்\nஆனந்த தாண்டவம்', sub: 'தேவாரம் · திருவாசகம் · திருமந்திரம்', badge: '✦ சிவ பக்தி', glyph: 'நம', colors: ['#05051A', '#0D0D30', '#1A0800'] as const, page: 'Shiva' },
  { title: 'சக்தி – ஆதி பராசக்தி\nகாஞ்சி காமாட்சி', sub: 'அபிராமி அந்தாதி · லலிதா சஹஸ்ரநாமம்', badge: '✦ சக்தி பக்தி', glyph: 'சக்', colors: ['#1A0510', '#2D0820', '#1A0500'] as const, page: 'Sakthi' },
];

const DAILY_VERSE_IDS = ['tp01', 'tp02', 'trm01', 'ksk01', 'tp04', 'tp06'];

// All God cards with their registered navigation routes
const GOD_CARDS = [
  { icon: '🦚', name: 'முருகன்', bg: '#0E2A18', page: 'Murugan' },
  { icon: '🌙', name: 'சிவன்', bg: '#0E0E38', page: 'Shiva' },
  { icon: '🌸', name: 'பெருமாள்', bg: '#0A1E38', page: 'Perumal' },
  { icon: '🔱', name: 'சக்தி', bg: '#300820', page: 'Sakthi' },
  { icon: '🧘', name: 'சித்தர்கள்', bg: '#181808', page: 'Siddhars' },
  { icon: '🐘', name: 'விநாயகர்', bg: '#3A2000', page: 'Vinayagar' },
];

export default function HomeScreen({ navigation }: any) {
  const { readingStreak } = useApp();
  const [heroIdx, setHeroIdx] = useState(0);
  const fadeAnim = useRef(new Animated.Value(1)).current;

  const day = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000);
  const todayVerseId = DAILY_VERSE_IDS[day % DAILY_VERSE_IDS.length];
  const todayVerse = SONGS.find(s => s.id === todayVerseId) || SONGS[0];
  const todayTemple = TEMPLES[day % TEMPLES.length];
  const todayMantra = MANTRAS[day % MANTRAS.length];

  useEffect(() => {
    const interval = setInterval(() => {
      Animated.timing(fadeAnim, { toValue: 0, duration: 400, useNativeDriver: true }).start(() => {
        setHeroIdx(p => (p + 1) % HERO.length);
        Animated.timing(fadeAnim, { toValue: 1, duration: 400, useNativeDriver: true }).start();
      });
    }, 4500);
    return () => clearInterval(interval);
  }, []);

  const muruganSongs = SONGS.filter(s => s.god === 'murugan').slice(0, 5);
  const siddharSongs = SONGS.filter(s => s.type === 'siddhar').slice(0, 2);
  const DAYS = ['ஞா', 'தி', 'செ', 'பு', 'வி', 'வெ', 'ச'];
  const today = new Date().getDay();

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      <View style={styles.topBar}>
        <View>
          <Text style={styles.topBarTitle}>சரவண பவ</Text>
          <Text style={styles.topBarSub}>Murugan Bhakti Library</Text>
        </View>
        <View style={styles.topBarRight}>
          <TouchableOpacity style={styles.topBarBtn} onPress={() => navigation.navigate('Profile')}>
            <Text style={styles.topBarBtnText}>👤</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.topBarBtn} onPress={() => navigation.navigate('Library')}>
            <Text style={styles.topBarBtnText}>🔍</Text>
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Hero — tappable to god page */}
        <TouchableOpacity activeOpacity={0.9} onPress={() => navigation.navigate(HERO[heroIdx].page)}>
          <Animated.View style={{ opacity: fadeAnim }}>
            <LinearGradient colors={HERO[heroIdx].colors} style={styles.hero}>
              <Text style={styles.heroGlyph}>{HERO[heroIdx].glyph}</Text>
              <View style={styles.heroBadge}><Text style={styles.heroBadgeText}>{HERO[heroIdx].badge}</Text></View>
              <Text style={styles.heroTitle}>{HERO[heroIdx].title}</Text>
              <Text style={styles.heroSub}>{HERO[heroIdx].sub}</Text>
              <View style={styles.heroDots}>
                {HERO.map((_, i) => <View key={i} style={[styles.dot, i === heroIdx && styles.dotActive]} />)}
              </View>
            </LinearGradient>
          </Animated.View>
        </TouchableOpacity>

        {/* Daily Cards */}
        <SH title="✨ இன்றைய தரிசனம்" />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.row}>
          <TouchableOpacity style={styles.dailyCard} onPress={() => navigation.navigate('SongDetail', { songId: todayVerse.id })}>
            <Text style={styles.dailyLabel}>இன்றைய வசனம்</Text>
            <Text style={styles.dailyIcon}>📿</Text>
            <Text style={styles.dailyText} numberOfLines={2}>{todayVerse.original.split('\n')[0]}…</Text>
            <Text style={styles.dailySub}>{todayVerse.type}</Text>
          </TouchableOpacity>
          <View style={styles.dailyCard}>
            <Text style={styles.dailyLabel}>இன்றைய கோயில்</Text>
            <Text style={styles.dailyIcon}>🛕</Text>
            <Text style={styles.dailyText}>{todayTemple.name}</Text>
            <Text style={styles.dailySub}>{todayTemple.badge}</Text>
          </View>
          <View style={styles.dailyCard}>
            <Text style={styles.dailyLabel}>இன்றைய மந்திரம்</Text>
            <Text style={styles.dailyIcon}>🔱</Text>
            <Text style={styles.dailyText} numberOfLines={2}>{todayMantra.name}</Text>
            <Text style={styles.dailySub}>{todayMantra.deity}</Text>
          </View>
          <TouchableOpacity style={styles.dailyCard} onPress={() => navigation.navigate('Quiz')}>
            <Text style={styles.dailyLabel}>வினாடி வினா</Text>
            <Text style={styles.dailyIcon}>🎯</Text>
            <Text style={styles.dailyText}>பக்தி வினாடி வினா</Text>
            <Text style={styles.dailySub}>விளையாடு →</Text>
          </TouchableOpacity>
        </ScrollView>

        {/* Streak */}
        <SH title="🔥 படிப்பு தொடர்ச்சி" />
        <View style={styles.streakCard}>
          <View style={styles.streakTop}>
            <View>
              <Text style={styles.streakNum}>{readingStreak}</Text>
              <Text style={styles.streakLabel}>நாள் தொடர்ச்சி</Text>
            </View>
            <View style={styles.streakRight}>
              <Text style={{ fontSize: 36 }}>🔥</Text>
              <TouchableOpacity style={styles.rewardsBtn} onPress={() => navigation.navigate('Rewards')}>
                <Text style={styles.rewardsBtnTxt}>🎁 வெகுமதி</Text>
              </TouchableOpacity>
            </View>
          </View>
          <View style={styles.streakDays}>
            {DAYS.map((d, i) => (
              <View key={i} style={[styles.streakDay, i <= today && styles.streakDayOn]}>
                <Text style={[styles.streakDayTxt, i <= today && styles.streakDayTxtOn]}>{d}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Gods — ALL WIRED */}
        <SH title="🙏 தெய்வங்கள்" />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.row}>
          {GOD_CARDS.map(g => (
            <TouchableOpacity
              key={g.name}
              style={styles.godCard}
              onPress={() => navigation.navigate(g.page)}
              activeOpacity={0.8}
            >
              <View style={[styles.godCircle, { backgroundColor: g.bg }]}>
                <Text style={{ fontSize: 32 }}>{g.icon}</Text>
              </View>
              <Text style={styles.godName}>{g.name}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Featured Songs */}
        <SH title="⭐ திருப்புகழ் பாடல்கள்" />
        {muruganSongs.map(s => <SongCard key={s.id} song={s} navigation={navigation} />)}

        {/* Siddhar */}
        <SH title="🧘 சித்தர் ஞானம்" />
        {siddharSongs.map(s => <SongCard key={s.id} song={s} navigation={navigation} />)}

        {/* Temples */}
        <SH title="🛕 ஆறு படைவீடுகள்" />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.row}>
          {TEMPLES.map((t, i) => (
            <TouchableOpacity key={i} style={styles.templeCard} onPress={() => navigation.navigate('Murugan')}>
              <Text style={{ fontSize: 28, marginBottom: 6 }}>{t.icon}</Text>
              <Text style={styles.templeName}>{t.name}</Text>
              <Text style={styles.templeLoc}>{t.loc}</Text>
              <View style={styles.templeBadge}><Text style={styles.templeBadgeTxt}>{t.badge}</Text></View>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Feature Row */}
        <SH title="🎮 விளையாட்டு & சாதனைகள்" />
        <View style={styles.featureRow}>
          {[
            { icon: '🎯', label: 'வினாடி வினா', sub: '15 கேள்விகள்', page: 'Quiz', color: C.muruganBg },
            { icon: '🏆', label: 'சாதனைகள்', sub: '14 சாதனைகள்', page: 'Achievements', color: '#1A1A08' },
            { icon: '🎁', label: 'வெகுமதிகள்', sub: 'தினசரி பரிசு', page: 'Rewards', color: '#1A0510' },
            { icon: '👤', label: 'சுயவிவரம்', sub: 'உங்கள் பக்தி', page: 'Profile', color: '#0A1E38' },
          ].map(f => (
            <TouchableOpacity key={f.page} style={[styles.featureCard, { backgroundColor: f.color }]} onPress={() => navigation.navigate(f.page)}>
              <Text style={styles.featureIcon}>{f.icon}</Text>
              <Text style={styles.featureLabel}>{f.label}</Text>
              <Text style={styles.featureSub}>{f.sub}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={{ height: 80 }} />
      </ScrollView>
    </View>
  );
}

function SH({ title }: { title: string }) {
  return (
    <View style={styles.sh}>
      <Text style={styles.shTitle}>{title}</Text>
      <View style={styles.shLine} />
    </View>
  );
}

function SongCard({ song, navigation }: { song: any; navigation: any }) {
  const { isFavorite, toggleFavorite } = useApp();
  const fav = isFavorite(song.id);
  const godBg: Record<string, string> = { murugan: C.muruganBg, shiva: C.shivaBg, perumal: C.perumalBg, sakthi: C.sakthiBg, vinayagar: '#3A2000' };
  const godIcon: Record<string, string> = { murugan: '🦚', shiva: '🌙', perumal: '🌸', sakthi: '🔱', vinayagar: '🐘' };
  return (
    <TouchableOpacity style={styles.songCard} onPress={() => navigation.navigate('SongDetail', { songId: song.id })} activeOpacity={0.8}>
      <View style={[styles.songIcon, { backgroundColor: godBg[song.god] || C.card }]}>
        <Text style={{ fontSize: 22 }}>{godIcon[song.god] || '🎵'}</Text>
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.songTitle}>{song.title}</Text>
        <Text style={styles.songMeta}>{song.temple || song.siddharTa || song.type}</Text>
        <View style={styles.tags}>
          {song.tags.slice(0, 2).map((t: string) => (
            <View key={t} style={styles.tag}><Text style={styles.tagTxt}>{t}</Text></View>
          ))}
        </View>
      </View>
      <TouchableOpacity onPress={() => toggleFavorite(song.id)}>
        <Text style={{ fontSize: 16 }}>{fav ? '❤️' : '🔖'}</Text>
      </TouchableOpacity>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  topBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: S.lg, paddingTop: 52, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: C.border2 },
  topBarTitle: { color: C.gold, fontSize: 18, fontWeight: '700' },
  topBarSub: { color: C.txt3, fontSize: 10 },
  topBarRight: { flexDirection: 'row', gap: 8 },
  topBarBtn: { width: 36, height: 36, borderRadius: 18, borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center' },
  topBarBtnText: { fontSize: 16 },
  hero: { height: 200, padding: S.xl, justifyContent: 'flex-end', position: 'relative' },
  heroGlyph: { position: 'absolute', right: -10, top: -20, fontSize: 130, color: 'rgba(212,168,32,0.05)' },
  heroBadge: { backgroundColor: 'rgba(212,168,32,0.15)', borderWidth: 1, borderColor: C.border, borderRadius: 20, paddingHorizontal: 10, paddingVertical: 4, alignSelf: 'flex-start', marginBottom: 8 },
  heroBadgeText: { color: C.gold, fontSize: 9, letterSpacing: 1.5 },
  heroTitle: { color: C.gold3, fontSize: 20, fontWeight: '700', lineHeight: 28 },
  heroSub: { color: C.txt2, fontSize: 11, marginTop: 4 },
  heroDots: { flexDirection: 'row', gap: 5, marginTop: 10 },
  dot: { width: 20, height: 3, borderRadius: 2, backgroundColor: C.border },
  dotActive: { backgroundColor: C.gold, width: 30 },
  sh: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: S.lg, paddingTop: 18, paddingBottom: 10 },
  shTitle: { color: C.gold, fontSize: 14, fontWeight: '700' },
  shLine: { flex: 1, height: 1, backgroundColor: C.border },
  row: { paddingHorizontal: S.lg, gap: S.sm },
  dailyCard: { width: 150, backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border, padding: 13 },
  dailyLabel: { color: C.saffron, fontSize: 8.5, letterSpacing: 1.5, marginBottom: 6 },
  dailyIcon: { fontSize: 24, marginBottom: 6 },
  dailyText: { color: C.txt, fontSize: 12, lineHeight: 19 },
  dailySub: { color: C.txt2, fontSize: 10, marginTop: 4 },
  streakCard: { marginHorizontal: S.lg, backgroundColor: C.card, borderRadius: R.lg, borderWidth: 1, borderColor: C.border, padding: S.lg },
  streakTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  streakNum: { fontSize: 36, fontWeight: '700', color: C.saffron },
  streakLabel: { color: C.txt2, fontSize: 12 },
  streakRight: { alignItems: 'flex-end', gap: 8 },
  rewardsBtn: { backgroundColor: 'rgba(212,168,32,0.15)', borderRadius: 20, paddingHorizontal: 12, paddingVertical: 5, borderWidth: 1, borderColor: C.border },
  rewardsBtnTxt: { color: C.gold, fontSize: 11, fontWeight: '600' },
  streakDays: { flexDirection: 'row', gap: 6 },
  streakDay: { width: 36, height: 36, borderRadius: R.sm, backgroundColor: C.bg3, alignItems: 'center', justifyContent: 'center' },
  streakDayOn: { backgroundColor: C.saffron },
  streakDayTxt: { color: C.txt3, fontSize: 11 },
  streakDayTxtOn: { color: '#fff' },
  godCard: { alignItems: 'center', gap: 8, width: 80 },
  godCircle: { width: 72, height: 72, borderRadius: 36, alignItems: 'center', justifyContent: 'center', borderWidth: 1.5, borderColor: C.border },
  godName: { color: C.txt2, fontSize: 11, textAlign: 'center' },
  songCard: { flexDirection: 'row', backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border2, padding: 13, marginHorizontal: S.lg, marginBottom: 9, alignItems: 'flex-start', gap: 12 },
  songIcon: { width: 42, height: 42, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  songTitle: { color: C.txt, fontSize: 13.5, fontWeight: '600', marginBottom: 2 },
  songMeta: { color: C.txt3, fontSize: 11 },
  tags: { flexDirection: 'row', gap: 5, marginTop: 6, flexWrap: 'wrap' },
  tag: { backgroundColor: 'rgba(212,168,32,0.07)', borderWidth: 1, borderColor: 'rgba(212,168,32,0.25)', borderRadius: 10, paddingHorizontal: 8, paddingVertical: 2 },
  tagTxt: { color: C.gold, fontSize: 9.5 },
  templeCard: { width: 160, backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border, padding: 13 },
  templeName: { color: C.txt, fontSize: 13, fontWeight: '600', marginBottom: 3 },
  templeLoc: { color: C.txt3, fontSize: 10, marginBottom: 6 },
  templeBadge: { backgroundColor: C.saffronGlow, borderRadius: 10, paddingHorizontal: 8, paddingVertical: 3, alignSelf: 'flex-start' },
  templeBadgeTxt: { color: C.saffron, fontSize: 9 },
  featureRow: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: S.lg, gap: 10 },
  featureCard: { width: '47%', borderRadius: R.md, borderWidth: 1, borderColor: C.border2, padding: 16, alignItems: 'center', gap: 4 },
  featureIcon: { fontSize: 32, marginBottom: 4 },
  featureLabel: { color: C.txt, fontSize: 13, fontWeight: '700' },
  featureSub: { color: C.txt3, fontSize: 10 },
});
