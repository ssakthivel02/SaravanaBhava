import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, StatusBar } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { C, S, R } from '../utils/theme';
import { SONGS } from '../data/songs';
import { useApp } from '../context/AppContext';

const PERUMAL_BOOKS = [
  { icon: '🌺', title: 'நாலாயிர திவ்யப்பிரபந்தம்', author: '12 ஆழ்வார்கள்', count: '4000 பாசுரங்கள்', desc: 'வைஷ்ணவ சமயத்தின் திருமறை' },
  { icon: '📿', title: 'விஷ்ணு சஹஸ்ரநாமம்', author: 'வேதம்', count: '1000 நாமங்கள்', desc: 'விஷ்ணுவின் 1000 திருநாமங்கள்' },
  { icon: '❄️', title: 'திருப்பாவை', author: 'ஆண்டாள்', count: '30 பாசுரங்கள்', desc: 'மார்கழி மாத பாசுரங்கள்' },
  { icon: '🌅', title: 'வேங்கடேச சுப்ரபாதம்', author: 'பரவஸ்து பட்டர்', count: '29 ஸ்லோகங்கள்', desc: 'திருப்பதி வேங்கடேசனை விழிப்பூட்டும் பாடல்' },
  { icon: '🙏', title: 'பெருமாள் 108 போற்றி', author: 'பாரம்பரியம்', count: '108 போற்றிகள்', desc: 'பெருமாளின் 108 திருநாமங்கள்' },
  { icon: '🌊', title: 'நாராயணீயம்', author: 'நாராயண பட்டத்திரி', count: '100 அத்தியாயங்கள்', desc: 'கிருஷ்ணனின் லீலைகளை போற்றும் நூல்' },
];

const PERUMAL_SONGS = SONGS.filter(s => s.god === 'perumal');

const ALWARS = [
  { name: 'பொய்கையாழ்வார்', work: 'முதல் திருவந்தாதி', icon: '💧' },
  { name: 'பூதத்தாழ்வார்', work: 'இரண்டாம் திருவந்தாதி', icon: '🌿' },
  { name: 'பேயாழ்வார்', work: 'மூன்றாம் திருவந்தாதி', icon: '🌟' },
  { name: 'திருமழிசையாழ்வார்', work: 'நான்முகன் திருவந்தாதி', icon: '🔥' },
  { name: 'நம்மாழ்வார்', work: 'திருவாய்மொழி (1102 பாசுரங்கள்)', icon: '👑' },
  { name: 'மதுரகவியாழ்வார்', work: 'கண்ணிநுண் சிறுத்தாம்பு', icon: '🎵' },
  { name: 'குலசேகராழ்வார்', work: 'பெருமாள் திருமொழி', icon: '🏰' },
  { name: 'பெரியாழ்வார்', work: 'பெரியாழ்வார் திருமொழி', icon: '🌸' },
  { name: 'ஆண்டாள்', work: 'திருப்பாவை, நாச்சியார் திருமொழி', icon: '💫' },
  { name: 'தொண்டரடிப்பொடியாழ்வார்', work: 'திருமாலை', icon: '🌺' },
  { name: 'திருப்பாணாழ்வார்', work: 'அமலனாதிபிரான்', icon: '🎶' },
  { name: 'திருமங்கையாழ்வார்', work: 'பெரிய திருமொழி', icon: '⚔️' },
];

const MOODS = ['பக்தி', 'ஞானம்', 'காப்பு', 'மோக்ஷம்'];

export default function PerumalScreen({ navigation }: any) {
  const [mood, setMood] = useState('பக்தி');
  const { isFavorite, toggleFavorite } = useApp();

  return (
    <View style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      <ScrollView showsVerticalScrollIndicator={false}>
        <LinearGradient colors={['#050F1A', '#0A1E35', '#001208']} style={s.header}>
          <Text style={s.glyph}>ஓம்</Text>
          <TouchableOpacity onPress={() => navigation.goBack()} style={s.back}>
            <Text style={s.backTxt}>←</Text>
          </TouchableOpacity>
          <Text style={s.icon}>🌸</Text>
          <Text style={s.name}>பெருமாள்</Text>
          <Text style={s.desc}>திருமால் · விஷ்ணு · ரங்கநாதன் · வேங்கடேசன் · கோவிந்தன்{'\n'}அன்பும் அருளும் கருணையும் சொரியும் தெய்வம்</Text>
          <View style={s.stats}>
            {[['8', 'நூல்கள்'], ['4000+', 'பாசுரங்கள்'], ['12', 'ஆழ்வார்கள்']].map(([n, l]) => (
              <View key={l}><Text style={s.statN}>{n}</Text><Text style={s.statL}>{l}</Text></View>
            ))}
          </View>
        </LinearGradient>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.moodRow}>
          {MOODS.map(m => (
            <TouchableOpacity key={m} style={[s.chip, mood === m && s.chipOn]} onPress={() => setMood(m)}>
              <Text style={[s.chipTxt, mood === m && s.chipTxtOn]}>{m}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <SH title="📚 நூல்கள்" />
        <View style={s.bookGrid}>
          {PERUMAL_BOOKS.map((b, i) => (
            <View key={i} style={s.bookCard}>
              <Text style={{ fontSize: 26, marginBottom: 6 }}>{b.icon}</Text>
              <Text style={s.bookTitle}>{b.title}</Text>
              <Text style={s.bookAuthor}>{b.author}</Text>
              <Text style={s.bookDesc}>{b.desc}</Text>
              <View style={s.bookBadge}><Text style={s.bookBadgeTxt}>{b.count}</Text></View>
            </View>
          ))}
        </View>

        <SH title="🎵 பாசுரங்கள்" count={PERUMAL_SONGS.length} />
        {PERUMAL_SONGS.length > 0 ? PERUMAL_SONGS.map(song => (
          <TouchableOpacity key={song.id} style={s.songCard} onPress={() => navigation.navigate('SongDetail', { songId: song.id })}>
            <View style={[s.songIcon, { backgroundColor: C.perumalBg }]}><Text style={{ fontSize: 22 }}>🌸</Text></View>
            <View style={{ flex: 1 }}>
              <Text style={s.songTitle}>{song.title}</Text>
              <Text style={s.songMeta}>{song.temple || song.type}</Text>
            </View>
            <TouchableOpacity onPress={() => toggleFavorite(song.id)}>
              <Text style={{ fontSize: 16 }}>{isFavorite(song.id) ? '❤️' : '🔖'}</Text>
            </TouchableOpacity>
          </TouchableOpacity>
        )) : (
          <View style={s.empty}><Text style={s.emptyTxt}>பாசுரங்கள் விரைவில் சேர்க்கப்படும்</Text></View>
        )}

        <SH title="🙏 12 ஆழ்வார்கள்" />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: S.lg, gap: S.sm }}>
          {ALWARS.map((a, i) => (
            <View key={i} style={s.alwarCard}>
              <Text style={{ fontSize: 28, marginBottom: 6 }}>{a.icon}</Text>
              <Text style={s.alwarName}>{a.name}</Text>
              <Text style={s.alwarWork}>{a.work}</Text>
            </View>
          ))}
        </ScrollView>

        <SH title="📿 திருவஷ்டாட்சரம்" />
        <View style={s.mantraCard}>
          <Text style={s.mantraName}>ஓம் நமோ நாராயணாய</Text>
          <Text style={s.mantraMeaning}>நாராயணனுக்கு நமஸ்காரம் — அஷ்டாட்சர மந்திரம் (8 எழுத்துக்கள்)</Text>
          <Text style={s.mantraWhen}>காலை மற்றும் மாலை 108 முறை சொல்லவும்</Text>
        </View>

        <View style={{ height: 80 }} />
      </ScrollView>
    </View>
  );
}

function SH({ title, count }: { title: string; count?: number }) {
  return (
    <View style={s.sh}>
      <Text style={s.shTitle}>{title}</Text>
      {count !== undefined && <Text style={s.shCount}>{count}</Text>}
      <View style={s.shLine} />
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  header: { paddingTop: 50, paddingBottom: 22, paddingHorizontal: S.lg, position: 'relative' },
  glyph: { position: 'absolute', right: -5, bottom: -15, fontSize: 100, color: 'rgba(66,165,245,0.06)' },
  back: { position: 'absolute', top: 50, left: S.lg, width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(66,165,245,0.15)', borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center', zIndex: 10 },
  backTxt: { color: '#42A5F5', fontSize: 18, fontWeight: '700' },
  icon: { fontSize: 52, marginBottom: 10, marginTop: 40 },
  name: { color: '#42A5F5', fontSize: 24, fontWeight: '700', marginBottom: 5 },
  desc: { color: C.txt2, fontSize: 12, lineHeight: 20 },
  stats: { flexDirection: 'row', gap: 18, marginTop: 14 },
  statN: { color: '#42A5F5', fontSize: 20, fontWeight: '700' },
  statL: { color: C.txt3, fontSize: 9 },
  moodRow: { paddingHorizontal: S.lg, gap: 7, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: C.border2 },
  chip: { paddingHorizontal: 13, paddingVertical: 6, borderRadius: 20, borderWidth: 1, borderColor: 'rgba(66,165,245,0.3)' },
  chipOn: { backgroundColor: '#1565C0', borderColor: '#1565C0' },
  chipTxt: { color: '#42A5F5', fontSize: 11 },
  chipTxtOn: { color: '#fff' },
  sh: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: S.lg, paddingTop: 18, paddingBottom: 10 },
  shTitle: { color: C.gold, fontSize: 14, fontWeight: '700' },
  shCount: { color: C.txt3, fontSize: 10 },
  shLine: { flex: 1, height: 1, backgroundColor: C.border },
  bookGrid: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: S.lg, gap: 10 },
  bookCard: { width: '47%', backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border2, padding: 12 },
  bookTitle: { color: C.txt, fontSize: 12, fontWeight: '600', marginBottom: 2 },
  bookAuthor: { color: C.txt3, fontSize: 10, marginBottom: 3 },
  bookDesc: { color: C.txt2, fontSize: 10, lineHeight: 16, marginBottom: 6 },
  bookBadge: { backgroundColor: 'rgba(66,165,245,0.12)', borderRadius: 10, paddingHorizontal: 8, paddingVertical: 2, alignSelf: 'flex-start' },
  bookBadgeTxt: { color: '#42A5F5', fontSize: 9 },
  songCard: { flexDirection: 'row', backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border2, padding: 13, marginHorizontal: S.lg, marginBottom: 9, alignItems: 'center', gap: 12 },
  songIcon: { width: 42, height: 42, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  songTitle: { color: C.txt, fontSize: 13.5, fontWeight: '600' },
  songMeta: { color: C.txt3, fontSize: 11 },
  empty: { padding: 20, alignItems: 'center' },
  emptyTxt: { color: C.txt3, fontSize: 12 },
  alwarCard: { width: 130, backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border, padding: 12 },
  alwarName: { color: C.txt, fontSize: 11, fontWeight: '600', marginBottom: 3 },
  alwarWork: { color: C.txt3, fontSize: 9, lineHeight: 14 },
  mantraCard: { marginHorizontal: S.lg, backgroundColor: 'rgba(21,101,192,0.1)', borderRadius: R.lg, borderWidth: 1, borderColor: 'rgba(21,101,192,0.3)', padding: S.xl },
  mantraName: { color: '#42A5F5', fontSize: 22, fontWeight: '700', textAlign: 'center', marginBottom: 12 },
  mantraMeaning: { color: C.txt2, fontSize: 13, textAlign: 'center', lineHeight: 22, marginBottom: 8 },
  mantraWhen: { color: C.txt3, fontSize: 11, textAlign: 'center' },
});
