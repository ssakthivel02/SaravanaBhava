import { View, Text, FlatList, TouchableOpacity, StyleSheet, StatusBar } from 'react-native';
import { C, S, R } from '../utils/theme';
import { SONGS } from '../data/songs';
import { useApp } from '../context/AppContext';
import { AppContent } from '../data/models';

export default function BookmarksScreen({ navigation }: any) {
  const { favorites, toggleFavorite } = useApp();
  const favSongs = SONGS.filter(s => favorites.includes(s.id));
  const godBg: Record<string, string> = { murugan: C.muruganBg, shiva: C.shivaBg, perumal: C.perumalBg, sakthi: C.sakthiBg, vinayagar: '#3A2000' };
  const godIcon: Record<string, string> = { murugan: '🦚', shiva: '🌙', perumal: '🌸', sakthi: '🔱', vinayagar: '🐘' };

  return (
    <View style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      <View style={s.header}>
        <Text style={s.headerTitle}>🔖 சேமிக்கப்பட்டவை</Text>
        <Text style={s.headerSub}>{favSongs.length} பாடல்கள்</Text>
      </View>
      <FlatList
        data={favSongs}
        keyExtractor={i => i.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal: S.lg, paddingTop: S.md, paddingBottom: 80 }}
        renderItem={({ item }: { item: AppContent }) => (
          <TouchableOpacity style={s.card} onPress={() => navigation.navigate('SongDetail', { songId: item.id })} activeOpacity={0.8}>
            <View style={[s.icon, { backgroundColor: godBg[item.deity || ''] || C.card }]}>
              <Text style={{ fontSize: 22 }}>{godIcon[item.deity || ''] || '🎵'}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={s.title}>{item.title_ta}</Text>
              <Text style={s.meta}>{item.category}</Text>
              <Text style={s.preview} numberOfLines={2}>{item.content_ta}</Text>
            </View>
            <TouchableOpacity onPress={() => toggleFavorite(item.id)}>
              <Text style={{ fontSize: 16 }}>❤️</Text>
            </TouchableOpacity>
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          <View style={s.empty}>
            <Text style={{ fontSize: 56, opacity: 0.3, marginBottom: 16 }}>🔖</Text>
            <Text style={s.emptyTxt}>இன்னும் எந்த பாடலும் சேமிக்கப்படவில்லை</Text>
            <Text style={s.emptySub}>பாடலை படிக்கும்போது ❤️ அழுத்துங்கள்</Text>
          </View>
        }
      />
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  header: { paddingHorizontal: S.lg, paddingTop: S.lg, paddingBottom: S.md },
  headerTitle: { fontSize: 24, fontWeight: '700', color: C.gold, marginBottom: 4 },
  headerSub: { fontSize: 12, color: C.txt3 },
  card: { flexDirection: 'row', backgroundColor: C.card, borderRadius: R.md, padding: S.md, marginBottom: S.md, alignItems: 'center', borderColor: C.border, borderWidth: 1 },
  icon: { width: 48, height: 48, borderRadius: R.md, alignItems: 'center', justifyContent: 'center', marginRight: S.md },
  title: { fontSize: 14, fontWeight: '600', color: C.txt, marginBottom: 2 },
  meta: { fontSize: 12, color: C.txt2, marginBottom: 4 },
  preview: { fontSize: 12, color: C.txt3 },
  empty: { alignItems: 'center', justifyContent: 'center', paddingVertical: 80 },
  emptyTxt: { fontSize: 16, fontWeight: '600', color: C.txt2, textAlign: 'center' },
  emptySub: { fontSize: 12, color: C.txt3, marginTop: 8, textAlign: 'center' },
});
