import React, { useState, useEffect } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  StatusBar, Switch, Alert,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Notifications from 'expo-notifications';
import { C, S, R } from '../utils/theme';
import { useApp } from '../context/AppContext';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export default function SettingsScreen({ navigation }: any) {
  const { fontScale, setFontScale, favorites, readingStreak, toggleFavorite } = useApp();
  const [notifEnabled, setNotifEnabled] = useState(false);
  const [dailyReminder, setDailyReminder] = useState(false);
  const [notifPermission, setNotifPermission] = useState(false);
  const [totalPoints, setTotalPoints] = useState(0);

  useEffect(() => {
    loadSettings();
    checkNotifPermission();
  }, []);

  const loadSettings = async () => {
    try {
      const [ne, dr, pts] = await Promise.all([
        AsyncStorage.getItem('sb_notif_enabled'),
        AsyncStorage.getItem('sb_daily_reminder'),
        AsyncStorage.getItem('sb_total_points'),
      ]);
      setNotifEnabled(ne === 'true');
      setDailyReminder(dr === 'true');
      if (pts) setTotalPoints(parseInt(pts));
    } catch {}
  };

  const checkNotifPermission = async () => {
    const { status } = await Notifications.getPermissionsAsync();
    setNotifPermission(status === 'granted');
  };

  const requestNotifPermission = async () => {
    const { status } = await Notifications.requestPermissionsAsync();
    setNotifPermission(status === 'granted');
    return status === 'granted';
  };

  const toggleNotifications = async (value: boolean) => {
    if (value) {
      const granted = notifPermission || await requestNotifPermission();
      if (!granted) {
        Alert.alert('அனுமதி தேவை', 'அறிவிப்புகளை இயக்க Settings-ல் அனுமதி கொடுங்கள்.');
        return;
      }
    }
    setNotifEnabled(value);
    await AsyncStorage.setItem('sb_notif_enabled', value.toString());
    if (!value) {
      await Notifications.cancelAllScheduledNotificationsAsync();
      setDailyReminder(false);
      await AsyncStorage.setItem('sb_daily_reminder', 'false');
    }
  };

  const toggleDailyReminder = async (value: boolean) => {
    if (value && !notifPermission) {
      const granted = await requestNotifPermission();
      if (!granted) return;
    }
    setDailyReminder(value);
    await AsyncStorage.setItem('sb_daily_reminder', value.toString());
    if (value) {
      await Notifications.cancelAllScheduledNotificationsAsync();
      await Notifications.scheduleNotificationAsync({
        content: {
          title: '🙏 சரவண பவ — இன்றைய பாடல்',
          body: 'இன்றைய திருப்புகழ் பாடலை படிக்க மறக்காதீர்கள்! முருகன் அருள் பெறுங்கள்.',
          sound: true,
        },
        trigger: {
          hour: 6,
          minute: 0,
          repeats: true,
        } as any,
      });
      Alert.alert('✅ நினைவூட்டல் அமைக்கப்பட்டது', 'தினமும் காலை 6:00 மணிக்கு அறிவிப்பு வரும்.');
    } else {
      await Notifications.cancelAllScheduledNotificationsAsync();
    }
  };

  const handleClearBookmarks = () => {
    Alert.alert(
      'சேமிப்பை நீக்கவா?',
      `${favorites.length} பாடல்களின் சேமிப்பு நீக்கப்படும். இந்த செயலை மாற்ற முடியாது.`,
      [
        { text: 'ரத்து', style: 'cancel' },
        {
          text: 'நீக்கு',
          style: 'destructive',
          onPress: async () => {
            // Actually clear all favorites
            await AsyncStorage.setItem('sb_favorites', JSON.stringify([]));
            // Force reload by toggling each favorite
            for (const id of [...favorites]) {
              toggleFavorite(id);
            }
            Alert.alert('✅ நீக்கப்பட்டது', 'அனைத்து சேமிப்புகளும் நீக்கப்பட்டன.');
          },
        },
      ]
    );
  };

  const handleClearAllData = () => {
    Alert.alert(
      'அனைத்து தரவையும் நீக்கவா?',
      'சேமிப்பு, தொடர்ச்சி, மதிப்பெண்கள் அனைத்தும் நீக்கப்படும்.',
      [
        { text: 'ரத்து', style: 'cancel' },
        {
          text: 'நீக்கு',
          style: 'destructive',
          onPress: async () => {
            await AsyncStorage.multiRemove([
              'sb_favorites', 'sb_fontscale', 'sb_streak', 'sb_lastread',
              'sb_recent', 'sb_total_points', 'sb_quiz_highscore',
              'sb_claimed_today', 'sb_last_claim_date', 'sb_profile_name',
            ]);
            Alert.alert('✅ நீக்கப்பட்டது', 'அனைத்து தரவும் நீக்கப்பட்டன. App மீண்டும் தொடங்கவும்.');
          },
        },
      ]
    );
  };

  return (
    <View style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      <View style={s.header}><Text style={s.headerTitle}>⚙️ அமைப்புகள்</Text></View>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.content}>

        {/* App Card */}
        <View style={s.appCard}>
          <Text style={s.appOm}>ஓம்</Text>
          <Text style={s.appName}>சரவண பவ</Text>
          <Text style={s.appSub}>Saravana Bhava – Murugan Bhakti</Text>
          <Text style={s.appVer}>Version 1.0.0 · Android API 35 · Expo SDK 56</Text>
        </View>

        {/* Stats */}
        <Text style={s.secTitle}>📊 உங்கள் புள்ளிவிவரங்கள்</Text>
        <View style={s.statsRow}>
          {[
            { n: favorites.length, l: 'சேமிப்பு' },
            { n: readingStreak, l: 'தொடர்ச்சி' },
            { n: totalPoints, l: 'புள்ளிகள்' },
          ].map(st => (
            <View key={st.l} style={s.statCard}>
              <Text style={s.statNum}>{st.n}</Text>
              <Text style={s.statLbl}>{st.l}</Text>
            </View>
          ))}
        </View>

        {/* Quick Navigation */}
        <Text style={s.secTitle}>🚀 விரைவு செல்</Text>
        <View style={s.navGrid}>
          {[
            { icon: '👤', label: 'சுயவிவரம்', screen: 'Profile' },
            { icon: '🏆', label: 'சாதனைகள்', screen: 'Achievements' },
            { icon: '🎁', label: 'வெகுமதிகள்', screen: 'Rewards' },
            { icon: '🎯', label: 'வினாடி வினா', screen: 'Quiz' },
          ].map(n => (
            <TouchableOpacity key={n.screen} style={s.navCard} onPress={() => navigation.navigate(n.screen)}>
              <Text style={s.navIcon}>{n.icon}</Text>
              <Text style={s.navLabel}>{n.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Font Size */}
        <Text style={s.secTitle}>📝 எழுத்து அமைப்புகள்</Text>
        <View style={s.card}>
          <Text style={s.cardLabel}>எழுத்து அளவு</Text>
          <View style={s.fontRow}>
            <TouchableOpacity style={s.fontBtn} onPress={() => setFontScale(fontScale - 0.1)}><Text style={s.fontBtnTxt}>A-</Text></TouchableOpacity>
            <Text style={s.fontSizeTxt}>{Math.round(fontScale * 100)}%</Text>
            <TouchableOpacity style={s.fontBtn} onPress={() => setFontScale(fontScale + 0.1)}><Text style={s.fontBtnTxt}>A+</Text></TouchableOpacity>
          </View>
          <Text style={{ fontSize: 14 * fontScale, color: C.txt2, marginTop: 8 }}>கைத்தல நிறைகனி அக்கர மலர்புனல்</Text>
        </View>

        {/* Notifications */}
        <Text style={s.secTitle}>🔔 அறிவிப்புகள்</Text>
        <View style={s.card}>
          <View style={s.toggleRow}>
            <View style={{ flex: 1 }}>
              <Text style={s.cardLabel}>அறிவிப்புகள்</Text>
              <Text style={s.cardDesc}>{notifPermission ? 'அனுமதி உள்ளது ✅' : 'அனுமதி இல்லை ⚠️'}</Text>
            </View>
            <Switch value={notifEnabled} onValueChange={toggleNotifications} trackColor={{ false: C.border, true: C.saffron }} thumbColor="#fff" />
          </View>
          <View style={[s.toggleRow, { marginTop: 14, paddingTop: 14, borderTopWidth: 1, borderTopColor: C.border2 }]}>
            <View style={{ flex: 1 }}>
              <Text style={s.cardLabel}>தினசரி நினைவூட்டல்</Text>
              <Text style={s.cardDesc}>காலை 6:00 மணி — இன்றைய பாடல்</Text>
            </View>
            <Switch value={dailyReminder} onValueChange={toggleDailyReminder} trackColor={{ false: C.border, true: C.saffron }} thumbColor="#fff" disabled={!notifEnabled} />
          </View>
        </View>

        {/* About */}
        <Text style={s.secTitle}>ℹ️ உள்ளடக்கம்</Text>
        <View style={s.card}>
          {[
            ['திருப்புகழ்', '10 பாடல்கள் (அருணகிரிநாதர்)'],
            ['கந்தர் சஷ்டி கவசம்', '2 பகுதிகள் (தேவராய சுவாமிகள்)'],
            ['திருமுருகாற்றுப்படை', '2 பகுதிகள் (நக்கீரர்)'],
            ['சுப்ரமண்ய புஜங்கம்', '1 வசனம் (ஆதி சங்கரர்)'],
            ['சிவன், பெருமாள், சக்தி', '3 பாடல்கள்'],
            ['சித்தர் பாடல்கள்', '2 பாடல்கள்'],
            ['விநாயகர்', '1 பாடல்'],
            ['Android Target', 'API 35 (Android 15)'],
            ['Privacy', 'All data stored locally only'],
          ].map(([l, v]) => (
            <View key={l} style={s.infoRow}>
              <Text style={s.infoLbl}>{l}</Text>
              <Text style={s.infoVal}>{v}</Text>
            </View>
          ))}
        </View>

        {/* Danger Zone */}
        <Text style={s.secTitle}>⚠️ தரவு நிர்வாகம்</Text>
        <TouchableOpacity style={s.dangerBtn} onPress={handleClearBookmarks}>
          <Text style={s.dangerTxt}>🔖 சேமிப்பை நீக்கு ({favorites.length} பாடல்கள்)</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[s.dangerBtn, { marginTop: 8 }]} onPress={handleClearAllData}>
          <Text style={s.dangerTxt}>🗑️ அனைத்து தரவையும் நீக்கு</Text>
        </TouchableOpacity>

        <View style={{ height: 80 }} />
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  header: { paddingTop: 60, paddingHorizontal: S.lg, paddingBottom: S.lg, borderBottomWidth: 1, borderBottomColor: C.border2 },
  headerTitle: { color: C.gold, fontSize: 20, fontWeight: '700' },
  content: { paddingHorizontal: S.lg },
  appCard: { alignItems: 'center', paddingVertical: 28, borderBottomWidth: 1, borderBottomColor: C.border2, marginBottom: 8 },
  appOm: { fontSize: 48, color: C.gold, marginBottom: 8 },
  appName: { color: C.gold, fontSize: 22, fontWeight: '700' },
  appSub: { color: C.txt2, fontSize: 13, marginTop: 2 },
  appVer: { color: C.txt3, fontSize: 11, marginTop: 6 },
  secTitle: { color: C.txt3, fontSize: 11, letterSpacing: 1.5, textTransform: 'uppercase', marginTop: 20, marginBottom: 10 },
  statsRow: { flexDirection: 'row', gap: 10 },
  statCard: { flex: 1, backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border, padding: S.md, alignItems: 'center' },
  statNum: { color: C.saffron, fontSize: 24, fontWeight: '700' },
  statLbl: { color: C.txt3, fontSize: 10, marginTop: 4, textAlign: 'center' },
  navGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  navCard: { width: '47%', backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border, padding: S.lg, alignItems: 'center', gap: 6 },
  navIcon: { fontSize: 28 },
  navLabel: { color: C.txt, fontSize: 12, fontWeight: '600' },
  card: { backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border, padding: S.lg },
  cardLabel: { color: C.txt, fontSize: 14, fontWeight: '600' },
  cardDesc: { color: C.txt3, fontSize: 11, marginTop: 2 },
  fontRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: 12, marginBottom: 10 },
  fontBtn: { backgroundColor: C.bg3, borderWidth: 1, borderColor: C.border, borderRadius: R.sm, paddingHorizontal: 16, paddingVertical: 8 },
  fontBtnTxt: { color: C.gold, fontWeight: '600' },
  fontSizeTxt: { color: C.txt, fontSize: 14, minWidth: 48, textAlign: 'center' },
  toggleRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: C.border2 },
  infoLbl: { color: C.txt2, fontSize: 12 },
  infoVal: { color: C.txt3, fontSize: 12 },
  dangerBtn: { backgroundColor: 'rgba(139,0,0,0.2)', borderWidth: 1, borderColor: 'rgba(139,0,0,0.4)', borderRadius: R.md, padding: S.lg, alignItems: 'center' },
  dangerTxt: { color: '#FF6B6B', fontSize: 14, fontWeight: '600' },
});
