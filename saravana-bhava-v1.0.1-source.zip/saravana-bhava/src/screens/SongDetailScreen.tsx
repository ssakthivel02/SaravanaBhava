import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  StatusBar, Share, Alert, Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Clipboard from 'expo-clipboard';
import * as Haptics from 'expo-haptics';
import { Audio } from 'expo-av';
import { C, S, R } from '../utils/theme';
import { SONGS } from '../data/songs';
import { useApp } from '../context/AppContext';

type Mode = 'original' | 'split' | 'words' | 'meaning' | 'context' | 'audio';
const MODES: { key: Mode; label: string }[] = [
  { key: 'original', label: 'மூலம்' },
  { key: 'split', label: 'சீர்' },
  { key: 'words', label: 'பொருள்' },
  { key: 'meaning', label: 'விளக்கம்' },
  { key: 'context', label: 'சூழல்' },
  { key: 'audio', label: '🔊 ஒலி' },
];

// Public domain Thiruppugazh audio from archive.org
const PUBLIC_AUDIO_MAP: Record<string, string> = {
  tp01: 'https://archive.org/download/thiruppugazh-collection/kaithala_niraikani.mp3',
  tp02: 'https://archive.org/download/thiruppugazh-collection/saravana_bava.mp3',
};

export default function SongDetailScreen({ route, navigation }: any) {
  const { songId } = route.params;
  const song = SONGS.find(s => s.id === songId);
  const { isFavorite, toggleFavorite, fontScale, setFontScale, updateStreak, addToRecentlyViewed } = useApp();
  const [mode, setMode] = useState<Mode>('original');
  const [sound, setSound] = useState<Audio.Sound | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [duration, setDuration] = useState(0);
  const [position, setPosition] = useState(0);
  const [audioError, setAudioError] = useState('');
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (song) { updateStreak(); addToRecentlyViewed(song.id); }
    Animated.timing(fadeAnim, { toValue: 1, duration: 300, useNativeDriver: true }).start();
    Audio.setAudioModeAsync({ playsInSilentModeIOS: true, staysActiveInBackground: false });
    return () => { sound?.unloadAsync(); };
  }, [song]);

  if (!song) return <View style={s.container}><Text style={{ color: C.txt, padding: 20 }}>பாடல் கிடைக்கவில்லை</Text></View>;

  const fav = isFavorite(song.id);
  const audioUrl = song.audioUrl || PUBLIC_AUDIO_MAP[song.id];

  const godColors: Record<string, [string, string]> = {
    murugan: ['#071A0E', '#0D2818'], shiva: ['#05051A', '#0D0D30'],
    perumal: ['#050F1A', '#0A1E35'], sakthi: ['#1A0510', '#2D0820'], vinayagar: ['#1A0E00', '#2A1500'],
  };
  const headerColors = godColors[song.god] || ['#0F0700', '#160C00'];

  const handleFav = async () => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    toggleFavorite(song.id);
  };

  const handleShare = async () => {
    try {
      await Share.share({ message: `${song.title}\n\n${song.original}\n\n— சரவண பவ · Murugan Bhakti`, title: song.title });
    } catch {}
  };

  const handleCopy = async () => {
    await Clipboard.setStringAsync(`${song.title}\n\n${song.original}`);
    Alert.alert('நகலெடுக்கப்பட்டது!', 'பாடல் clipboard-ல் சேமிக்கப்பட்டது.');
  };

  const handlePlayPause = async () => {
    if (!audioUrl) {
      setAudioError('இந்த பாடலுக்கு ஒலி கோப்பு இன்னும் சேர்க்கப்படவில்லை.');
      return;
    }
    try {
      setAudioError('');
      if (sound) {
        if (isPlaying) {
          await sound.pauseAsync();
          setIsPlaying(false);
        } else {
          await sound.playAsync();
          setIsPlaying(true);
        }
      } else {
        setIsLoading(true);
        const { sound: newSound } = await Audio.Sound.createAsync(
          { uri: audioUrl },
          { shouldPlay: true },
          (status) => {
            if (status.isLoaded) {
              setPosition(status.positionMillis || 0);
              setDuration(status.durationMillis || 0);
              setIsPlaying(status.isPlaying);
              if (status.didJustFinish) {
                setIsPlaying(false);
                setPosition(0);
              }
            }
          }
        );
        setSound(newSound);
        setIsPlaying(true);
        setIsLoading(false);
      }
    } catch (e) {
      setIsLoading(false);
      setAudioError('ஒலி ஏற்றுவதில் பிழை. இணைய இணைப்பை சரிபார்க்கவும்.');
    }
  };

  const handleStop = async () => {
    if (sound) {
      await sound.stopAsync();
      await sound.unloadAsync();
      setSound(null);
      setIsPlaying(false);
      setPosition(0);
    }
  };

  const formatTime = (ms: number) => {
    const s = Math.floor(ms / 1000);
    return `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, '0')}`;
  };

  const progress = duration > 0 ? position / duration : 0;
  const splitWords = (song.split || '').split('|').filter(Boolean);

  return (
    <Animated.View style={[s.container, { opacity: fadeAnim }]}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      <LinearGradient colors={headerColors as [string, string]} style={s.header}>
        <View style={s.headerRow}>
          <TouchableOpacity onPress={() => { handleStop(); navigation.goBack(); }} style={s.backBtn}>
            <Text style={s.backBtnTxt}>←</Text>
          </TouchableOpacity>
          <View style={{ flex: 1 }}>
            <Text style={s.headerTitle} numberOfLines={1}>{song.title}</Text>
            <Text style={s.headerSub}>{song.temple || song.siddharTa || song.type}</Text>
          </View>
          <View style={s.headerActions}>
            <TouchableOpacity onPress={handleFav} style={s.actionBtn}><Text style={{ fontSize: 15 }}>{fav ? '❤️' : '🔖'}</Text></TouchableOpacity>
            <TouchableOpacity onPress={handleShare} style={s.actionBtn}><Text style={{ fontSize: 15 }}>📤</Text></TouchableOpacity>
          </View>
        </View>
      </LinearGradient>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.modeTabs} contentContainerStyle={s.modeTabsContent}>
        {MODES.map(m => (
          <TouchableOpacity key={m.key} style={[s.modeTab, mode === m.key && s.modeTabActive]} onPress={() => setMode(m.key)}>
            <Text style={[s.modeTabTxt, mode === m.key && s.modeTabTxtActive]}>{m.label}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        <View style={s.panel}>

          {mode === 'original' && (
            <>
              <Text style={s.panelLabel}>மூல பாடல்</Text>
              <View style={s.box}><Text style={[s.originalTxt, { fontSize: 16 * fontScale }]}>{song.original}</Text></View>
              {song.titleEn && <View style={s.enBox}><Text style={s.enLabel}>English Title</Text><Text style={s.enTxt}>{song.titleEn}</Text></View>}
            </>
          )}

          {mode === 'split' && (
            <>
              <Text style={s.panelLabel}>சீர் பிரித்து</Text>
              <View style={s.splitContainer}>
                {splitWords.length > 0 ? splitWords.map((w, i) => (
                  <View key={i} style={s.splitWord}><Text style={[s.splitWordTxt, { fontSize: 14 * fontScale }]}>{w}</Text></View>
                )) : <Text style={s.tip}>இந்த பாடலுக்கு சீர் பிரிப்பு விரைவில் சேர்க்கப்படும்</Text>}
              </View>
              {splitWords.length > 0 && <Text style={s.tip}>💡 ஒவ்வொரு சீரையும் தனியாக படியுங்கள்</Text>}
            </>
          )}

          {mode === 'words' && (
            <>
              <Text style={s.panelLabel}>சொல்லுக்கு சொல் பொருள்</Text>
              {(song.words || []).length > 0 ? (song.words || []).map(([w, m], i) => (
                <View key={i} style={s.wordRow}>
                  <Text style={[s.wordTamil, { fontSize: 13 * fontScale }]}>{w}</Text>
                  <Text style={s.wordArrow}>→</Text>
                  <Text style={[s.wordMeaning, { fontSize: 13 * fontScale }]}>{m}</Text>
                </View>
              )) : <Text style={s.tip}>இந்த பாடலுக்கு சொல் பொருள் விரைவில் சேர்க்கப்படும்</Text>}
            </>
          )}

          {mode === 'meaning' && (
            <>
              <Text style={s.panelLabel}>எளிய விளக்கம்</Text>
              <View style={s.box}><Text style={[s.meaningTxt, { fontSize: 14 * fontScale }]}>{song.meaning}</Text></View>
              {song.meaningEn && <View style={s.enBox}><Text style={s.enLabel}>English Meaning</Text><Text style={[s.enTxt, { fontSize: 13 * fontScale }]}>{song.meaningEn}</Text></View>}
            </>
          )}

          {mode === 'context' && (
            <>
              <Text style={s.panelLabel}>சரித்திர சூழல்</Text>
              <View style={s.contextBox}><Text style={[s.contextTxt, { fontSize: 13 * fontScale }]}>{song.context || 'விரைவில் சேர்க்கப்படும்…'}</Text></View>
              {song.spiritual && (
                <View style={s.spiritualBox}>
                  <Text style={s.spiritualTitle}>✦ ஆன்மீக சிறப்பு</Text>
                  <Text style={[s.spiritualTxt, { fontSize: 13 * fontScale }]}>{song.spiritual}</Text>
                </View>
              )}
              <View style={s.metaGrid}>
                {song.temple && <View style={s.metaItem}><Text style={s.metaLabel}>கோயில்</Text><Text style={s.metaVal}>{song.temple}</Text></View>}
                {song.templeEn && <View style={s.metaItem}><Text style={s.metaLabel}>Temple</Text><Text style={s.metaVal}>{song.templeEn}</Text></View>}
                {song.difficulty && <View style={s.metaItem}><Text style={s.metaLabel}>நிலை</Text><Text style={s.metaVal}>{song.difficulty}</Text></View>}
              </View>
            </>
          )}

          {mode === 'audio' && (
            <>
              <Text style={s.panelLabel}>ஒலி வடிவம்</Text>
              {audioUrl ? (
                <>
                  <View style={s.audioPlayer}>
                    <TouchableOpacity style={[s.audioPlayBtn, isLoading && s.audioPlayBtnLoading]} onPress={handlePlayPause} disabled={isLoading}>
                      <Text style={s.audioPlayIcon}>{isLoading ? '⏳' : isPlaying ? '⏸' : '▶'}</Text>
                    </TouchableOpacity>
                    <View style={{ flex: 1 }}>
                      <Text style={s.audioTitle}>{song.title}</Text>
                      <View style={s.audioBar}>
                        <View style={[s.audioFill, { width: `${progress * 100}%` }]} />
                      </View>
                      <View style={s.audioTimes}>
                        <Text style={s.audioTime}>{formatTime(position)}</Text>
                        <Text style={s.audioTime}>{duration > 0 ? formatTime(duration) : '--:--'}</Text>
                      </View>
                    </View>
                    {(isPlaying || sound) && (
                      <TouchableOpacity style={s.stopBtn} onPress={handleStop}>
                        <Text style={s.stopBtnTxt}>⏹</Text>
                      </TouchableOpacity>
                    )}
                  </View>
                  {audioError ? <Text style={s.audioError}>{audioError}</Text> : null}
                </>
              ) : (
                <View style={s.audioNote}>
                  <Text style={s.audioNoteIcon}>🎵</Text>
                  <Text style={s.audioNoteTxt}>இந்த பாடலுக்கு ஒலி கோப்பு விரைவில் சேர்க்கப்படும்</Text>
                  <Text style={s.audioNoteSubTxt}>Audio will be added in the next update</Text>
                </View>
              )}
            </>
          )}

          <View style={s.fontCtrl}>
            <Text style={s.fontCtrlLabel}>எழுத்து அளவு</Text>
            <TouchableOpacity style={s.fontBtn} onPress={() => setFontScale(fontScale - 0.1)}><Text style={s.fontBtnTxt}>A-</Text></TouchableOpacity>
            <Text style={s.fontSizeTxt}>{Math.round(fontScale * 100)}%</Text>
            <TouchableOpacity style={s.fontBtn} onPress={() => setFontScale(fontScale + 0.1)}><Text style={s.fontBtnTxt}>A+</Text></TouchableOpacity>
          </View>

          <View style={s.actRow}>
            <TouchableOpacity style={s.actBtn} onPress={handleFav}><Text style={s.actBtnTxt}>{fav ? '❤️ சேமிக்கப்பட்டது' : '🔖 சேமி'}</Text></TouchableOpacity>
            <TouchableOpacity style={s.actBtn} onPress={handleShare}><Text style={s.actBtnTxt}>📤 பகிர்</Text></TouchableOpacity>
            <TouchableOpacity style={[s.actBtn, s.actBtnPrimary]} onPress={handleCopy}><Text style={[s.actBtnTxt, { color: C.bg }]}>📋 நகல்</Text></TouchableOpacity>
          </View>
        </View>
        <View style={{ height: 80 }} />
      </ScrollView>
    </Animated.View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  header: { paddingTop: 52, paddingBottom: 16, paddingHorizontal: S.lg },
  headerRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(212,168,32,0.15)', borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center' },
  backBtnTxt: { color: C.saffron, fontSize: 18, fontWeight: '700' },
  headerTitle: { color: C.txt, fontSize: 15, fontWeight: '600' },
  headerSub: { color: C.txt3, fontSize: 10 },
  headerActions: { flexDirection: 'row', gap: 6 },
  actionBtn: { width: 34, height: 34, borderRadius: 17, borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center' },
  modeTabs: { maxHeight: 46, borderBottomWidth: 1, borderBottomColor: C.border2 },
  modeTabsContent: { paddingHorizontal: S.lg },
  modeTab: { paddingHorizontal: 14, paddingVertical: 12, borderBottomWidth: 2, borderBottomColor: 'transparent' },
  modeTabActive: { borderBottomColor: C.saffron },
  modeTabTxt: { color: C.txt3, fontSize: 12 },
  modeTabTxtActive: { color: C.saffron, fontWeight: '600' },
  panel: { padding: S.lg },
  panelLabel: { color: C.txt3, fontSize: 10, letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 12 },
  box: { backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border, padding: S.lg },
  originalTxt: { color: C.txt, lineHeight: 28 },
  enBox: { backgroundColor: C.bg3, borderRadius: R.md, borderWidth: 1, borderColor: C.border2, padding: S.md, marginTop: 12 },
  enLabel: { color: C.txt3, fontSize: 9, letterSpacing: 1, marginBottom: 4 },
  enTxt: { color: C.txt2, lineHeight: 22 },
  splitContainer: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  splitWord: { backgroundColor: 'rgba(212,168,32,0.08)', borderWidth: 1, borderColor: 'rgba(212,168,32,0.2)', borderRadius: R.sm, paddingHorizontal: 10, paddingVertical: 6 },
  splitWordTxt: { color: C.gold2 },
  tip: { color: C.txt3, fontSize: 11, marginTop: 12 },
  wordRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: C.border2 },
  wordTamil: { color: C.gold, fontWeight: '600', width: 120 },
  wordArrow: { color: C.txt3, marginHorizontal: 8 },
  wordMeaning: { color: C.txt, flex: 1 },
  meaningTxt: { color: C.txt, lineHeight: 26 },
  contextBox: { backgroundColor: C.bg3, borderRadius: R.md, borderWidth: 1, borderColor: C.border2, padding: S.lg, marginBottom: 12 },
  contextTxt: { color: C.txt2, lineHeight: 24 },
  spiritualBox: { backgroundColor: 'rgba(212,168,32,0.06)', borderRadius: R.md, borderWidth: 1, borderColor: 'rgba(212,168,32,0.2)', padding: S.lg, marginBottom: 12 },
  spiritualTitle: { color: C.gold, fontSize: 12, fontWeight: '600', marginBottom: 8 },
  spiritualTxt: { color: C.txt2, lineHeight: 22 },
  metaGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  metaItem: { backgroundColor: C.card, borderRadius: R.sm, borderWidth: 1, borderColor: C.border2, padding: 10, minWidth: 120 },
  metaLabel: { color: C.txt3, fontSize: 9, marginBottom: 3 },
  metaVal: { color: C.txt, fontSize: 12 },
  audioPlayer: { backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border, padding: S.md, flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 12 },
  audioPlayBtn: { width: 52, height: 52, borderRadius: 26, backgroundColor: C.saffron, alignItems: 'center', justifyContent: 'center' },
  audioPlayBtnLoading: { backgroundColor: C.txt3 },
  audioPlayIcon: { color: '#fff', fontSize: 20 },
  audioTitle: { color: C.txt, fontSize: 13, marginBottom: 8 },
  audioBar: { height: 4, backgroundColor: C.border, borderRadius: 2, overflow: 'hidden', marginBottom: 4 },
  audioFill: { height: '100%', backgroundColor: C.saffron, borderRadius: 2 },
  audioTimes: { flexDirection: 'row', justifyContent: 'space-between' },
  audioTime: { color: C.txt3, fontSize: 10 },
  stopBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(240,106,10,0.15)', borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center' },
  stopBtnTxt: { fontSize: 14 },
  audioError: { color: '#FF6B6B', fontSize: 12, textAlign: 'center', marginBottom: 8 },
  audioNote: { backgroundColor: C.bg3, borderRadius: R.lg, padding: S.xl, alignItems: 'center' },
  audioNoteIcon: { fontSize: 40, marginBottom: 10 },
  audioNoteTxt: { color: C.txt2, fontSize: 13, textAlign: 'center', marginBottom: 4 },
  audioNoteSubTxt: { color: C.txt3, fontSize: 11 },
  fontCtrl: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 12, paddingVertical: 12, borderTopWidth: 1, borderTopColor: C.border2, marginTop: 16 },
  fontCtrlLabel: { color: C.txt3, fontSize: 11 },
  fontBtn: { backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: R.sm, paddingHorizontal: 12, paddingVertical: 6 },
  fontBtnTxt: { color: C.gold, fontWeight: '600' },
  fontSizeTxt: { color: C.txt, fontSize: 12, minWidth: 40, textAlign: 'center' },
  actRow: { flexDirection: 'row', gap: 10, paddingVertical: S.md },
  actBtn: { flex: 1, backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: R.md, paddingVertical: 12, alignItems: 'center' },
  actBtnPrimary: { backgroundColor: C.gold },
  actBtnTxt: { color: C.txt, fontSize: 12, fontWeight: '600' },
});
