import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, StatusBar,
  ScrollView, Animated, Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { C, S, R } from '../utils/theme';

interface Question {
  id: number;
  question: string;
  options: string[];
  correct: number;
  explanation: string;
  category: string;
}

const QUESTIONS: Question[] = [
  { id: 1, question: 'திருப்புகழ் யார் இயற்றியது?', options: ['திருமூலர்', 'அருணகிரிநாதர்', 'மாணிக்கவாசகர்', 'நக்கீரர்'], correct: 1, explanation: 'அருணகிரிநாதர் 15ம் நூற்றாண்டில் திருப்புகழை இயற்றினார். முருகனின் பக்தர்.', category: 'திருப்புகழ்' },
  { id: 2, question: 'முருகனின் ஆறு படைவீடுகளில் முதல் படைவீடு எது?', options: ['திருச்செந்தூர்', 'பழனி', 'திருப்பரங்குன்றம்', 'ஸ்வாமிமலை'], correct: 2, explanation: 'திருப்பரங்குன்றம் முருகனின் முதல் படைவீடு. இங்கே தேவயானை திருமணம் நடந்தது.', category: 'முருகன்' },
  { id: 3, question: 'திருமுருகாற்றுப்படை யார் இயற்றியது?', options: ['அருணகிரிநாதர்', 'நக்கீரர்', 'திருமூலர்', 'ஔவையார்'], correct: 1, explanation: 'நக்கீரர் சங்க காலத்தில் திருமுருகாற்றுப்படையை இயற்றினார். பத்துப்பாட்டு நூல்களில் ஒன்று.', category: 'சங்க இலக்கியம்' },
  { id: 4, question: 'கந்தர் சஷ்டி கவசம் யார் இயற்றியது?', options: ['தேவராய சுவாமிகள்', 'ஆதி சங்கரர்', 'அருணகிரிநாதர்', 'திருமூலர்'], correct: 0, explanation: 'ஸ்ரீ தேவராய சுவாமிகள் கந்தர் சஷ்டி கவசத்தை இயற்றினார்.', category: 'கவசம்' },
  { id: 5, question: 'சுப்ரமண்ய புஜங்கம் யார் இயற்றியது?', options: ['நக்கீரர்', 'மாணிக்கவாசகர்', 'ஆதி சங்கரர்', 'அருணகிரிநாதர்'], correct: 2, explanation: 'ஆதி சங்கரர் திருச்செந்தூரில் தியானத்தில் இருக்கும்போது சுப்ரமண்ய புஜங்கம் இயற்றினார்.', category: 'ஸ்தோத்ரம்' },
  { id: 6, question: 'திருமந்திரம் எத்தனை பாடல்களை கொண்டது?', options: ['1000', '2000', '3000', '4000'], correct: 2, explanation: 'திருமூலர் இயற்றிய திருமந்திரம் 3000 பாடல்களை கொண்டது.', category: 'சித்தர்' },
  { id: 7, question: 'விநாயகர் அகவல் யார் இயற்றியது?', options: ['திருமூலர்', 'ஔவையார்', 'நக்கீரர்', 'அருணகிரிநாதர்'], correct: 1, explanation: 'ஔவையார் விநாயகர் அகவலை இயற்றினார். விநாயகரை போற்றும் சிறந்த நூல்.', category: 'விநாயகர்' },
  { id: 8, question: 'முருகனின் ஆயுதம் எது?', options: ['சக்கரம்', 'வேல்', 'வில்', 'கத்தி'], correct: 1, explanation: 'வேல் முருகனின் முக்கிய ஆயுதம். சூரபத்மனை வேலால் வென்றார்.', category: 'முருகன்' },
  { id: 9, question: 'நாலாயிர திவ்யப்பிரபந்தம் எத்தனை ஆழ்வார்கள் இயற்றியது?', options: ['6', '8', '10', '12'], correct: 3, explanation: '12 ஆழ்வார்கள் நாலாயிர திவ்யப்பிரபந்தத்தை இயற்றினார்கள். 4000 பாசுரங்கள் உள்ளன.', category: 'பெருமாள்' },
  { id: 10, question: 'திருவாசகம் யார் இயற்றியது?', options: ['அப்பர்', 'சம்பந்தர்', 'மாணிக்கவாசகர்', 'சுந்தரர்'], correct: 2, explanation: 'மாணிக்கவாசகர் திருவாசகத்தை இயற்றினார். 51 திருமுறைகளை கொண்டது.', category: 'சிவன்' },
  { id: 11, question: 'பஞ்சாட்சர மந்திரம் என்ன?', options: ['ஓம் நமோ நாராயணாய', 'நமச்சிவாய', 'ஓம் கணேஷாய நமஹ', 'ஓம் சரவண பவ'], correct: 1, explanation: 'நமச்சிவாய என்பது பஞ்சாட்சர மந்திரம். ந,ம,சி,வ,ய என்ற 5 எழுத்துக்கள் 5 பூதங்களை குறிக்கும்.', category: 'சிவன்' },
  { id: 12, question: 'திருப்பாவை யார் இயற்றியது?', options: ['நம்மாழ்வார்', 'ஆண்டாள்', 'குலசேகராழ்வார்', 'பெரியாழ்வார்'], correct: 1, explanation: 'ஆண்டாள் திருப்பாவையை இயற்றினார். மார்கழி மாதம் 30 பாசுரங்கள் பாடப்படும்.', category: 'பெருமாள்' },
  { id: 13, question: 'முருகனின் வாகனம் எது?', options: ['நந்தி', 'கருடன்', 'மயில்', 'யானை'], correct: 2, explanation: 'மயில் முருகனின் வாகனம். மயில் ஞானத்தின் அடையாளம்.', category: 'முருகன்' },
  { id: 14, question: 'அபிராமி அந்தாதி யார் இயற்றியது?', options: ['ஆதி சங்கரர்', 'அபிராமி பட்டர்', 'திருமூலர்', 'ஔவையார்'], correct: 1, explanation: 'அபிராமி பட்டர் திருக்கடையூரில் அபிராமி அந்தாதியை இயற்றினார். 100 பாடல்கள்.', category: 'சக்தி' },
  { id: 15, question: 'ஸ்வாமிமலை எந்த படைவீடு?', options: ['3வது', '4வது', '5வது', '6வது'], correct: 1, explanation: 'ஸ்வாமிமலை முருகனின் 4வது படைவீடு. இங்கே முருகன் சிவனுக்கு குருவாக பிரணவம் உரைத்தார்.', category: 'முருகன்' },
];

export default function QuizScreen({ navigation }: any) {
  const [started, setStarted] = useState(false);
  const [currentQ, setCurrentQ] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [answered, setAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);
  const [highScore, setHighScore] = useState(0);
  const [shuffled, setShuffled] = useState<Question[]>([]);
  const progressAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    AsyncStorage.getItem('sb_quiz_highscore').then(v => {
      if (v) setHighScore(parseInt(v));
    });
  }, []);

  const startQuiz = () => {
    const q = [...QUESTIONS].sort(() => Math.random() - 0.5).slice(0, 10);
    setShuffled(q);
    setCurrentQ(0);
    setScore(0);
    setSelected(null);
    setAnswered(false);
    setFinished(false);
    setStarted(true);
    Animated.timing(progressAnim, { toValue: 0, duration: 0, useNativeDriver: false }).start();
  };

  const handleAnswer = async (idx: number) => {
    if (answered) return;
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSelected(idx);
    setAnswered(true);
    const correct = idx === shuffled[currentQ].correct;
    if (correct) {
      setScore(s => s + 1);
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } else {
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    }
    Animated.timing(progressAnim, {
      toValue: (currentQ + 1) / shuffled.length,
      duration: 400,
      useNativeDriver: false,
    }).start();
  };

  const nextQuestion = () => {
    if (currentQ + 1 >= shuffled.length) {
      const finalScore = score + (selected === shuffled[currentQ].correct ? 1 : 0);
      // Save high score
      if (finalScore > highScore) {
        setHighScore(finalScore);
        AsyncStorage.setItem('sb_quiz_highscore', finalScore.toString());
      }
      setFinished(true);
    } else {
      setCurrentQ(q => q + 1);
      setSelected(null);
      setAnswered(false);
    }
  };

  const getScoreColor = (s: number, total: number) => {
    const pct = s / total;
    if (pct >= 0.8) return '#4CAF50';
    if (pct >= 0.5) return C.gold;
    return C.saffron;
  };

  if (!started) {
    return (
      <View style={s.container}>
        <StatusBar barStyle="light-content" backgroundColor={C.bg} />
        <LinearGradient colors={['#071A0E', '#0D2818', '#050200']} style={s.startScreen}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={s.back}>
            <Text style={s.backTxt}>←</Text>
          </TouchableOpacity>
          <Text style={s.startIcon}>🎯</Text>
          <Text style={s.startTitle}>பக்தி வினாடி வினா</Text>
          <Text style={s.startSub}>Devotional Quiz</Text>
          <Text style={s.startDesc}>திருப்புகழ், சித்தர்கள், தெய்வங்கள் பற்றிய{'\n'}10 கேள்விகளுக்கு பதில் சொல்லுங்கள்</Text>
          <View style={s.startStats}>
            <View style={s.startStat}>
              <Text style={s.startStatN}>10</Text>
              <Text style={s.startStatL}>கேள்விகள்</Text>
            </View>
            <View style={s.startStat}>
              <Text style={s.startStatN}>{highScore}</Text>
              <Text style={s.startStatL}>உங்கள் சிறந்த மதிப்பெண்</Text>
            </View>
            <View style={s.startStat}>
              <Text style={s.startStatN}>{QUESTIONS.length}</Text>
              <Text style={s.startStatL}>மொத்த கேள்விகள்</Text>
            </View>
          </View>
          <TouchableOpacity style={s.startBtn} onPress={startQuiz}>
            <Text style={s.startBtnTxt}>🎯 தொடங்கு</Text>
          </TouchableOpacity>
        </LinearGradient>
      </View>
    );
  }

  if (finished) {
    const finalScore = score;
    const total = shuffled.length;
    const pct = Math.round((finalScore / total) * 100);
    const scoreColor = getScoreColor(finalScore, total);
    return (
      <View style={s.container}>
        <StatusBar barStyle="light-content" backgroundColor={C.bg} />
        <ScrollView contentContainerStyle={s.resultScreen}>
          <Text style={s.resultIcon}>{pct >= 80 ? '🏆' : pct >= 50 ? '⭐' : '📚'}</Text>
          <Text style={s.resultTitle}>வினாடி வினா முடிந்தது!</Text>
          <View style={[s.scoreCircle, { borderColor: scoreColor }]}>
            <Text style={[s.scoreNum, { color: scoreColor }]}>{finalScore}/{total}</Text>
            <Text style={[s.scorePct, { color: scoreColor }]}>{pct}%</Text>
          </View>
          <Text style={s.resultMsg}>
            {pct >= 80 ? '🌟 அருமை! நீங்கள் ஒரு திருப்புகழ் ஞானி!' :
             pct >= 50 ? '👍 நல்ல முயற்சி! மேலும் படியுங்கள்.' :
             '📖 கொஞ்சம் மேலும் படிக்க வேண்டும்!'}
          </Text>
          {finalScore > highScore - 1 && finalScore === highScore && (
            <View style={s.newRecord}>
              <Text style={s.newRecordTxt}>🏆 புதிய சாதனை!</Text>
            </View>
          )}
          <View style={s.resultBtns}>
            <TouchableOpacity style={s.resultBtn} onPress={startQuiz}>
              <Text style={s.resultBtnTxt}>🔄 மீண்டும் விளையாடு</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[s.resultBtn, s.resultBtnSecondary]} onPress={() => navigation.goBack()}>
              <Text style={[s.resultBtnTxt, { color: C.txt }]}>← திரும்பு</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    );
  }

  const q = shuffled[currentQ];
  return (
    <View style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      {/* Header */}
      <View style={s.quizHeader}>
        <TouchableOpacity onPress={() => { setStarted(false); }} style={s.back}>
          <Text style={s.backTxt}>✕</Text>
        </TouchableOpacity>
        <View style={s.progressBarContainer}>
          <Animated.View style={[s.progressBarFill, {
            width: progressAnim.interpolate({ inputRange: [0, 1], outputRange: ['0%', '100%'] }),
          }]} />
        </View>
        <Text style={s.qCounter}>{currentQ + 1}/{shuffled.length}</Text>
      </View>

      <ScrollView contentContainerStyle={s.quizBody}>
        <View style={s.categoryBadge}>
          <Text style={s.categoryTxt}>{q.category}</Text>
        </View>
        <Text style={s.questionTxt}>{q.question}</Text>

        {q.options.map((opt, i) => {
          let optStyle = s.option;
          let optTxtStyle = s.optionTxt;
          if (answered) {
            if (i === q.correct) { optStyle = { ...s.option, ...s.optionCorrect }; optTxtStyle = { ...s.optionTxt, color: '#fff' }; }
            else if (i === selected && i !== q.correct) { optStyle = { ...s.option, ...s.optionWrong }; optTxtStyle = { ...s.optionTxt, color: '#fff' }; }
          } else if (selected === i) {
            optStyle = { ...s.option, ...s.optionSelected };
          }
          return (
            <TouchableOpacity key={i} style={optStyle} onPress={() => handleAnswer(i)} activeOpacity={0.8}>
              <View style={s.optionLetter}><Text style={s.optionLetterTxt}>{['அ', 'ஆ', 'இ', 'ஈ'][i]}</Text></View>
              <Text style={optTxtStyle}>{opt}</Text>
              {answered && i === q.correct && <Text style={{ marginLeft: 'auto' }}>✅</Text>}
              {answered && i === selected && i !== q.correct && <Text style={{ marginLeft: 'auto' }}>❌</Text>}
            </TouchableOpacity>
          );
        })}

        {answered && (
          <View style={s.explanationBox}>
            <Text style={s.explanationTitle}>💡 விளக்கம்</Text>
            <Text style={s.explanationTxt}>{q.explanation}</Text>
          </View>
        )}

        {answered && (
          <TouchableOpacity style={s.nextBtn} onPress={nextQuestion}>
            <Text style={s.nextBtnTxt}>
              {currentQ + 1 >= shuffled.length ? '🏆 முடிவு காண்' : 'அடுத்த கேள்வி →'}
            </Text>
          </TouchableOpacity>
        )}
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  back: { width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(212,168,32,0.15)', borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center' },
  backTxt: { color: C.gold, fontSize: 16, fontWeight: '700' },
  startScreen: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: S.xl },
  startIcon: { fontSize: 80, marginBottom: 16 },
  startTitle: { color: C.gold, fontSize: 28, fontWeight: '700', marginBottom: 4 },
  startSub: { color: C.txt2, fontSize: 14, letterSpacing: 2, marginBottom: 16 },
  startDesc: { color: C.txt2, fontSize: 13, textAlign: 'center', lineHeight: 22, marginBottom: 28 },
  startStats: { flexDirection: 'row', gap: 24, marginBottom: 36 },
  startStat: { alignItems: 'center' },
  startStatN: { color: C.saffron, fontSize: 28, fontWeight: '700' },
  startStatL: { color: C.txt3, fontSize: 10, textAlign: 'center', marginTop: 2 },
  startBtn: { backgroundColor: C.saffron, borderRadius: R.full, paddingHorizontal: 40, paddingVertical: 16 },
  startBtnTxt: { color: '#fff', fontSize: 16, fontWeight: '700' },
  quizHeader: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: S.lg, paddingTop: 52, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: C.border2 },
  progressBarContainer: { flex: 1, height: 6, backgroundColor: C.border, borderRadius: 3, overflow: 'hidden' },
  progressBarFill: { height: '100%', backgroundColor: C.saffron, borderRadius: 3 },
  qCounter: { color: C.txt3, fontSize: 12, minWidth: 36, textAlign: 'right' },
  quizBody: { padding: S.lg, paddingBottom: 80 },
  categoryBadge: { backgroundColor: 'rgba(212,168,32,0.12)', borderRadius: 20, paddingHorizontal: 12, paddingVertical: 4, alignSelf: 'flex-start', marginBottom: 16 },
  categoryTxt: { color: C.gold, fontSize: 11 },
  questionTxt: { color: C.txt, fontSize: 18, fontWeight: '600', lineHeight: 28, marginBottom: 24 },
  option: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.card, borderRadius: R.md, borderWidth: 1.5, borderColor: C.border2, padding: 14, marginBottom: 10, gap: 12 },
  optionSelected: { borderColor: C.gold, backgroundColor: 'rgba(212,168,32,0.1)' },
  optionCorrect: { borderColor: '#4CAF50', backgroundColor: '#1B5E20' },
  optionWrong: { borderColor: '#F44336', backgroundColor: '#B71C1C' },
  optionLetter: { width: 28, height: 28, borderRadius: 14, backgroundColor: 'rgba(212,168,32,0.15)', alignItems: 'center', justifyContent: 'center' },
  optionLetterTxt: { color: C.gold, fontSize: 12, fontWeight: '700' },
  optionTxt: { color: C.txt, fontSize: 14, flex: 1 },
  explanationBox: { backgroundColor: 'rgba(212,168,32,0.08)', borderRadius: R.md, borderWidth: 1, borderColor: 'rgba(212,168,32,0.2)', padding: S.lg, marginTop: 8, marginBottom: 16 },
  explanationTitle: { color: C.gold, fontSize: 13, fontWeight: '700', marginBottom: 6 },
  explanationTxt: { color: C.txt2, fontSize: 13, lineHeight: 22 },
  nextBtn: { backgroundColor: C.saffron, borderRadius: R.full, padding: 16, alignItems: 'center' },
  nextBtnTxt: { color: '#fff', fontSize: 15, fontWeight: '700' },
  resultScreen: { alignItems: 'center', padding: S.xl, paddingTop: 80 },
  resultIcon: { fontSize: 80, marginBottom: 16 },
  resultTitle: { color: C.gold, fontSize: 24, fontWeight: '700', marginBottom: 24 },
  scoreCircle: { width: 140, height: 140, borderRadius: 70, borderWidth: 4, alignItems: 'center', justifyContent: 'center', marginBottom: 20 },
  scoreNum: { fontSize: 32, fontWeight: '700' },
  scorePct: { fontSize: 16, fontWeight: '600' },
  resultMsg: { color: C.txt2, fontSize: 15, textAlign: 'center', lineHeight: 24, marginBottom: 20 },
  newRecord: { backgroundColor: 'rgba(212,168,32,0.15)', borderRadius: 20, paddingHorizontal: 20, paddingVertical: 8, marginBottom: 20 },
  newRecordTxt: { color: C.gold, fontSize: 14, fontWeight: '700' },
  resultBtns: { width: '100%', gap: 12 },
  resultBtn: { backgroundColor: C.saffron, borderRadius: R.full, padding: 16, alignItems: 'center' },
  resultBtnSecondary: { backgroundColor: C.card, borderWidth: 1, borderColor: C.border },
  resultBtnTxt: { color: '#fff', fontSize: 15, fontWeight: '700' },
});
