import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, StatusBar, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Haptics from 'expo-haptics';
import { C, S, R } from '../utils/theme';
import { useApp } from '../context/AppContext';

const DAILY_REWARDS = [
  { day: 1, icon: '🌱', title: 'முதல் நாள்', reward: '10 புள்ளிகள்', points: 10 },
  { day: 2, icon: '🌿', title: 'இரண்டாம் நாள்', reward: '15 புள்ளிகள்', points: 15 },
  { day: 3, icon: '🌟', title: 'மூன்றாம் நாள்', reward: '20 புள்ளிகள்', points: 20 },
  { day: 4, icon: '🔥', title: 'நான்காம் நாள்', reward: '25 புள்ளிகள்', points: 25 },
  { day: 5, icon: '💫', title: 'ஐந்தாம் நாள்', reward: '30 புள்ளிகள்', points: 30 },
  { day: 6, icon: '⭐', title: 'ஆறாம் நாள்', reward: '40 புள்ளிகள்', points: 40 },
  { day: 7, icon: '🏆', title: 'ஏழாம் நாள்', reward: '100 புள்ளிகள் + சிறப்பு', points: 100 },
];

const SPECIAL_REWARDS = [
  { id: 'sr1', icon: '🎵', title: 'திருப்புகழ் ஞானி', desc: '5 திருப்புகழ் பாடல்கள் படிக்கவும்', points: 50, target: 5, type: 'tiruppugazh' },
  { id: 'sr2', icon: '🧘', title: 'சித்தர் சீடன்', desc: 'அனைத்து சித்தர் பாடல்களையும் படிக்கவும்', points: 75, target: 2, type: 'siddhar' },
  { id: 'sr3', icon: '🎯', title: 'வினாடி வினா வீரர்', desc: 'வினாடி வினாவில் 8+ மதிப்பெண் பெறவும்', points: 80, target: 8, type: 'quiz' },
  { id: 'sr4', icon: '❤️', title: 'பக்தி நிரம்பியவர்', desc: '10 பாடல்களை சேமிக்கவும்', points: 60, target: 10, type: 'favorites' },
];

export default function RewardsScreen({ navigation }: any) {
  const { readingStreak, favorites, recentlyViewed } = useApp();
  const [totalPoints, setTotalPoints] = useState(0);
  const [claimedToday, setClaimedToday] = useState(false);
  const [quizHighScore, setQuizHighScore] = useState(0);
  const [lastClaimDate, setLastClaimDate] = useState('');

  useEffect(() => {
    loadRewards();
  }, []);

  const loadRewards = async () => {
    try {
      const [pts, claimed, lcd, qhs] = await Promise.all([
        AsyncStorage.getItem('sb_total_points'),
        AsyncStorage.getItem('sb_claimed_today'),
        AsyncStorage.getItem('sb_last_claim_date'),
        AsyncStorage.getItem('sb_quiz_highscore'),
      ]);
      if (pts) setTotalPoints(parseInt(pts));
      if (lcd) setLastClaimDate(lcd);
      if (qhs) setQuizHighScore(parseInt(qhs));
      const today = new Date().toDateString();
      setClaimedToday(claimed === today);
    } catch {}
  };

  const claimDailyReward = async () => {
    const today = new Date().toDateString();
    if (claimedToday) {
      Alert.alert('ஏற்கனவே பெற்றீர்கள்', 'இன்றைய வெகுமதியை ஏற்கனவே பெற்றீர்கள். நாளை மீண்டும் வாருங்கள்!');
      return;
    }
    const dayIdx = Math.min(readingStreak - 1, 6);
    const reward = DAILY_REWARDS[Math.max(dayIdx, 0)];
    const newPoints = totalPoints + reward.points;
    setTotalPoints(newPoints);
    setClaimedToday(true);
    setLastClaimDate(today);
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    await AsyncStorage.setItem('sb_total_points', newPoints.toString());
    await AsyncStorage.setItem('sb_claimed_today', today);
    await AsyncStorage.setItem('sb_last_claim_date', today);
    Alert.alert('🎉 வெகுமதி கிடைத்தது!', `+${reward.points} புள்ளிகள் பெற்றீர்கள்!\nமொத்தம்: ${newPoints} புள்ளிகள்`);
  };

  const getSpecialProgress = (sr: typeof SPECIAL_REWARDS[0]) => {
    switch (sr.type) {
      case 'tiruppugazh': return Math.min(recentlyViewed.filter(id => id.startsWith('tp')).length, sr.target);
      case 'siddhar': return Math.min(recentlyViewed.filter(id => id.startsWith('sid')).length, sr.target);
      case 'quiz': return Math.min(quizHighScore, sr.target);
      case 'favorites': return Math.min(favorites.length, sr.target);
      default: return 0;
    }
  };

  const currentDayReward = DAILY_REWARDS[Math.min(Math.max(readingStreak - 1, 0), 6)];

  return (
    <View style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      <View style={s.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={s.back}>
          <Text style={s.backTxt}>←</Text>
        </TouchableOpacity>
        <Text style={s.headerTitle}>🎁 வெகுமதிகள்</Text>
        <View style={s.pointsBadge}>
          <Text style={s.pointsBadgeTxt}>⭐ {totalPoints}</Text>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.content}>
        {/* Daily Claim */}
        <View style={s.dailyClaimCard}>
          <Text style={s.dailyClaimTitle}>🌅 இன்றைய வெகுமதி</Text>
          <Text style={s.dailyClaimIcon}>{currentDayReward.icon}</Text>
          <Text style={s.dailyClaimReward}>{currentDayReward.reward}</Text>
          <Text style={s.dailyClaimStreak}>{readingStreak} நாள் தொடர்ச்சி</Text>
          <TouchableOpacity
            style={[s.claimBtn, claimedToday && s.claimBtnDone]}
            onPress={claimDailyReward}
          >
            <Text style={s.claimBtnTxt}>{claimedToday ? '✅ இன்று பெற்றீர்கள்' : '🎁 வெகுமதி பெறு'}</Text>
          </TouchableOpacity>
        </View>

        {/* 7-Day Streak Rewards */}
        <Text style={s.sectionTitle}>📅 7 நாள் தொடர்ச்சி வெகுமதி</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.streakRow}>
          {DAILY_REWARDS.map((dr, i) => {
            const done = readingStreak > dr.day;
            const current = readingStreak === dr.day;
            return (
              <View key={dr.day} style={[s.streakDay, done && s.streakDayDone, current && s.streakDayCurrent]}>
                <Text style={s.streakDayIcon}>{done ? '✅' : dr.icon}</Text>
                <Text style={s.streakDayNum}>{dr.day}</Text>
                <Text style={s.streakDayPts}>{dr.points}</Text>
              </View>
            );
          })}
        </ScrollView>

        {/* Special Rewards */}
        <Text style={s.sectionTitle}>🏅 சிறப்பு வெகுமதிகள்</Text>
        {SPECIAL_REWARDS.map(sr => {
          const progress = getSpecialProgress(sr);
          const completed = progress >= sr.target;
          const pct = (progress / sr.target) * 100;
          return (
            <View key={sr.id} style={[s.specialCard, completed && s.specialCardDone]}>
              <View style={s.specialIcon}><Text style={{ fontSize: 28 }}>{sr.icon}</Text></View>
              <View style={{ flex: 1 }}>
                <Text style={s.specialTitle}>{sr.title}</Text>
                <Text style={s.specialDesc}>{sr.desc}</Text>
                <View style={s.specialBar}>
                  <View style={[s.specialFill, { width: `${pct}%` }]} />
                </View>
                <Text style={s.specialProgress}>{progress}/{sr.target}</Text>
              </View>
              <View style={[s.specialPoints, completed && s.specialPointsDone]}>
                <Text style={[s.specialPointsTxt, completed && { color: '#4CAF50' }]}>
                  {completed ? '✅' : `+${sr.points}`}
                </Text>
              </View>
            </View>
          );
        })}

        {/* Points Summary */}
        <View style={s.summaryCard}>
          <Text style={s.summaryTitle}>⭐ மொத்த புள்ளிகள்: {totalPoints}</Text>
          <Text style={s.summaryDesc}>தினமும் படித்து, வினாடி வினா விளையாடி, பாடல்களை சேமித்து அதிக புள்ளிகள் பெறுங்கள்!</Text>
        </View>

        <View style={{ height: 80 }} />
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  header: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: S.lg, paddingTop: 52, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: C.border2 },
  back: { width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(212,168,32,0.15)', borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center' },
  backTxt: { color: C.gold, fontSize: 18, fontWeight: '700' },
  headerTitle: { flex: 1, color: C.gold, fontSize: 18, fontWeight: '700' },
  pointsBadge: { backgroundColor: 'rgba(212,168,32,0.15)', borderRadius: 20, paddingHorizontal: 12, paddingVertical: 5, borderWidth: 1, borderColor: C.border },
  pointsBadgeTxt: { color: C.gold, fontSize: 13, fontWeight: '700' },
  content: { paddingHorizontal: S.lg, paddingTop: S.lg },
  dailyClaimCard: { backgroundColor: 'rgba(212,168,32,0.08)', borderRadius: R.xl, borderWidth: 1, borderColor: 'rgba(212,168,32,0.3)', padding: S.xl, alignItems: 'center', marginBottom: 20 },
  dailyClaimTitle: { color: C.gold, fontSize: 16, fontWeight: '700', marginBottom: 12 },
  dailyClaimIcon: { fontSize: 52, marginBottom: 8 },
  dailyClaimReward: { color: C.saffron, fontSize: 18, fontWeight: '700', marginBottom: 4 },
  dailyClaimStreak: { color: C.txt3, fontSize: 12, marginBottom: 16 },
  claimBtn: { backgroundColor: C.saffron, borderRadius: R.full, paddingHorizontal: 32, paddingVertical: 14 },
  claimBtnDone: { backgroundColor: '#1B5E20' },
  claimBtnTxt: { color: '#fff', fontSize: 15, fontWeight: '700' },
  sectionTitle: { color: C.txt3, fontSize: 11, letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 12, marginTop: 4 },
  streakRow: { paddingBottom: 4, gap: 8 },
  streakDay: { width: 64, backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border2, padding: 10, alignItems: 'center' },
  streakDayDone: { backgroundColor: '#1B5E20', borderColor: '#4CAF50' },
  streakDayCurrent: { backgroundColor: 'rgba(240,106,10,0.15)', borderColor: C.saffron },
  streakDayIcon: { fontSize: 22, marginBottom: 4 },
  streakDayNum: { color: C.txt3, fontSize: 10 },
  streakDayPts: { color: C.saffron, fontSize: 11, fontWeight: '700' },
  specialCard: { flexDirection: 'row', backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border2, padding: 13, marginBottom: 9, alignItems: 'center', gap: 12 },
  specialCardDone: { borderColor: '#4CAF5044', backgroundColor: 'rgba(27,94,32,0.2)' },
  specialIcon: { width: 52, height: 52, borderRadius: 26, backgroundColor: 'rgba(212,168,32,0.12)', alignItems: 'center', justifyContent: 'center' },
  specialTitle: { color: C.txt, fontSize: 14, fontWeight: '600', marginBottom: 2 },
  specialDesc: { color: C.txt2, fontSize: 11, lineHeight: 18, marginBottom: 6 },
  specialBar: { height: 4, backgroundColor: C.bg3, borderRadius: 2, overflow: 'hidden', marginBottom: 3 },
  specialFill: { height: '100%', backgroundColor: C.gold, borderRadius: 2 },
  specialProgress: { color: C.txt3, fontSize: 10 },
  specialPoints: { alignItems: 'center', backgroundColor: 'rgba(240,106,10,0.15)', borderRadius: R.sm, padding: 8, minWidth: 44 },
  specialPointsDone: { backgroundColor: 'rgba(76,175,80,0.15)' },
  specialPointsTxt: { color: C.saffron, fontSize: 14, fontWeight: '700' },
  summaryCard: { backgroundColor: C.card, borderRadius: R.lg, borderWidth: 1, borderColor: C.border, padding: S.lg, marginTop: 8 },
  summaryTitle: { color: C.gold, fontSize: 16, fontWeight: '700', marginBottom: 8 },
  summaryDesc: { color: C.txt2, fontSize: 13, lineHeight: 22 },
});
