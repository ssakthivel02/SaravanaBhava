import React, { useState, useMemo } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, StatusBar, TextInput } from 'react-native';
import { C, S, R } from '../utils/theme';
import { SONGS } from '../data/songs';
import { useApp } from '../context/AppContext';

const FILTERS = [
  { key: 'all', label: 'அனைத்தும்' },
  { key: 'tiruppugazh', label: 'திருப்புகழ்' },
  { key: 'thirumurugatrupadai', label: 'திருமுருகாற்றுப்படை' },
  { key: 'kandhar_sashti', label: 'கந்தர் சஷ்டி' },
  { key: 'subramanya_bhujangam', label: 'புஜங்கம்' },
  { key: 'shiva', label: 'சிவன்' },
  { key: 'perumal', label: 'பெருமாள்' },
  { key: 'sakthi', label: 'சக்தி' },
  { key: 'siddhar', label: 'சித்தர்' },
  { key: 'vinayagar', label: 'விநாயகர்' },
];

export default function LibraryScreen({ navigation }: any) {
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const { isFavorite, toggleFavorite } = useApp();

  const filtered = useMemo(() => {
    let list = SONGS;
    if (filter !== 'all') list = list.filter(s => s.type === filter);
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(s =>
        s.title.toLowerCase().includes(q) ||
        s.original.toLowerCase().includes(q) ||
        s.meaning.toLowerCase().includes(q) ||
        (s.temple && s.temple.toLowerCase().includes(q)) ||
        s.tags.some(t => t.toLowerCase().includes(q))
      );
    }
    return list;
  }, [filter, search]);

  const godBg: Record<string, string> = { murugan: C.muruganBg, shiva: C.shivaBg, perumal: C.perumalBg, sakthi: C.sakthiBg, vinayagar: '#3A2000' };
  const godIcon: Record<string, string> = { murugan: '🦚', shiva: '🌙', perumal: '🌸', sakthi: '🔱', vinayagar: '🐘' };

  const renderItem = ({ item }: { item: Song }) => (
    <TouchableOpacity style={s.card} onPress={() => navigation.navigate('SongDetail', { songId: item.id })} activeOpacity={0.8}>
      <View style={[s.icon, { backgroundColor: godBg[item.god] || C.card }]}>
        <Text style={{ fontSize: 22 }}>{godIcon[item.god] || '🎵'}</Text>
      </View>
      <View style={{ flex: 1 }}>
        <Text style={s.title}>{item.title}</Text>
        <Text style={s.meta}>{item.temple || item.siddharTa || item.type}</Text>
        <View style={s.tags}>
          {item.tags.slice(0, 3).map(t => <View key={t} style={s.tag}><Text style={s.tagTxt}>{t}</Text></View>)}
        </View>
      </View>
      <TouchableOpacity onPress={() => toggleFavorite(item.id)}>
        <Text style={{ fontSize: 16 }}>{isFavorite(item.id) ? '❤️' : '🔖'}</Text>
      </TouchableOpacity>
    </TouchableOpacity>
  );

  return (
    <View style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      <View style={s.searchBar}>
        <Text style={{ fontSize: 16 }}>🔍</Text>
        <TextInput style={s.searchInput} placeholder="பாடல் / கோயில் / வார்த்தை தேடு…" placeholderTextColor={C.txt3} value={search} onChangeText={setSearch} />
        {search.length > 0 && <TouchableOpacity onPress={() => setSearch('')}><Text style={{ color: C.txt3, fontSize: 14 }}>✕</Text></TouchableOpacity>}
      </View>
      <FlatList
        data={FILTERS}
        horizontal
        showsHorizontalScrollIndicator={false}
        keyExtractor={i => i.key}
        contentContainerStyle={s.filterRow}
        style={s.filterList}
        renderItem={({ item }) => (
          <TouchableOpacity style={[s.chip, filter === item.key && s.chipOn]} onPress={() => setFilter(item.key)}>
            <Text style={[s.chipTxt, filter === item.key && s.chipTxtOn]}>{item.label}</Text>
          </TouchableOpacity>
        )}
      />
      <View style={s.countRow}><Text style={s.countTxt}>{filtered.length} பாடல்கள்</Text></View>
      <FlatList
        data={filtered}
        keyExtractor={i => i.id}
        renderItem={renderItem}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal: S.lg, paddingBottom: 80 }}
        ListEmptyComponent={
          <View style={s.empty}>
            <Text style={{ fontSize: 48, opacity: 0.3, marginBottom: 12 }}>🔍</Text>
            <Text style={s.emptyTxt}>முடிவு இல்லை</Text>
          </View>
        }
      />
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  searchBar: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border, marginHorizontal: S.lg, marginTop: 60, marginBottom: 10, paddingHorizontal: S.md, paddingVertical: 10 },
  searchInput: { flex: 1, color: C.txt, fontSize: 14 },
  filterList: { maxHeight: 46, borderBottomWidth: 1, borderBottomColor: C.border2 },
  filterRow: { paddingHorizontal: S.lg, gap: 7, paddingVertical: 8 },
  chip: { paddingHorizontal: 13, paddingVertical: 6, borderRadius: 20, borderWidth: 1, borderColor: C.border },
  chipOn: { backgroundColor: C.saffron, borderColor: C.saffron },
  chipTxt: { color: C.txt3, fontSize: 11 },
  chipTxtOn: { color: '#fff' },
  countRow: { paddingHorizontal: S.lg, paddingVertical: 8 },
  countTxt: { color: C.txt3, fontSize: 11 },
  card: { flexDirection: 'row', backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border2, padding: 13, marginBottom: 9, alignItems: 'flex-start', gap: 12 },
  icon: { width: 42, height: 42, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  title: { color: C.txt, fontSize: 13.5, fontWeight: '600', marginBottom: 2 },
  meta: { color: C.txt3, fontSize: 11 },
  tags: { flexDirection: 'row', gap: 5, marginTop: 6, flexWrap: 'wrap' },
  tag: { backgroundColor: 'rgba(212,168,32,0.07)', borderWidth: 1, borderColor: 'rgba(212,168,32,0.25)', borderRadius: 10, paddingHorizontal: 8, paddingVertical: 2 },
  tagTxt: { color: C.gold, fontSize: 9.5 },
  empty: { alignItems: 'center', paddingTop: 80 },
  emptyTxt: { color: C.txt3, fontSize: 16 },
});
