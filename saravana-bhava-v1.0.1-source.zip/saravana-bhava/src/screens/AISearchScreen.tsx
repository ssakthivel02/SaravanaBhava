import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { C } from '../utils/theme';
import { searchContent } from '../data/dataService';
import { AppContent } from '../data/models';

const AISearchScreen: React.FC = () => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<AppContent[]>([]);
  const [loading, setLoading] = useState(false);

  const handleSearch = () => {
    if (!query.trim()) return;
    setLoading(true);
    // Simulate AI search by filtering local content for now
    // In a real app, this would call an AI API
    const searchResults = searchContent(query);
    setResults(searchResults);
    setLoading(false);
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <Text style={styles.title}>AI குரு (AI Guru)</Text>
        <Text style={styles.subtitle}>உங்கள் ஆன்மீக கேள்விகளுக்கு பதில் தேடுங்கள்</Text>

        <TextInput
          style={styles.searchInput}
          placeholder="தேடல்: முருகன் மந்திரம், பயம் நீங்க, ஆரோக்கியம்..."
          placeholderTextColor={C.txt3}
          value={query}
          onChangeText={setQuery}
          onSubmitEditing={handleSearch}
        />
        <TouchableOpacity style={styles.searchButton} onPress={handleSearch} disabled={loading}>
          {loading ? (
            <ActivityIndicator color={C.bg} />
          ) : (
            <Text style={styles.searchButtonText}>தேடு (Search)</Text>
          )}
        </TouchableOpacity>

        {results.length > 0 && (
          <View style={styles.resultsContainer}>
            <Text style={styles.resultsTitle}>தேடல் முடிவுகள் ({results.length})</Text>
            {results.map((item) => (
              <View key={item.id} style={styles.resultItem}>
                <Text style={styles.resultItemTitle}>{item.title_ta} {item.title_en ? `(${item.title_en})` : ''}</Text>
                <Text style={styles.resultItemCategory}>தெய்வம்: {item.deity || 'N/A'} | வகை: {item.category}</Text>
                <Text style={styles.resultItemStatus}>சரிபார்ப்பு நிலை: {item.verification_status === 'needs_review' ? 'Needs Review' : 'Verified'}</Text>
                <Text style={styles.resultItemContent} numberOfLines={3}>{item.content_ta}</Text>
                <TouchableOpacity style={styles.readMoreButton}>
                  <Text style={styles.readMoreButtonText}>படிக்க (Read)</Text>
                </TouchableOpacity>
                <Text style={styles.aiNote}>AI பரிந்துரை: இது பாரம்பரிய ஆன்மீக வழிகாட்டுதல் மட்டுமே, மருத்துவ/சட்ட/நிதி ஆலோசனை அல்ல.</Text>
              </View>
            ))}
          </View>
        )}

        {results.length === 0 && !loading && query.trim() !== '' && (
          <Text style={styles.noResultsText}>முடிவுகள் இல்லை. வேறு வார்த்தைகளில் தேடவும்.</Text>
        )}

        <Text style={styles.safetyNote}>
          AI குரு உள்ளூர் சரிபார்க்கப்பட்ட உள்ளடக்கத்திலிருந்து மட்டுமே பரிந்துரைகளை வழங்குகிறது. 
          வெளிப்புற AI பயன்படுத்தப்பட்டால், பதில்கள் "பாரம்பரிய பக்தி பரிந்துரை" என்று குறிக்கப்படும். 
          இது மருத்துவ, சட்ட அல்லது நிதி ஆலோசனை அல்ல.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: C.bg,
  },
  scrollContainer: {
    padding: 20,
    alignItems: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: C.gold,
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: C.txt2,
    marginBottom: 30,
    textAlign: 'center',
  },
  searchInput: {
    width: '100%',
    backgroundColor: C.card,
    borderRadius: 10,
    padding: 15,
    fontSize: 16,
    color: C.txt,
    marginBottom: 20,
    borderColor: C.border,
    borderWidth: 1,
  },
  searchButton: {
    backgroundColor: C.saffron,
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 10,
    marginBottom: 30,
    width: '100%',
    alignItems: 'center',
  },
  searchButtonText: {
    color: C.bg,
    fontSize: 18,
    fontWeight: 'bold',
  },
  resultsContainer: {
    width: '100%',
    marginTop: 20,
  },
  resultsTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: C.gold,
    marginBottom: 15,
    textAlign: 'center',
  },
  resultItem: {
    backgroundColor: C.card,
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
    borderColor: C.border,
    borderWidth: 1,
  },
  resultItemTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: C.txt,
    marginBottom: 5,
  },
  resultItemCategory: {
    fontSize: 14,
    color: C.txt2,
    marginBottom: 5,
  },
  resultItemStatus: {
    fontSize: 14,
    color: C.saffron,
    marginBottom: 10,
  },
  resultItemContent: {
    fontSize: 14,
    color: C.txt3,
    marginBottom: 10,
  },
  readMoreButton: {
    backgroundColor: C.gold,
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 8,
    alignSelf: 'flex-start',
    marginBottom: 10,
  },
  readMoreButtonText: {
    color: C.bg,
    fontSize: 14,
    fontWeight: 'bold',
  },
  aiNote: {
    fontSize: 12,
    color: C.txt3,
    fontStyle: 'italic',
    marginTop: 10,
  },
  noResultsText: {
    fontSize: 16,
    color: C.txt3,
    textAlign: 'center',
    marginTop: 50,
  },
  safetyNote: {
    fontSize: 12,
    color: C.txt3,
    textAlign: 'center',
    marginTop: 40,
    paddingHorizontal: 10,
    fontStyle: 'italic',
  },
});

export default AISearchScreen;
