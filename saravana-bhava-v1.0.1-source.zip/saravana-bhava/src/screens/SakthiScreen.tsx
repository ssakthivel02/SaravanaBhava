import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, StatusBar } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { C, S, R } from '../utils/theme';
import { SONGS } from '../data/songs';
import { useApp } from '../context/AppContext';

const SAKTHI_BOOKS = [
  { icon: '💫', title: 'அபிராமி அந்தாதி', author: 'அபிராமி பட்டர்', count: '100 பாடல்கள்', desc: 'அபிராமி அம்மனை போற்றும் அந்தாதி' },
  { icon: '🔱', title: 'லலிதா சஹஸ்ரநாமம்', author: 'ப்ரம்மாண்ட புராணம்', count: '1000 நாமங்கள்', desc: 'லலிதா அம்மனின் 1000 திருநாமங்கள்' },
  { icon: '✨', title: 'சௌந்தர்ய லஹரி', author: 'ஆதி சங்கரர்', count: '100 ஸ்லோகங்கள்', desc: 'அம்மனின் அழகை போற்றும் நூல்' },
  { icon: '⚔️', title: 'மஹிஷாசுர மர்தினி', author: 'ஆதி சங்கரர்', count: '21 ஸ்லோகங்கள்', desc: 'மஹிஷாசுரனை வென்ற துர்கையை போற்றும் நூல்' },
  { icon: '🌟', title: 'கனகதாரா ஸ்தோத்ரம்', author: 'ஆதி சங்கரர்', count: '21 ஸ்லோகங்கள்', desc: 'செல்வம் தரும் லட்சுமி ஸ்தோத்ரம்' },
  { icon: '📿', title: 'அம்மன் 108 போற்றி', author: 'பாரம்பரியம்', count: '108 போற்றிகள்', desc: 'அம்மனின் 108 திருநாமங்கள்' },
];

const SAKTHI_SONGS = SONGS.filter(s => s.god === 'sakthi');

const SAKTHI_FORMS = [
  { name: 'துர்கை', desc: 'அசுரர்களை அழிக்கும் சக்தி', icon: '⚔️', color: '#E53935' },
  { name: 'காளி', desc: 'காலத்தின் தெய்வம், கருணை வடிவம்', icon: '🌑', color: '#4A148C' },
  { name: 'லட்சுமி', desc: 'செல்வம் மற்றும் மங்களம்', icon: '🌺', color: '#F9A825' },
  { name: 'சரஸ்வதி', desc: 'கல்வி மற்றும் கலை தெய்வம்', icon: '🎵', color: '#1565C0' },
  { name: 'காமாட்சி', desc: 'காஞ்சி பீடத்தில் வாழும் அம்மன்', icon: '👁️', color: '#2E7D32' },
  { name: 'மீனாட்சி', desc: 'மதுரை மீனாட்சி அம்மன்', icon: '🐟', color: '#00838F' },
];

const MOODS = ['பக்தி', 'ஞானம்', 'காப்பு', 'செல்வம்'];

export default function SakthiScreen({ navigation }: any) {
  const [mood, setMood] = useState('பக்தி');
  const { isFavorite, toggleFavorite } = useApp();

  return (
    <View style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      <ScrollView showsVerticalScrollIndicator={false}>
        <LinearGradient colors={['#1A0510', '#2D0820', '#1A0500']} style={s.header}>
          <Text style={s.glyph}>சக்</Text>
          <TouchableOpacity onPress={() => navigation.goBack()} style={s.back}>
            <Text style={s.backTxt}>←</Text>
          </TouchableOpacity>
          <Text style={s.icon}>🔱</Text>
          <Text style={s.name}>சக்தி</Text>
          <Text style={s.desc}>ஆதி பராசக்தி · துர்கை · காளி · லட்சுமி · சரஸ்வதி{'\n'}அருள் தரும் அம்மன் — உலகின் ஆற்றல் வடிவம்</Text>
          <View style={s.stats}>
            {[['8', 'நூல்கள்'], ['1200+', 'பாடல்கள்'], ['51', 'சக்தி பீடங்கள்']].map(([n, l]) => (
              <View key={l}><Text style={s.statN}>{n}</Text><Text style={s.statL}>{l}</Text></View>
            ))}
          </View>
        </LinearGradient>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.moodRow}>
          {MOODS.map(m => (
            <TouchableOpacity key={m} style={[s.chip, mood === m && s.chipOn]} onPress={() => setMood(m)}>
              <Text style={[s.chipTxt, mood === m && s.chipTxtOn]}>{m}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <SH title="📚 நூல்கள்" />
        <View style={s.bookGrid}>
          {SAKTHI_BOOKS.map((b, i) => (
            <View key={i} style={s.bookCard}>
              <Text style={{ fontSize: 26, marginBottom: 6 }}>{b.icon}</Text>
              <Text style={s.bookTitle}>{b.title}</Text>
              <Text style={s.bookAuthor}>{b.author}</Text>
              <Text style={s.bookDesc}>{b.desc}</Text>
              <View style={s.bookBadge}><Text style={s.bookBadgeTxt}>{b.count}</Text></View>
            </View>
          ))}
        </View>

        <SH title="🎵 பாடல்கள்" count={SAKTHI_SONGS.length} />
        {SAKTHI_SONGS.length > 0 ? SAKTHI_SONGS.map(song => (
          <TouchableOpacity key={song.id} style={s.songCard} onPress={() => navigation.navigate('SongDetail', { songId: song.id })}>
            <View style={[s.songIcon, { backgroundColor: C.sakthiBg }]}><Text style={{ fontSize: 22 }}>🔱</Text></View>
            <View style={{ flex: 1 }}>
              <Text style={s.songTitle}>{song.title}</Text>
              <Text style={s.songMeta}>{song.temple || song.type}</Text>
            </View>
            <TouchableOpacity onPress={() => toggleFavorite(song.id)}>
              <Text style={{ fontSize: 16 }}>{isFavorite(song.id) ? '❤️' : '🔖'}</Text>
            </TouchableOpacity>
          </TouchableOpacity>
        )) : (
          <View style={s.empty}><Text style={s.emptyTxt}>பாடல்கள் விரைவில் சேர்க்கப்படும்</Text></View>
        )}

        <SH title="✨ சக்தியின் வடிவங்கள்" />
        <View style={s.formsGrid}>
          {SAKTHI_FORMS.map((f, i) => (
            <View key={i} style={[s.formCard, { borderColor: f.color + '44' }]}>
              <Text style={{ fontSize: 28, marginBottom: 6 }}>{f.icon}</Text>
              <Text style={[s.formName, { color: f.color }]}>{f.name}</Text>
              <Text style={s.formDesc}>{f.desc}</Text>
            </View>
          ))}
        </View>

        <SH title="📿 சக்தி மந்திரம்" />
        <View style={s.mantraCard}>
          <Text style={s.mantraName}>ஓம் ஐம் ஹ்ரீம் க்லீம் சாமுண்டாயை விச்சே</Text>
          <Text style={s.mantraMeaning}>நவராத்திரி மந்திரம் — துர்கையை போற்றும் சக்தி மந்திரம்</Text>
          <Text style={s.mantraWhen}>நவராத்திரி நாட்களில் 108 முறை சொல்லவும்</Text>
        </View>

        <View style={{ height: 80 }} />
      </ScrollView>
    </View>
  );
}

function SH({ title, count }: { title: string; count?: number }) {
  return (
    <View style={s.sh}>
      <Text style={s.shTitle}>{title}</Text>
      {count !== undefined && <Text style={s.shCount}>{count}</Text>}
      <View style={s.shLine} />
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  header: { paddingTop: 50, paddingBottom: 22, paddingHorizontal: S.lg, position: 'relative' },
  glyph: { position: 'absolute', right: -5, bottom: -15, fontSize: 100, color: 'rgba(194,24,91,0.06)' },
  back: { position: 'absolute', top: 50, left: S.lg, width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(194,24,91,0.15)', borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center', zIndex: 10 },
  backTxt: { color: '#F06292', fontSize: 18, fontWeight: '700' },
  icon: { fontSize: 52, marginBottom: 10, marginTop: 40 },
  name: { color: '#F06292', fontSize: 24, fontWeight: '700', marginBottom: 5 },
  desc: { color: C.txt2, fontSize: 12, lineHeight: 20 },
  stats: { flexDirection: 'row', gap: 18, marginTop: 14 },
  statN: { color: '#F06292', fontSize: 20, fontWeight: '700' },
  statL: { color: C.txt3, fontSize: 9 },
  moodRow: { paddingHorizontal: S.lg, gap: 7, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: C.border2 },
  chip: { paddingHorizontal: 13, paddingVertical: 6, borderRadius: 20, borderWidth: 1, borderColor: 'rgba(194,24,91,0.3)' },
  chipOn: { backgroundColor: '#AD1457', borderColor: '#AD1457' },
  chipTxt: { color: '#F06292', fontSize: 11 },
  chipTxtOn: { color: '#fff' },
  sh: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: S.lg, paddingTop: 18, paddingBottom: 10 },
  shTitle: { color: C.gold, fontSize: 14, fontWeight: '700' },
  shCount: { color: C.txt3, fontSize: 10 },
  shLine: { flex: 1, height: 1, backgroundColor: C.border },
  bookGrid: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: S.lg, gap: 10 },
  bookCard: { width: '47%', backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border2, padding: 12 },
  bookTitle: { color: C.txt, fontSize: 12, fontWeight: '600', marginBottom: 2 },
  bookAuthor: { color: C.txt3, fontSize: 10, marginBottom: 3 },
  bookDesc: { color: C.txt2, fontSize: 10, lineHeight: 16, marginBottom: 6 },
  bookBadge: { backgroundColor: 'rgba(194,24,91,0.12)', borderRadius: 10, paddingHorizontal: 8, paddingVertical: 2, alignSelf: 'flex-start' },
  bookBadgeTxt: { color: '#F06292', fontSize: 9 },
  songCard: { flexDirection: 'row', backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border2, padding: 13, marginHorizontal: S.lg, marginBottom: 9, alignItems: 'center', gap: 12 },
  songIcon: { width: 42, height: 42, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  songTitle: { color: C.txt, fontSize: 13.5, fontWeight: '600' },
  songMeta: { color: C.txt3, fontSize: 11 },
  empty: { padding: 20, alignItems: 'center' },
  emptyTxt: { color: C.txt3, fontSize: 12 },
  formsGrid: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: S.lg, gap: 10 },
  formCard: { width: '47%', backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, padding: 12 },
  formName: { fontSize: 14, fontWeight: '700', marginBottom: 4 },
  formDesc: { color: C.txt2, fontSize: 10, lineHeight: 16 },
  mantraCard: { marginHorizontal: S.lg, backgroundColor: 'rgba(173,20,87,0.1)', borderRadius: R.lg, borderWidth: 1, borderColor: 'rgba(173,20,87,0.3)', padding: S.xl },
  mantraName: { color: '#F06292', fontSize: 16, fontWeight: '700', textAlign: 'center', marginBottom: 12, lineHeight: 26 },
  mantraMeaning: { color: C.txt2, fontSize: 13, textAlign: 'center', lineHeight: 22, marginBottom: 8 },
  mantraWhen: { color: C.txt3, fontSize: 11, textAlign: 'center' },
});
