import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, StatusBar, FlatList } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { C, S, R } from '../utils/theme';
import { SONGS } from '../data/songs';
import { useApp } from '../context/AppContext';

const SHIVA_BOOKS = [
  { icon: '🎵', title: 'தேவாரம்', author: 'மூவர் (அப்பர், சம்பந்தர், சுந்தரர்)', count: '4000+ பாடல்கள்', desc: 'சைவ சமயத்தின் முதல் திருமுறைகள்' },
  { icon: '🔥', title: 'திருவாசகம்', author: 'மாணிக்கவாசகர்', count: '51 திருமுறைகள்', desc: 'ஆன்மீக அனுபவங்களின் உச்சகட்ட வெளிப்பாடு' },
  { icon: '🧘', title: 'திருமந்திரம்', author: 'திருமூலர்', count: '3000 பாடல்கள்', desc: 'யோகம், தந்திரம், சைவ தத்துவம்' },
  { icon: '🌙', title: 'சிவ புராணம்', author: 'மாணிக்கவாசகர்', count: '1 நூல்', desc: 'சிவனின் மகிமையை போற்றும் நூல்' },
  { icon: '🔱', title: 'சிவன் 108 போற்றி', author: 'பாரம்பரியம்', count: '108 போற்றிகள்', desc: 'சிவனின் 108 திருநாமங்கள்' },
  { icon: '⚡', title: 'ருத்ரம்', author: 'வேதம்', count: '11 அனுவாகங்கள்', desc: 'சிவனை போற்றும் வேத மந்திரங்கள்' },
];

const SHIVA_SONGS = SONGS.filter(s => s.god === 'shiva');

const SHIVA_TEMPLES = [
  { icon: '💃', name: 'சிதம்பரம்', loc: 'கடலூர் மாவட்டம்', desc: 'ஆகாயலிங்கம் — ஆனந்த தாண்டவம்' },
  { icon: '🌋', name: 'திருவண்ணாமலை', loc: 'திருவண்ணாமலை மாவட்டம்', desc: 'அக்னிலிங்கம் — கார்த்திகை தீபம்' },
  { icon: '🌊', name: 'திருவானைக்கா', loc: 'திருச்சி அருகே', desc: 'ஜலலிங்கம் — அகிலாண்டேஸ்வரி' },
  { icon: '🌬️', name: 'காளஹஸ்தி', loc: 'ஆந்திரா', desc: 'வாயுலிங்கம் — ராகு கேது பரிகாரம்' },
  { icon: '🌍', name: 'கஞ்சிபுரம்', loc: 'காஞ்சிபுரம் மாவட்டம்', desc: 'பிருதிவிலிங்கம் — ஏகாம்பரேஸ்வரர்' },
];

const MOODS = ['பக்தி', 'ஞானம்', 'காப்பு', 'வைராக்கியம்'];

export default function ShivaScreen({ navigation }: any) {
  const [mood, setMood] = useState('பக்தி');
  const { isFavorite, toggleFavorite } = useApp();

  return (
    <View style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      <ScrollView showsVerticalScrollIndicator={false}>
        <LinearGradient colors={['#05051A', '#0D0D30', '#1A0800']} style={s.header}>
          <Text style={s.glyph}>நம</Text>
          <TouchableOpacity onPress={() => navigation.goBack()} style={s.back}>
            <Text style={s.backTxt}>←</Text>
          </TouchableOpacity>
          <Text style={s.icon}>🌙</Text>
          <Text style={s.name}>சிவன்</Text>
          <Text style={s.desc}>மகேஸ்வரன் · நடராஜன் · சம்பு · சங்கரன் · சோமசுந்தரம்{'\n'}அண்ட ஆதி, ஆனந்த நடனம் புரியும் தெய்வம்</Text>
          <View style={s.stats}>
            {[['10', 'நூல்கள்'], ['4000+', 'பாடல்கள்'], ['63', 'நாயன்மார்கள்']].map(([n, l]) => (
              <View key={l}><Text style={s.statN}>{n}</Text><Text style={s.statL}>{l}</Text></View>
            ))}
          </View>
        </LinearGradient>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.moodRow}>
          {MOODS.map(m => (
            <TouchableOpacity key={m} style={[s.chip, mood === m && s.chipOn]} onPress={() => setMood(m)}>
              <Text style={[s.chipTxt, mood === m && s.chipTxtOn]}>{m}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <SH title="📚 நூல்கள்" />
        <View style={s.bookGrid}>
          {SHIVA_BOOKS.map((b, i) => (
            <View key={i} style={s.bookCard}>
              <Text style={{ fontSize: 26, marginBottom: 6 }}>{b.icon}</Text>
              <Text style={s.bookTitle}>{b.title}</Text>
              <Text style={s.bookAuthor}>{b.author}</Text>
              <Text style={s.bookDesc}>{b.desc}</Text>
              <View style={s.bookBadge}><Text style={s.bookBadgeTxt}>{b.count}</Text></View>
            </View>
          ))}
        </View>

        <SH title="🎵 பாடல்கள்" count={SHIVA_SONGS.length} />
        {SHIVA_SONGS.length > 0 ? SHIVA_SONGS.map(song => (
          <TouchableOpacity key={song.id} style={s.songCard} onPress={() => navigation.navigate('SongDetail', { songId: song.id })}>
            <View style={[s.songIcon, { backgroundColor: C.shivaBg }]}><Text style={{ fontSize: 22 }}>🌙</Text></View>
            <View style={{ flex: 1 }}>
              <Text style={s.songTitle}>{song.title}</Text>
              <Text style={s.songMeta}>{song.temple || song.type}</Text>
            </View>
            <TouchableOpacity onPress={() => toggleFavorite(song.id)}>
              <Text style={{ fontSize: 16 }}>{isFavorite(song.id) ? '❤️' : '🔖'}</Text>
            </TouchableOpacity>
          </TouchableOpacity>
        )) : (
          <View style={s.empty}><Text style={s.emptyTxt}>பாடல்கள் விரைவில் சேர்க்கப்படும்</Text></View>
        )}

        <SH title="🛕 சிவன் கோயில்கள்" />
        {SHIVA_TEMPLES.map((t, i) => (
          <View key={i} style={s.templeCard}>
            <Text style={{ fontSize: 28, marginRight: 12 }}>{t.icon}</Text>
            <View style={{ flex: 1 }}>
              <Text style={s.templeName}>{t.name}</Text>
              <Text style={s.templeLoc}>{t.loc}</Text>
              <Text style={s.templeDesc}>{t.desc}</Text>
            </View>
          </View>
        ))}

        <SH title="🔱 பஞ்சாட்சர மந்திரம்" />
        <View style={s.mantraCard}>
          <Text style={s.mantraName}>நமச்சிவாய</Text>
          <Text style={s.mantraMeaning}>ந = பூமி · ம = நீர் · சி = நெருப்பு · வ = காற்று · ய = ஆகாயம்</Text>
          <Text style={s.mantraWhen}>பிரதோஷ நேரம் மற்றும் தினமும் 108 முறை சொல்லவும்</Text>
        </View>

        <View style={{ height: 80 }} />
      </ScrollView>
    </View>
  );
}

function SH({ title, count }: { title: string; count?: number }) {
  return (
    <View style={s.sh}>
      <Text style={s.shTitle}>{title}</Text>
      {count !== undefined && <Text style={s.shCount}>{count}</Text>}
      <View style={s.shLine} />
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  header: { paddingTop: 50, paddingBottom: 22, paddingHorizontal: S.lg, position: 'relative' },
  glyph: { position: 'absolute', right: -5, bottom: -15, fontSize: 100, color: 'rgba(159,168,218,0.06)' },
  back: { position: 'absolute', top: 50, left: S.lg, width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(159,168,218,0.15)', borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center', zIndex: 10 },
  backTxt: { color: '#9FA8DA', fontSize: 18, fontWeight: '700' },
  icon: { fontSize: 52, marginBottom: 10, marginTop: 40 },
  name: { color: '#7986CB', fontSize: 24, fontWeight: '700', marginBottom: 5 },
  desc: { color: C.txt2, fontSize: 12, lineHeight: 20 },
  stats: { flexDirection: 'row', gap: 18, marginTop: 14 },
  statN: { color: '#9FA8DA', fontSize: 20, fontWeight: '700' },
  statL: { color: C.txt3, fontSize: 9 },
  moodRow: { paddingHorizontal: S.lg, gap: 7, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: C.border2 },
  chip: { paddingHorizontal: 13, paddingVertical: 6, borderRadius: 20, borderWidth: 1, borderColor: 'rgba(121,134,203,0.3)' },
  chipOn: { backgroundColor: '#5C6BC0', borderColor: '#5C6BC0' },
  chipTxt: { color: '#9FA8DA', fontSize: 11 },
  chipTxtOn: { color: '#fff' },
  sh: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: S.lg, paddingTop: 18, paddingBottom: 10 },
  shTitle: { color: C.gold, fontSize: 14, fontWeight: '700' },
  shCount: { color: C.txt3, fontSize: 10 },
  shLine: { flex: 1, height: 1, backgroundColor: C.border },
  bookGrid: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: S.lg, gap: 10 },
  bookCard: { width: '47%', backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border2, padding: 12 },
  bookTitle: { color: C.txt, fontSize: 12, fontWeight: '600', marginBottom: 2 },
  bookAuthor: { color: C.txt3, fontSize: 10, marginBottom: 3 },
  bookDesc: { color: C.txt2, fontSize: 10, lineHeight: 16, marginBottom: 6 },
  bookBadge: { backgroundColor: 'rgba(121,134,203,0.15)', borderRadius: 10, paddingHorizontal: 8, paddingVertical: 2, alignSelf: 'flex-start' },
  bookBadgeTxt: { color: '#9FA8DA', fontSize: 9 },
  songCard: { flexDirection: 'row', backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border2, padding: 13, marginHorizontal: S.lg, marginBottom: 9, alignItems: 'center', gap: 12 },
  songIcon: { width: 42, height: 42, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  songTitle: { color: C.txt, fontSize: 13.5, fontWeight: '600' },
  songMeta: { color: C.txt3, fontSize: 11 },
  empty: { padding: 20, alignItems: 'center' },
  emptyTxt: { color: C.txt3, fontSize: 12 },
  templeCard: { flexDirection: 'row', backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border2, padding: 13, marginHorizontal: S.lg, marginBottom: 9, alignItems: 'flex-start' },
  templeName: { color: C.txt, fontSize: 14, fontWeight: '600', marginBottom: 2 },
  templeLoc: { color: C.txt3, fontSize: 11, marginBottom: 3 },
  templeDesc: { color: '#9FA8DA', fontSize: 10 },
  mantraCard: { marginHorizontal: S.lg, backgroundColor: 'rgba(92,107,192,0.1)', borderRadius: R.lg, borderWidth: 1, borderColor: 'rgba(92,107,192,0.3)', padding: S.xl },
  mantraName: { color: '#9FA8DA', fontSize: 28, fontWeight: '700', textAlign: 'center', marginBottom: 12 },
  mantraMeaning: { color: C.txt2, fontSize: 13, textAlign: 'center', lineHeight: 22, marginBottom: 8 },
  mantraWhen: { color: C.txt3, fontSize: 11, textAlign: 'center' },
});
