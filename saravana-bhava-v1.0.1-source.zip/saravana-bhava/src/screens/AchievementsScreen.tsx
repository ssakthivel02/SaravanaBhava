import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, StatusBar } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { C, S, R } from '../utils/theme';
import { useApp } from '../context/AppContext';

interface Achievement {
  id: string;
  icon: string;
  title: string;
  desc: string;
  condition: string;
  points: number;
  category: string;
}

const ALL_ACHIEVEMENTS: Achievement[] = [
  { id: 'first_read', icon: '📖', title: 'முதல் படிப்பு', desc: 'முதல் பாடலை படித்தீர்கள்', condition: 'read_1', points: 10, category: 'படிப்பு' },
  { id: 'five_reads', icon: '📚', title: 'ஐந்து பாடல்கள்', desc: '5 பாடல்களை படித்தீர்கள்', condition: 'read_5', points: 25, category: 'படிப்பு' },
  { id: 'first_fav', icon: '❤️', title: 'முதல் சேமிப்பு', desc: 'முதல் பாடலை சேமித்தீர்கள்', condition: 'fav_1', points: 10, category: 'சேமிப்பு' },
  { id: 'five_favs', icon: '💝', title: 'ஐந்து சேமிப்பு', desc: '5 பாடல்களை சேமித்தீர்கள்', condition: 'fav_5', points: 30, category: 'சேமிப்பு' },
  { id: 'ten_favs', icon: '💖', title: 'பத்து சேமிப்பு', desc: '10 பாடல்களை சேமித்தீர்கள்', condition: 'fav_10', points: 50, category: 'சேமிப்பு' },
  { id: 'streak_3', icon: '🔥', title: '3 நாள் தொடர்ச்சி', desc: '3 நாட்கள் தொடர்ந்து படித்தீர்கள்', condition: 'streak_3', points: 20, category: 'தொடர்ச்சி' },
  { id: 'streak_7', icon: '🌟', title: '7 நாள் தொடர்ச்சி', desc: 'ஒரு வாரம் தொடர்ந்து படித்தீர்கள்', condition: 'streak_7', points: 50, category: 'தொடர்ச்சி' },
  { id: 'streak_30', icon: '🏆', title: '30 நாள் தொடர்ச்சி', desc: 'ஒரு மாதம் தொடர்ந்து படித்தீர்கள்', condition: 'streak_30', points: 200, category: 'தொடர்ச்சி' },
  { id: 'quiz_first', icon: '🎯', title: 'முதல் வினாடி வினா', desc: 'முதல் வினாடி வினாவில் பங்கேற்றீர்கள்', condition: 'quiz_1', points: 15, category: 'வினாடி வினா' },
  { id: 'quiz_perfect', icon: '🥇', title: 'சரியான மதிப்பெண்', desc: 'வினாடி வினாவில் 10/10 பெற்றீர்கள்', condition: 'quiz_perfect', points: 100, category: 'வினாடி வினா' },
  { id: 'murugan_fan', icon: '🦚', title: 'முருகன் பக்தர்', desc: 'முருகன் பக்கத்தை திறந்தீர்கள்', condition: 'murugan_page', points: 15, category: 'தெய்வங்கள்' },
  { id: 'all_gods', icon: '🙏', title: 'எல்லா தெய்வங்கள்', desc: 'அனைத்து தெய்வ பக்கங்களையும் திறந்தீர்கள்', condition: 'all_gods', points: 75, category: 'தெய்வங்கள்' },
  { id: 'tiruppugazh_fan', icon: '🎵', title: 'திருப்புகழ் பக்தர்', desc: '5 திருப்புகழ் பாடல்களை படித்தீர்கள்', condition: 'tiruppugazh_5', points: 40, category: 'படிப்பு' },
  { id: 'share_verse', icon: '📤', title: 'பகிர்வு', desc: 'ஒரு பாடலை பகிர்ந்தீர்கள்', condition: 'share_1', points: 10, category: 'பகிர்வு' },
];

export default function AchievementsScreen({ navigation }: any) {
  const { favorites, readingStreak, recentlyViewed } = useApp();
  const [quizHighScore, setQuizHighScore] = useState(0);
  const [quizPlayed, setQuizPlayed] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem('sb_quiz_highscore').then(v => { if (v) { setQuizHighScore(parseInt(v)); setQuizPlayed(true); } });
  }, []);

  const isUnlocked = (a: Achievement): boolean => {
    switch (a.condition) {
      case 'read_1': return recentlyViewed.length >= 1;
      case 'read_5': return recentlyViewed.length >= 5;
      case 'fav_1': return favorites.length >= 1;
      case 'fav_5': return favorites.length >= 5;
      case 'fav_10': return favorites.length >= 10;
      case 'streak_3': return readingStreak >= 3;
      case 'streak_7': return readingStreak >= 7;
      case 'streak_30': return readingStreak >= 30;
      case 'quiz_1': return quizPlayed;
      case 'quiz_perfect': return quizHighScore >= 10;
      case 'murugan_page': return true; // Unlocked by visiting this screen
      case 'tiruppugazh_5': return recentlyViewed.filter(id => id.startsWith('tp')).length >= 5;
      case 'all_gods': return false; // Requires visiting all god pages
      case 'share_1': return false; // Requires share action
      default: return false;
    }
  };

  const unlockedList = ALL_ACHIEVEMENTS.filter(a => isUnlocked(a));
  const lockedList = ALL_ACHIEVEMENTS.filter(a => !isUnlocked(a));
  const totalPoints = unlockedList.reduce((sum, a) => sum + a.points, 0);
  const maxPoints = ALL_ACHIEVEMENTS.reduce((sum, a) => sum + a.points, 0);

  const categories = [...new Set(ALL_ACHIEVEMENTS.map(a => a.category))];

  return (
    <View style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      <View style={s.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={s.back}>
          <Text style={s.backTxt}>←</Text>
        </TouchableOpacity>
        <Text style={s.headerTitle}>🏆 சாதனைகள்</Text>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.content}>
        {/* Summary */}
        <View style={s.summaryCard}>
          <View style={s.summaryRow}>
            <View style={s.summaryItem}>
              <Text style={s.summaryNum}>{unlockedList.length}</Text>
              <Text style={s.summaryLabel}>திறக்கப்பட்டவை</Text>
            </View>
            <View style={s.summaryDivider} />
            <View style={s.summaryItem}>
              <Text style={s.summaryNum}>{ALL_ACHIEVEMENTS.length}</Text>
              <Text style={s.summaryLabel}>மொத்தம்</Text>
            </View>
            <View style={s.summaryDivider} />
            <View style={s.summaryItem}>
              <Text style={s.summaryNum}>{totalPoints}</Text>
              <Text style={s.summaryLabel}>புள்ளிகள்</Text>
            </View>
          </View>
          <View style={s.overallBar}>
            <View style={[s.overallFill, { width: `${(unlockedList.length / ALL_ACHIEVEMENTS.length) * 100}%` }]} />
          </View>
          <Text style={s.overallTxt}>{Math.round((unlockedList.length / ALL_ACHIEVEMENTS.length) * 100)}% முடிந்தது</Text>
        </View>

        {/* Unlocked */}
        {unlockedList.length > 0 && (
          <>
            <Text style={s.sectionTitle}>✅ திறக்கப்பட்டவை ({unlockedList.length})</Text>
            {unlockedList.map(a => (
              <View key={a.id} style={s.achievementCard}>
                <View style={s.achievementIcon}><Text style={{ fontSize: 28 }}>{a.icon}</Text></View>
                <View style={{ flex: 1 }}>
                  <Text style={s.achievementTitle}>{a.title}</Text>
                  <Text style={s.achievementDesc}>{a.desc}</Text>
                  <View style={s.categoryBadge}><Text style={s.categoryTxt}>{a.category}</Text></View>
                </View>
                <View style={s.pointsBadge}>
                  <Text style={s.pointsTxt}>+{a.points}</Text>
                  <Text style={s.pointsLabel}>புள்.</Text>
                </View>
              </View>
            ))}
          </>
        )}

        {/* Locked */}
        {lockedList.length > 0 && (
          <>
            <Text style={s.sectionTitle}>🔒 திறக்கப்படாதவை ({lockedList.length})</Text>
            {lockedList.map(a => (
              <View key={a.id} style={[s.achievementCard, s.achievementLocked]}>
                <View style={[s.achievementIcon, s.achievementIconLocked]}><Text style={{ fontSize: 28, opacity: 0.4 }}>{a.icon}</Text></View>
                <View style={{ flex: 1 }}>
                  <Text style={[s.achievementTitle, s.lockedTxt]}>{a.title}</Text>
                  <Text style={[s.achievementDesc, s.lockedTxt]}>{a.desc}</Text>
                </View>
                <View style={s.lockedBadge}>
                  <Text style={s.lockedBadgeTxt}>{a.points} புள்.</Text>
                </View>
              </View>
            ))}
          </>
        )}

        <View style={{ height: 80 }} />
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  header: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: S.lg, paddingTop: 52, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: C.border2 },
  back: { width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(212,168,32,0.15)', borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center' },
  backTxt: { color: C.gold, fontSize: 18, fontWeight: '700' },
  headerTitle: { color: C.gold, fontSize: 18, fontWeight: '700' },
  content: { paddingHorizontal: S.lg, paddingTop: S.lg },
  summaryCard: { backgroundColor: C.card, borderRadius: R.lg, borderWidth: 1, borderColor: C.border, padding: S.lg, marginBottom: 20 },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-around', marginBottom: 16 },
  summaryItem: { alignItems: 'center' },
  summaryNum: { color: C.saffron, fontSize: 28, fontWeight: '700' },
  summaryLabel: { color: C.txt3, fontSize: 10, marginTop: 2 },
  summaryDivider: { width: 1, backgroundColor: C.border2 },
  overallBar: { height: 6, backgroundColor: C.bg3, borderRadius: 3, overflow: 'hidden', marginBottom: 6 },
  overallFill: { height: '100%', backgroundColor: C.gold, borderRadius: 3 },
  overallTxt: { color: C.txt3, fontSize: 11, textAlign: 'center' },
  sectionTitle: { color: C.txt3, fontSize: 11, letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 12, marginTop: 4 },
  achievementCard: { flexDirection: 'row', backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border, padding: 13, marginBottom: 9, alignItems: 'center', gap: 12 },
  achievementLocked: { opacity: 0.5 },
  achievementIcon: { width: 52, height: 52, borderRadius: 26, backgroundColor: 'rgba(212,168,32,0.12)', alignItems: 'center', justifyContent: 'center' },
  achievementIconLocked: { backgroundColor: C.bg3 },
  achievementTitle: { color: C.txt, fontSize: 14, fontWeight: '600', marginBottom: 2 },
  achievementDesc: { color: C.txt2, fontSize: 11, lineHeight: 18, marginBottom: 4 },
  lockedTxt: { color: C.txt3 },
  categoryBadge: { backgroundColor: 'rgba(212,168,32,0.1)', borderRadius: 10, paddingHorizontal: 8, paddingVertical: 2, alignSelf: 'flex-start' },
  categoryTxt: { color: C.gold, fontSize: 9 },
  pointsBadge: { alignItems: 'center', backgroundColor: 'rgba(240,106,10,0.15)', borderRadius: R.sm, padding: 8, minWidth: 44 },
  pointsTxt: { color: C.saffron, fontSize: 14, fontWeight: '700' },
  pointsLabel: { color: C.txt3, fontSize: 9 },
  lockedBadge: { alignItems: 'center', backgroundColor: C.bg3, borderRadius: R.sm, padding: 8, minWidth: 44 },
  lockedBadgeTxt: { color: C.txt3, fontSize: 11 },
});
