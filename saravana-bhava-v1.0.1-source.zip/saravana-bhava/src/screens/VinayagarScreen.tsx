import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, StatusBar } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { C, S, R } from '../utils/theme';
import { SONGS } from '../data/songs';
import { useApp } from '../context/AppContext';

const VINAYAGAR_BOOKS = [
  { icon: '🐘', title: 'விநாயகர் அகவல்', author: 'ஔவையார்', count: '1 நூல்', desc: 'விநாயகரை போற்றும் ஔவையாரின் அகவல்' },
  { icon: '📿', title: 'கணபதி 108 போற்றி', author: 'பாரம்பரியம்', count: '108 போற்றிகள்', desc: 'விநாயகரின் 108 திருநாமங்கள்' },
  { icon: '✨', title: 'கணேஷ பஞ்சரத்னம்', author: 'ஆதி சங்கரர்', count: '5 ஸ்லோகங்கள்', desc: 'ஆதி சங்கரர் இயற்றிய 5 ஸ்லோகங்கள்' },
  { icon: '🌟', title: 'முதல் மொழி', author: 'ஔவையார்', count: 'பல பாடல்கள்', desc: 'ஔவையாரின் விநாயகர் பாடல்கள்' },
  { icon: '🙏', title: 'விக்னேஸ்வர ஸ்தோத்ரம்', author: 'பாரம்பரியம்', count: '20+ ஸ்லோகங்கள்', desc: 'தடைகளை நீக்கும் ஸ்தோத்ரம்' },
];

const VINAYAGAR_SONGS = SONGS.filter(s => s.god === 'vinayagar');

const VINAYAGAR_FORMS = [
  { name: 'விக்னேஸ்வரர்', desc: 'தடைகளை நீக்குபவர்', icon: '🚫' },
  { name: 'கணபதி', desc: 'கணங்களின் தலைவர்', icon: '👑' },
  { name: 'கஜானனர்', desc: 'யானை முகத்தவர்', icon: '🐘' },
  { name: 'லம்போதரர்', desc: 'பெரிய வயிறுடையவர்', icon: '🌕' },
  { name: 'ஏகதந்தர்', desc: 'ஒரே தந்தமுடையவர்', icon: '🦷' },
  { name: 'விநாயகர்', desc: 'தலைவர் இல்லாதவர்', icon: '🌟' },
];

const VINAYAGAR_TEMPLES = [
  { name: 'பிள்ளையார்பட்டி', loc: 'சிவகங்கை மாவட்டம்', desc: 'கற்பக விநாயகர் — மிகப் பழமையான கோயில்' },
  { name: 'திருச்செங்கோடு', loc: 'நாமக்கல் மாவட்டம்', desc: 'அர்த்தநாரீஸ்வரர் கோயில்' },
  { name: 'திருவண்ணாமலை', loc: 'திருவண்ணாமலை', desc: 'அபீதகுசாம்பிகை கோயில் விநாயகர்' },
  { name: 'காஞ்சிபுரம்', loc: 'காஞ்சிபுரம்', desc: 'வரசித்தி விநாயகர்' },
];

export default function VinayagarScreen({ navigation }: any) {
  const { isFavorite, toggleFavorite } = useApp();

  return (
    <View style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      <ScrollView showsVerticalScrollIndicator={false}>
        <LinearGradient colors={['#1A0E00', '#2A1500', '#1A0800']} style={s.header}>
          <Text style={s.glyph}>கண</Text>
          <TouchableOpacity onPress={() => navigation.goBack()} style={s.back}>
            <Text style={s.backTxt}>←</Text>
          </TouchableOpacity>
          <Text style={s.icon}>🐘</Text>
          <Text style={s.name}>விநாயகர்</Text>
          <Text style={s.desc}>கணபதி · கஜானனர் · விக்னேஸ்வரர் · லம்போதரர்{'\n'}முதல் வணக்கம் பெறும் தெய்வம் — தடைகளை நீக்குபவர்</Text>
          <View style={s.stats}>
            {[['5', 'நூல்கள்'], ['108', 'போற்றிகள்'], ['6', 'வடிவங்கள்']].map(([n, l]) => (
              <View key={l}><Text style={s.statN}>{n}</Text><Text style={s.statL}>{l}</Text></View>
            ))}
          </View>
        </LinearGradient>

        <SH title="📚 நூல்கள்" />
        <View style={s.bookGrid}>
          {VINAYAGAR_BOOKS.map((b, i) => (
            <View key={i} style={s.bookCard}>
              <Text style={{ fontSize: 26, marginBottom: 6 }}>{b.icon}</Text>
              <Text style={s.bookTitle}>{b.title}</Text>
              <Text style={s.bookAuthor}>{b.author}</Text>
              <Text style={s.bookDesc}>{b.desc}</Text>
              <View style={s.bookBadge}><Text style={s.bookBadgeTxt}>{b.count}</Text></View>
            </View>
          ))}
        </View>

        <SH title="🎵 பாடல்கள்" count={VINAYAGAR_SONGS.length} />
        {VINAYAGAR_SONGS.map(song => (
          <TouchableOpacity key={song.id} style={s.songCard} onPress={() => navigation.navigate('SongDetail', { songId: song.id })}>
            <View style={[s.songIcon, { backgroundColor: '#3A2000' }]}><Text style={{ fontSize: 22 }}>🐘</Text></View>
            <View style={{ flex: 1 }}>
              <Text style={s.songTitle}>{song.title}</Text>
              <Text style={s.songMeta}>{song.temple || song.type}</Text>
            </View>
            <TouchableOpacity onPress={() => toggleFavorite(song.id)}>
              <Text style={{ fontSize: 16 }}>{isFavorite(song.id) ? '❤️' : '🔖'}</Text>
            </TouchableOpacity>
          </TouchableOpacity>
        ))}

        <SH title="✨ விநாயகரின் வடிவங்கள்" />
        <View style={s.formsGrid}>
          {VINAYAGAR_FORMS.map((f, i) => (
            <View key={i} style={s.formCard}>
              <Text style={{ fontSize: 28, marginBottom: 6 }}>{f.icon}</Text>
              <Text style={s.formName}>{f.name}</Text>
              <Text style={s.formDesc}>{f.desc}</Text>
            </View>
          ))}
        </View>

        <SH title="🛕 முக்கிய கோயில்கள்" />
        {VINAYAGAR_TEMPLES.map((t, i) => (
          <View key={i} style={s.templeCard}>
            <Text style={{ fontSize: 28, marginRight: 12 }}>🐘</Text>
            <View style={{ flex: 1 }}>
              <Text style={s.templeName}>{t.name}</Text>
              <Text style={s.templeLoc}>{t.loc}</Text>
              <Text style={s.templeDesc}>{t.desc}</Text>
            </View>
          </View>
        ))}

        <SH title="📿 விநாயகர் மந்திரம்" />
        <View style={s.mantraCard}>
          <Text style={s.mantraName}>ஓம் கணேஷாய நமஹ</Text>
          <Text style={s.mantraMeaning}>கணங்களின் தலைவரான விநாயகருக்கு வணக்கம்</Text>
          <Text style={s.mantraWhen}>எந்த செயலையும் தொடங்கும் முன் 21 முறை சொல்லவும்</Text>
        </View>

        <View style={{ height: 80 }} />
      </ScrollView>
    </View>
  );
}

function SH({ title, count }: { title: string; count?: number }) {
  return (
    <View style={s.sh}>
      <Text style={s.shTitle}>{title}</Text>
      {count !== undefined && <Text style={s.shCount}>{count}</Text>}
      <View style={s.shLine} />
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  header: { paddingTop: 50, paddingBottom: 22, paddingHorizontal: S.lg, position: 'relative' },
  glyph: { position: 'absolute', right: -5, bottom: -15, fontSize: 100, color: 'rgba(212,168,32,0.05)' },
  back: { position: 'absolute', top: 50, left: S.lg, width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(212,168,32,0.15)', borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center', zIndex: 10 },
  backTxt: { color: C.saffron, fontSize: 18, fontWeight: '700' },
  icon: { fontSize: 52, marginBottom: 10, marginTop: 40 },
  name: { color: '#FFB74D', fontSize: 24, fontWeight: '700', marginBottom: 5 },
  desc: { color: C.txt2, fontSize: 12, lineHeight: 20 },
  stats: { flexDirection: 'row', gap: 18, marginTop: 14 },
  statN: { color: '#FFB74D', fontSize: 20, fontWeight: '700' },
  statL: { color: C.txt3, fontSize: 9 },
  sh: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: S.lg, paddingTop: 18, paddingBottom: 10 },
  shTitle: { color: C.gold, fontSize: 14, fontWeight: '700' },
  shCount: { color: C.txt3, fontSize: 10 },
  shLine: { flex: 1, height: 1, backgroundColor: C.border },
  bookGrid: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: S.lg, gap: 10 },
  bookCard: { width: '47%', backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border2, padding: 12 },
  bookTitle: { color: C.txt, fontSize: 12, fontWeight: '600', marginBottom: 2 },
  bookAuthor: { color: C.txt3, fontSize: 10, marginBottom: 3 },
  bookDesc: { color: C.txt2, fontSize: 10, lineHeight: 16, marginBottom: 6 },
  bookBadge: { backgroundColor: 'rgba(255,183,77,0.15)', borderRadius: 10, paddingHorizontal: 8, paddingVertical: 2, alignSelf: 'flex-start' },
  bookBadgeTxt: { color: '#FFB74D', fontSize: 9 },
  songCard: { flexDirection: 'row', backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border2, padding: 13, marginHorizontal: S.lg, marginBottom: 9, alignItems: 'center', gap: 12 },
  songIcon: { width: 42, height: 42, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  songTitle: { color: C.txt, fontSize: 13.5, fontWeight: '600' },
  songMeta: { color: C.txt3, fontSize: 11 },
  formsGrid: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: S.lg, gap: 10 },
  formCard: { width: '47%', backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: 'rgba(255,183,77,0.2)', padding: 12 },
  formName: { color: '#FFB74D', fontSize: 13, fontWeight: '700', marginBottom: 4 },
  formDesc: { color: C.txt2, fontSize: 10, lineHeight: 16 },
  templeCard: { flexDirection: 'row', backgroundColor: C.card, borderRadius: R.md, borderWidth: 1, borderColor: C.border2, padding: 13, marginHorizontal: S.lg, marginBottom: 9, alignItems: 'flex-start' },
  templeName: { color: C.txt, fontSize: 14, fontWeight: '600', marginBottom: 2 },
  templeLoc: { color: C.txt3, fontSize: 11, marginBottom: 3 },
  templeDesc: { color: '#FFB74D', fontSize: 10 },
  mantraCard: { marginHorizontal: S.lg, backgroundColor: 'rgba(255,152,0,0.1)', borderRadius: R.lg, borderWidth: 1, borderColor: 'rgba(255,152,0,0.3)', padding: S.xl },
  mantraName: { color: '#FFB74D', fontSize: 22, fontWeight: '700', textAlign: 'center', marginBottom: 12 },
  mantraMeaning: { color: C.txt2, fontSize: 13, textAlign: 'center', lineHeight: 22, marginBottom: 8 },
  mantraWhen: { color: C.txt3, fontSize: 11, textAlign: 'center' },
});
