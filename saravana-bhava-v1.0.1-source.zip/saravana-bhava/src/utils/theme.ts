export const C = {
  // Backgrounds
  bg: '#050200',
  bg2: '#0C0500',
  bg3: '#140800',
  card: '#180B02',
  card2: '#200E03',
  // Gold/Saffron palette
  gold: '#D4A820',
  gold2: '#ECC040',
  gold3: '#F8D560',
  saffron: '#F06A0A',
  saffron2: '#FF7E1E',
  // Borders
  border: 'rgba(212,168,32,0.2)',
  border2: 'rgba(212,168,32,0.09)',
  // Glows
  goldGlow: 'rgba(212,168,32,0.18)',
  saffronGlow: 'rgba(240,106,10,0.15)',
  // Text
  txt: '#F2EAD2',
  txt2: '#C0A878',
  txt3: '#7A5C32',
  // God backgrounds
  muruganBg: '#0E2A18',
  shivaBg: '#0E0E38',
  perumalBg: '#0A1E38',
  sakthiBg: '#300820',
  siddharBg: '#181808',
  // Utility
  white: '#FFFFFF',
  error: '#FF4444',
  success: '#44BB44',
};

export const S = {
  xs: 4, sm: 8, md: 12, lg: 16, xl: 20, xxl: 28,
};

export const R = {
  sm: 8, md: 12, lg: 16, xl: 20, full: 999,
};
