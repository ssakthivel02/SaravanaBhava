export interface AppContent {
  id: string;
  title_ta: string;
  title_en?: string;
  deity?: string;
  category: string;
  sub_category?: string;
  author?: string;
  source_name?: string;
  source_file?: string;
  source_page?: number;
  content_ta: string;
  transliteration_en?: string;
  meaning_ta?: string;
  meaning_en?: string;
  benefits_traditional?: string[];
  chant_guidance?: string;
  language_master: string;
  translation_status: 'verified' | 'auto_translation' | 'needs_review' | 'not_available';
  verification_status: 'verified' | 'needs_review' | 'do_not_use';
  publish_status: 'draft' | 'published';
  audio_status: 'not_available' | 'youtube_search' | 'local_audio' | 'external_verified';
  created_from_import?: boolean;
}

export interface Temple {
  id: string;
  content_type: 'temple';
  primary_deity: string;
  classification: {
    god: string;
    section: string;
    country: string;
    state_province: string;
    city_town: string;
    category: string;
  };
  names: {
    english: string;
    tamil_or_local: string;
  };
  location: {
    country: string;
    state_province: string;
    city_town: string;
    full_address: string;
    gps_latitude?: number;
    gps_longitude?: number;
    nearest_airport?: string;
  };
  contact: {
    phone?: string;
    email_website?: string;
  };
  temple_details: {
    main_deity_or_form: string;
    historical_period?: string;
    significance_short?: string;
    annual_festival?: string;
    festival_month?: string;
    daily_timings_am?: string;
    daily_timings_pm?: string;
    annual_visitors_est?: string;
    daily_maintenance?: string;
    renovation_status?: string;
    admin_type?: string;
    special_features?: string;
    facilities?: string;
  };
  app_workflow: {
    import_status: 'imported' | 'manual';
    classification_status: 'classified_initial' | 'classified_verified';
    verification_status: 'verified' | 'needs_review' | 'do_not_use';
    publish_status: 'not_ready_for_final_publish' | 'ready_for_publish' | 'published';
    display_status: 'listed_needs_review' | 'listed_verified';
    display_in_app: boolean;
    display_label: string;
    priority: 'high' | 'normal' | 'low';
    missing_or_unverified_fields?: string[];
    source?: string;
    last_reviewed?: string;
    review_notes?: string;
  };
}
