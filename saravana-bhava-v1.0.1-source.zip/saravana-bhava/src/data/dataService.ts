import { AppContent, Temple } from './models';
import appContentRecords from './app_content_records_needs_review.json';
import muruganTemples from './murugan_temples_import_records_needs_review.json';

export const getAppContent = (): AppContent[] => {
  return appContentRecords as AppContent[];
};

export const getMuruganTemples = (): Temple[] => {
  return muruganTemples as Temple[];
};

export const searchContent = (query: string): AppContent[] => {
  const lowerCaseQuery = query.toLowerCase();
  return getAppContent().filter(item => 
    item.title_ta.toLowerCase().includes(lowerCaseQuery) ||
    (item.title_en && item.title_en.toLowerCase().includes(lowerCaseQuery)) ||
    (item.deity && item.deity.toLowerCase().includes(lowerCaseQuery)) ||
    item.category.toLowerCase().includes(lowerCaseQuery) ||
    item.content_ta.toLowerCase().includes(lowerCaseQuery)
  );
};

export const searchTemples = (query: string): Temple[] => {
  const lowerCaseQuery = query.toLowerCase();
  return getMuruganTemples().filter(temple => 
    temple.names.english.toLowerCase().includes(lowerCaseQuery) ||
    temple.names.tamil_or_local.toLowerCase().includes(lowerCaseQuery) ||
    temple.classification.city_town.toLowerCase().includes(lowerCaseQuery) ||
    temple.classification.state_province.toLowerCase().includes(lowerCaseQuery) ||
    temple.temple_details.main_deity_or_form.toLowerCase().includes(lowerCaseQuery)
  );
};
