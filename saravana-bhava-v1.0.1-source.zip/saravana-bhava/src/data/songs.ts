import { AppContent } from './models';
import { getAppContent } from './dataService';

export const SONGS: AppContent[] = getAppContent();
