import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface AppContextType {
  favorites: string[];
  toggleFavorite: (id: string) => void;
  isFavorite: (id: string) => boolean;
  fontScale: number;
  setFontScale: (scale: number) => void;
  readingStreak: number;
  updateStreak: () => void;
  recentlyViewed: string[];
  addToRecentlyViewed: (id: string) => void;
  currentAudioId: string | null;
  setCurrentAudioId: (id: string | null) => void;
  isPlaying: boolean;
  setIsPlaying: (v: boolean) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [favorites, setFavorites] = useState<string[]>([]);
  const [fontScale, setFontScaleState] = useState(1.0);
  const [readingStreak, setReadingStreak] = useState(0);
  const [lastReadDate, setLastReadDate] = useState('');
  const [recentlyViewed, setRecentlyViewed] = useState<string[]>([]);
  const [currentAudioId, setCurrentAudioId] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    try {
      const [favs, fs, streak, lastDate, recent] = await Promise.all([
        AsyncStorage.getItem('sb_favorites'),
        AsyncStorage.getItem('sb_fontscale'),
        AsyncStorage.getItem('sb_streak'),
        AsyncStorage.getItem('sb_lastread'),
        AsyncStorage.getItem('sb_recent'),
      ]);
      if (favs) setFavorites(JSON.parse(favs));
      if (fs) setFontScaleState(parseFloat(fs));
      if (streak) setReadingStreak(parseInt(streak));
      if (lastDate) setLastReadDate(lastDate);
      if (recent) setRecentlyViewed(JSON.parse(recent));
    } catch (e) {}
  };

  const toggleFavorite = useCallback(async (id: string) => {
    setFavorites(prev => {
      const n = prev.includes(id) ? prev.filter(f => f !== id) : [...prev, id];
      AsyncStorage.setItem('sb_favorites', JSON.stringify(n));
      return n;
    });
  }, []);

  const isFavorite = useCallback((id: string) => favorites.includes(id), [favorites]);

  const setFontScale = useCallback(async (scale: number) => {
    const c = Math.min(1.5, Math.max(0.7, scale));
    setFontScaleState(c);
    await AsyncStorage.setItem('sb_fontscale', c.toString());
  }, []);

  const updateStreak = useCallback(async () => {
    const today = new Date().toDateString();
    const yesterday = new Date(Date.now() - 86400000).toDateString();
    if (lastReadDate === today) return;
    const newStreak = lastReadDate === yesterday ? readingStreak + 1 : 1;
    setReadingStreak(newStreak);
    setLastReadDate(today);
    await AsyncStorage.setItem('sb_streak', newStreak.toString());
    await AsyncStorage.setItem('sb_lastread', today);
  }, [lastReadDate, readingStreak]);

  const addToRecentlyViewed = useCallback(async (id: string) => {
    setRecentlyViewed(prev => {
      const n = [id, ...prev.filter(x => x !== id)].slice(0, 10);
      AsyncStorage.setItem('sb_recent', JSON.stringify(n));
      return n;
    });
  }, []);

  return (
    <AppContext.Provider value={{ favorites, toggleFavorite, isFavorite, fontScale, setFontScale, readingStreak, updateStreak, recentlyViewed, addToRecentlyViewed, currentAudioId, setCurrentAudioId, isPlaying, setIsPlaying }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be inside AppProvider');
  return ctx;
};
