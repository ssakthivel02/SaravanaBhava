import React, { useEffect, useState, useRef } from 'react';
import { View, Text, StyleSheet, StatusBar, Animated } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { AppProvider } from './src/context/AppContext';
import { C } from './src/utils/theme';
import { getAppContent, getMuruganTemples } from './src/data/dataService';
import AISearchScreen from './src/screens/AISearchScreen';
import TempleListScreen from './src/screens/TempleListScreen';

// Core Screens
import HomeScreen from './src/screens/HomeScreen';
import LibraryScreen from './src/screens/LibraryScreen';
import SongDetailScreen from './src/screens/SongDetailScreen';
import BookmarksScreen from './src/screens/BookmarksScreen';
import SettingsScreen from './src/screens/SettingsScreen';

// God Screens
import MuruganScreen from './src/screens/MuruganScreen';
import ShivaScreen from './src/screens/ShivaScreen';
import PerumalScreen from './src/screens/PerumalScreen';
import SakthiScreen from './src/screens/SakthiScreen';
import SiddharsScreen from './src/screens/SiddharsScreen';
import VinayagarScreen from './src/screens/VinayagarScreen';

// Feature Screens
import QuizScreen from './src/screens/QuizScreen';
import ProfileScreen from './src/screens/ProfileScreen';
import RewardsScreen from './src/screens/RewardsScreen';
import AchievementsScreen from './src/screens/AchievementsScreen';



// Load data on app start
const appContent = getAppContent();
const muruganTemples = getMuruganTemples();

console.log(`[App] Loaded ${appContent.length} content items.`);
console.log(`[App] Loaded ${muruganTemples.length} Murugan temples.`);

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

function SplashScreen({ onDone }: { onDone: () => void }) {
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.7)).current;
  const progressAnim = useRef(new Animated.Value(0)).current;
  const glowAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 700, useNativeDriver: true }),
      Animated.spring(scaleAnim, { toValue: 1, tension: 40, friction: 6, useNativeDriver: true }),
    ]).start();
    Animated.loop(Animated.sequence([
      Animated.timing(glowAnim, { toValue: 1, duration: 1200, useNativeDriver: false }),
      Animated.timing(glowAnim, { toValue: 0, duration: 1200, useNativeDriver: false }),
    ])).start();
    Animated.timing(progressAnim, { toValue: 1, duration: 2500, useNativeDriver: false }).start(() => {
      Animated.timing(fadeAnim, { toValue: 0, duration: 500, useNativeDriver: true }).start(onDone);
    });
  }, []);

  const omColor = glowAnim.interpolate({ inputRange: [0, 1], outputRange: [C.gold, C.saffron] });

  return (
    <View style={splash.container}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      <Animated.View style={{ opacity: fadeAnim, transform: [{ scale: scaleAnim }], alignItems: 'center' }}>
        <Animated.Text style={[splash.om, { color: omColor }]}>ஓம்</Animated.Text>
        <Text style={splash.title}>சரவண பவ</Text>
        <Text style={splash.subtitle}>Saravana Bhava</Text>
        <Text style={splash.tagline}>முருகன் பக்தி · Murugan Bhakti</Text>
        <View style={splash.progressBar}>
          <Animated.View style={[splash.progressFill, {
            width: progressAnim.interpolate({ inputRange: [0, 1], outputRange: ['0%', '100%'] }),
          }]} />
        </View>
        <Text style={splash.loading}>ஏற்றுகிறது…</Text>
      </Animated.View>
      <Text style={splash.version}>v1.0.1 · Android API 36</Text>
    </View>
  );
}

function TabBar({ state, navigation }: any) {
  const tabs = [
    { name: 'Home', icon: '🏠', label: 'முகப்பு' },
    { name: 'Library', icon: '📚', label: 'நூலகம்' },
    { name: 'Bookmarks', icon: '🔖', label: 'சேமிப்பு' },
    { name: 'Settings', icon: '⚙️', label: 'அமைப்பு' },
    { name: 'AISearch', icon: '🔍', label: 'AI குரு' },
    { name: 'Temples', icon: '🛕', label: 'கோயில்கள்' }
  ];
  return (
    <View style={tab.bar}>
      {state.routes.map((route: any, i: number) => {
        const t = tabs[i];
        const active = state.index === i;
        return (
          <View key={route.key} style={tab.item}>
            {active && <View style={tab.indicator} />}
            <Text style={[tab.icon, active && tab.iconActive]} onPress={() => navigation.navigate(route.name)}>{t?.icon}</Text>
            <Text style={[tab.label, active && tab.labelActive]} onPress={() => navigation.navigate(route.name)}>{t?.label}</Text>
          </View>
        );
      })}
    </View>
  );
}

function MainTabs() {
  return (
    <Tab.Navigator tabBar={p => <TabBar {...p} />} screenOptions={{ headerShown: false }}>
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Library" component={LibraryScreen} />
      <Tab.Screen name="Bookmarks" component={BookmarksScreen} />
      <Tab.Screen name="Settings" component={SettingsScreen} />
    </Tab.Navigator>
  );
}

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  if (showSplash) return <SplashScreen onDone={() => setShowSplash(false)} />;
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <AppProvider>
          <NavigationContainer>
            <Stack.Navigator screenOptions={{ headerShown: false }}>
              {/* Main Tabs */}
              <Stack.Screen name="Main" component={MainTabs} />

              {/* Song Detail */}
              <Stack.Screen name="SongDetail" component={SongDetailScreen} />

              {/* God Screens — ALL REGISTERED */}
              <Stack.Screen name="Murugan" component={MuruganScreen} />
              <Stack.Screen name="Shiva" component={ShivaScreen} />
              <Stack.Screen name="Perumal" component={PerumalScreen} />
              <Stack.Screen name="Sakthi" component={SakthiScreen} />
              <Stack.Screen name="Siddhars" component={SiddharsScreen} />
              <Stack.Screen name="Vinayagar" component={VinayagarScreen} />

              {/* Feature Screens — ALL REGISTERED */}
              <Stack.Screen name="Quiz" component={QuizScreen} />
              <Stack.Screen name="Profile" component={ProfileScreen} />
              <Stack.Screen name="Rewards" component={RewardsScreen} />
              <Stack.Screen name="Achievements" component={AchievementsScreen} />
              <Stack.Screen name="AISearch" component={AISearchScreen} />
              <Stack.Screen name="Temples" component={TempleListScreen} />
            </Stack.Navigator>
          </NavigationContainer>
        </AppProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

const splash = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center' },
  om: { fontSize: 90, marginBottom: 14 },
  title: { fontSize: 32, fontWeight: '700', color: C.gold, marginBottom: 4 },
  subtitle: { fontSize: 18, color: C.gold2, letterSpacing: 3, marginBottom: 6 },
  tagline: { fontSize: 12, color: C.txt3, letterSpacing: 1.5, marginBottom: 32 },
  progressBar: { width: 220, height: 3, backgroundColor: C.border, borderRadius: 2, overflow: 'hidden', marginBottom: 14 },
  progressFill: { height: '100%', backgroundColor: C.saffron, borderRadius: 2 },
  loading: { color: C.txt3, fontSize: 12 },
  version: { position: 'absolute', bottom: 30, color: C.txt3, fontSize: 10 },
});

const tab = StyleSheet.create({
  bar: { flexDirection: 'row', backgroundColor: 'rgba(5,2,0,0.98)', borderTopWidth: 1, borderTopColor: C.border, height: 64 },
  item: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 3, position: 'relative' },
  indicator: { position: 'absolute', top: 0, width: 36, height: 2.5, borderRadius: 2, backgroundColor: C.saffron },
  icon: { fontSize: 20, color: C.txt3 },
  iconActive: { color: C.saffron },
  label: { fontSize: 9, color: C.txt3 },
  labelActive: { color: C.saffron },
});
