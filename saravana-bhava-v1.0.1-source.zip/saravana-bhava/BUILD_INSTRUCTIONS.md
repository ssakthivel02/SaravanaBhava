# Saravana Bhava v1.0.1 - Build Instructions

## Prerequisites
- Node.js 18+ installed
- npm or yarn package manager
- EAS CLI installed: `npm install -g eas-cli`
- Expo account (for EAS builds)
- Android SDK (for local builds)

## Build Configuration

### App Version
- **Version Name**: 1.0.1
- **Version Code**: 2
- **Package Name**: com.saravanabhava.murugan
- **Target SDK**: 36 (Android 15)
- **Min SDK**: 24 (Android 6)
- **Compile SDK**: 36

### Build Profiles
- **development**: Internal APK for testing
- **preview**: Internal APK for staging
- **production**: AAB for Google Play Store

## Local Build (APK)

### Prerequisites
- Android SDK installed
- ANDROID_HOME environment variable set

### Build APK
```bash
cd /home/ubuntu/saravana-bhava
npm install
eas build --platform android --profile preview
```

### Output
- APK file: `app-release.apk` (approximately 50-70 MB)
- Location: EAS build artifacts

## Production Build (AAB)

### Build AAB for Google Play
```bash
cd /home/ubuntu/saravana-bhava
npm install
eas build --platform android --profile production
```

### Output
- AAB file: `app-release.aab` (approximately 40-60 MB)
- Location: EAS build artifacts
- Ready for Google Play Console upload

## Build Process

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Verify Configuration**
   - Check `app.json` for correct version
   - Check `eas.json` for build profiles
   - Verify `package.json` version matches

3. **Run Build**
   ```bash
   eas build --platform android --profile production
   ```

4. **Monitor Build**
   - EAS will provide a build URL
   - Build typically takes 10-15 minutes
   - Receive email notification when complete

5. **Download Artifacts**
   - Download AAB from EAS dashboard
   - Verify file integrity (checksum)
   - Store safely for upload to Play Store

## Verification Checklist

- [ ] Version code incremented (2)
- [ ] Version name updated (1.0.1)
- [ ] Package name correct (com.saravanabhava.murugan)
- [ ] Target SDK 36
- [ ] All dependencies installed
- [ ] No TypeScript errors
- [ ] Assets present (icons, splash)
- [ ] Build completes successfully
- [ ] AAB file generated
- [ ] File size reasonable (40-60 MB)

## Troubleshooting

### Build Fails
1. Clear cache: `npm cache clean --force`
2. Delete node_modules: `rm -rf node_modules`
3. Reinstall: `npm install`
4. Check EAS status: `eas build --status`

### Authentication Issues
1. Login to EAS: `eas login`
2. Verify credentials: `eas whoami`
3. Re-authenticate if needed

### Version Issues
1. Verify app.json version
2. Check package.json version
3. Ensure versionCode incremented

## Upload to Google Play

After successful build:

1. Download AAB from EAS
2. Go to Google Play Console
3. Select app: Saravana Bhava – Murugan Bhakti
4. Go to Releases > Production
5. Click "Create new release"
6. Upload AAB file
7. Review and submit

## Support

- EAS Documentation: https://docs.expo.dev/eas/
- Expo CLI: https://docs.expo.dev/more/expo-cli/
- Google Play Console: https://play.google.com/console

